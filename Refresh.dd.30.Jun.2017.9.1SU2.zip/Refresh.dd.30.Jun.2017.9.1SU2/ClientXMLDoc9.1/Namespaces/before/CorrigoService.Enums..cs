namespace CorrigoService.Enums
{
    /// <summary>
    /// Alert types
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum AlertType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Emergency,

        /// <remarks/>
        ApptReminder,

        /// <remarks/>
        ApptChanged,

        /// <remarks/>
        FlaggedTech,

        /// <remarks/>
        EscalationExpired,

        /// <remarks/>
        AssignedWo,

        /// <remarks/>
        BadSurevy,

        /// <remarks/>
        OverdueWoPrior,

        /// <remarks/>
        OverdueWo,

        /// <remarks/>
        NewWo,

        /// <remarks/>
        FlaggedScope,

        /// <remarks/>
        WoCancelled,

        /// <remarks/>
        WorkPlanComplete,

        /// <remarks/>
        WoUnassigned,

        /// <remarks/>
        WoOnHold,

        /// <remarks/>
        WoPriorityChange,

        /// <remarks/>
        VisitOverdue,

        /// <remarks/>
        ImpairmentOverdue,

        /// <remarks/>
        ImpairmentWellOverdue,

        /// <remarks/>
        TenantCoiExpires,

        /// <remarks/>
        QuoteReview,

        /// <remarks/>
        CustomerNote,

        /// <remarks/>
        CWoCreated,

        /// <remarks/>
        CWoPutOnHold,

        /// <remarks/>
        CWoCancelled,

        /// <remarks/>
        CWoPickedUp,

        /// <remarks/>
        CWoRejected,

        /// <remarks/>
        CApproveQuote,

        /// <remarks/>
        CVerifyWork,

        /// <remarks/>
        CWoCompleted,

        /// <remarks/>
        CSendWo,

        /// <remarks/>
        CProviderMsg,

        /// <remarks/>
        CCustomerEstimate,

        /// <remarks/>
        CVendorInvoice,

        /// <remarks/>
        CCost,

        /// <remarks/>
        CApptChange,

        /// <remarks/>
        ProposalCurrent,

        /// <remarks/>
        ProposalEnds,

        /// <remarks/>
        ProposalSkipped,
    }

    /// <summary>
    /// Specifies the entity type.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum EntityType
    {

        /// <remarks/>
        TaxCode,

        /// <remarks/>
        InvoiceDictionaryItem,

        /// <remarks/>
        BillingAccount,

        /// <remarks/>
        WorkOrder,

        /// <remarks/>
        Location,

        /// <remarks/>
        Address,

        /// <remarks/>
        Customer,

        /// <remarks/>
        Invoice,

        /// <remarks/>
        InvoiceLine,

        /// <remarks/>
        CorporateEntity,

        /// <remarks/>
        GLAccount,

        /// <remarks/>
        Payment,

        /// <remarks/>
        PaymentItem,

        /// <remarks/>
        Employee,

        /// <remarks/>
        Community,

        /// <remarks/>
        Space,

        /// <remarks/>
        Task,

        /// <remarks/>
        Disposition,

        /// <remarks/>
        WoItem,

        /// <remarks/>
        CustomFieldDescriptor,

        /// <remarks/>
        CustomField,

        /// <remarks/>
        Organization,

        /// <remarks/>
        LinkEmployeeAndOrganization,

        /// <remarks/>
        Contact,

        /// <remarks/>
        TimePeriod,

        /// <remarks/>
        Specialty,

        /// <remarks/>
        WorkOrderType,

        /// <remarks/>
        CustomerNoteType,

        /// <remarks/>
        RepairCode,

        /// <remarks/>
        AttributeDescriptor,

        /// <remarks/>
        WoActionReasonLookup,

        /// <remarks/>
        WoPriority,

        /// <remarks/>
        WoPunchListItem,

        /// <remarks/>
        WoLastAction,

        /// <remarks/>
        WoNote,

        /// <remarks/>
        Actor,

        /// <remarks/>
        ContactAddress,

        /// <remarks/>
        PunchListMaster,

        /// <remarks/>
        PunchListMasterItem,

        /// <remarks/>
        PunchListMasterNote,

        /// <remarks/>
        Address2,

        /// <remarks/>
        ContactInfo,

        /// <remarks/>
        CustomField2,

        /// <remarks/>
        Note,

        /// <remarks/>
        WorkOrderCost,

        /// <remarks/>
        WoAssignment,

        /// <remarks/>
        WoOnSite,

        /// <remarks/>
        WoActionLog,

        /// <remarks/>
        WoVerification,

        /// <remarks/>
        WoActionLogProp,

        /// <remarks/>
        FinancialItem,

        /// <remarks/>
        WoQuote,

        /// <remarks/>
        WoEquipment,

        /// <remarks/>
        Blob,

        /// <remarks/>
        DocumentType,

        /// <remarks/>
        Document,

        /// <remarks/>
        Product,

        /// <remarks/>
        LaborCode,

        /// <remarks/>
        WpTree,

        /// <remarks/>
        WoEstimate,

        /// <remarks/>
        ToDoItem,

        /// <remarks/>
        LinkCustomerAndGroup,

        /// <remarks/>
        LinkContactAndGroup,

        /// <remarks/>
        AssetInfo,

        /// <remarks/>
        PmSchedule,

        /// <remarks/>
        PmItem,

        /// <remarks/>
        Contract,

        /// <remarks/>
        WorkZoneDetails,

        /// <remarks/>
        TaxRegion,

        /// <remarks/>
        TaxRegionItem,

        /// <remarks/>
        PriceList,

        /// <remarks/>
        PriceListItem,

        /// <remarks/>
        ChargeCodeLookup,

        /// <remarks/>
        CustomFieldOption,

        /// <remarks/>
        Model,

        /// <remarks/>
        LinkUserAndSpecialty,

        /// <remarks/>
        LinkUserAndCustomerGroup,

        /// <remarks/>
        LinkUserAndWorkZone,

        /// <remarks/>
        LinkUserAndPortfolio,

        /// <remarks/>
        LinkUserAndTeam,

        /// <remarks/>
        UserPayRate,

        /// <remarks/>
        LinkUserAndStockLocation,

        /// <remarks/>
        LinkProviderPriceList,

        /// <remarks/>
        LinkProviderAndService,

        /// <remarks/>
        Role,

        /// <remarks/>
        AlertScope,

        /// <remarks/>
        AlertSubscription,

        /// <remarks/>
        AssetTree,
    }

    /// <summary>
    /// Actor type enumeration; 
    /// matches table [ActorTypeLookup]
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum ActorType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Employee,

        /// <remarks/>
        Occupancy,

        /// <remarks/>
        CorrigoNet,

        /// <remarks/>
        Resident,

        /// <remarks/>
        CommLease,

        /// <remarks/>
        CommLeaseSpace,

        /// <remarks/>
        Property,

        /// <remarks/>
        Portfolio,

        /// <remarks/>
        LeaseGroup,

        /// <remarks/>
        LeaseUser,

        /// <remarks/>
        Supplier,

        /// <remarks/>
        Asset,

        /// <remarks/>
        WO,

        /// <remarks/>
        Org,

        /// <remarks/>
        Warranty,

        /// <remarks/>
        WOPrintout,

        /// <remarks/>
        ImageSet,

        /// <remarks/>
        Team,

        /// <remarks/>
        CompanyProp,

        /// <remarks/>
        WOAction,

        /// <remarks/>
        Landmark,

        /// <remarks/>
        Provider,

        /// <remarks/>
        ReportTimeSet,

        /// <remarks/>
        TenantCoi,

        /// <remarks/>
        Model,

        /// <remarks/>
        Theme,

        /// <remarks/>
        CustomerInvoice,

        /// <remarks/>
        Payment,

        /// <remarks/>
        MhLocation,

        /// <remarks/>
        MhProduct,

        /// <remarks/>
        PmRmTemplate,

        /// <remarks/>
        Document,

        /// <remarks/>
        WoProxy,

        /// <remarks/>
        Proposal,

        /// <remarks/>
        PlWoItem,
    }

    /// <summary>
    /// WO types
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WOType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Basic,

        /// <remarks/>
        PMRM,

        /// <remarks/>
        Turn,

        /// <remarks/>
        Request,
    }

    /// <summary>
    /// Bill To Type enumerartion; used by Financial Record to define entity which will be billed for paticular WO
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum BillToType
    {

        /// <remarks/>
        None,

        /// <remarks/>
        Customer,

        /// <remarks/>
        WorkZone,

        /// <remarks/>
        Other,
    }

    /// <summary>
    /// AP States - grouping for Vendor Invoice Statuses and also a source of business rules.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum ApState
    {

        /// <summary>
        /// Default/initial. Assigned when application creates new Financial Record.
        /// </summary>
        None,

        /// <summary>
        /// Assigned when provider submits invoice; or when pre-billed WO is sent to provider. Read-only.
        /// Used by WON service to check if invoice update is allowed.
        /// </summary>
        Received,

        /// <summary>
        /// Read-only.
        /// Might require WO status to be Completed.
        /// UI for this action expects user to enter payment information (amount, check number, date)
        /// Moving in or out of this state triggers Billing Status update.
        /// </summary>
        Paid,

        /// <summary>
        /// Assigned when WO is sent to provider; used by WON service to check if invoice update is allowed.
        /// </summary>
        Waiting,

        /// <summary>
        /// Read-only.
        /// Might require WO status to be Completed.
        /// Moving in or out of this state triggers Billing Status update.
        /// </summary>
        Authorized,

        /// <summary>
        /// Assigned when export routine is executed via web services.
        /// Might require WO status to be Completed.
        /// Triggers authorization number generation.
        /// Moving in or out of this state triggers Billing Status update.
        /// </summary>
        Exported,

        /// <summary>
        /// Triggers WON async notification; used by WON service to check if invoice update is allowed.
        /// </summary>
        Disputed,
    }

    /// <summary>
    /// Enumeration for contact address types
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum ContactAddrType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        PrimPhone,

        /// <remarks/>
        PrimEmail,

        /// <remarks/>
        AltPhone,

        /// <remarks/>
        Pager,

        /// <remarks/>
        EmergencyEMail,

        /// <remarks/>
        EmergencyPhone,

        /// <remarks/>
        AltEmail,

        /// <remarks/>
        EMail1,

        /// <remarks/>
        EMail2,

        /// <remarks/>
        EMail3,

        /// <remarks/>
        HomePhone,

        /// <remarks/>
        OfficePhone,

        /// <remarks/>
        MobilePhone,

        /// <remarks/>
        WAP,

        /// <remarks/>
        Fax,

        /// <remarks/>
        Contact,

        /// <remarks/>
        Website,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum StreetAddrType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Primary,

        /// <remarks/>
        Home,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum RateType
    {

        /// <remarks/>
        Fixed,

        /// <remarks/>
        Amount,

        /// <remarks/>
        Percentage,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum VendorType
    {

        /// <remarks/>
        Editable,

        /// <remarks/>
        NonEditable,

        /// <remarks/>
        Hidden,

        /// <remarks/>
        UseVendorPrLst,
    }

    /// <summary>
    /// Enumeration for custom field data types
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CfType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        String,

        /// <remarks/>
        Integer,

        /// <remarks/>
        Decimal,

        /// <remarks/>
        Money,

        /// <remarks/>
        Phone,

        /// <remarks/>
        Date,

        /// <remarks/>
        Time,

        /// <remarks/>
        Boolean,

        /// <remarks/>
        Url,
    }


    /// <summary>
    /// Types of inventory assets
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum AssetType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Regular,

        /// <summary>
        /// is used when application needs to find Unit�s parent to build so-called �short location� value.
        /// </summary>
        Building,

        /// <summary>
        /// is used to as root for Unit sub-tree
        /// </summary>
        Unit,

        /// <summary>
        /// is used as root for work zone Assets tree
        /// </summary>
        Community,

        /// <remarks/>
        RoomArea,

        /// <remarks/>
        Floor,

        /// <remarks/>
        Utility,

        /// <summary>
        /// is used when application builds list of Assets for �equipment worked on� feature
        /// </summary>
        Equipment,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum TaskSelfHelpType
    {

        /// <remarks/>
        Html,

        /// <remarks/>
        Hyperlink,

        /// <remarks/>
        YouTube,
    }

    /// <summary>
    /// WO Actions
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WOActionType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Create,

        /// <remarks/>
        PickUp,

        /// <remarks/>
        Start,

        /// <remarks/>
        OnHold,

        /// <remarks/>
        Complete,

        /// <remarks/>
        Cancel,

        /// <remarks/>
        Reopen,

        /// <remarks/>
        Assign,

        /// <remarks/>
        Attention,

        /// <remarks/>
        APInvStatus,

        /// <remarks/>
        Archived,

        /// <remarks/>
        Restored,

        /// <remarks/>
        Stop,

        /// <remarks/>
        AccessChanged,

        /// <remarks/>
        Billed,

        /// <remarks/>
        DueDateChanged,

        /// <remarks/>
        Note,

        /// <remarks/>
        Message,

        /// <remarks/>
        QuoteRequested,

        /// <remarks/>
        CostStatus,

        /// <remarks/>
        BillingRuleChanged,

        /// <remarks/>
        OwnerChanged,

        /// <remarks/>
        Signature,

        /// <remarks/>
        ApprovalStart,

        /// <remarks/>
        ApprovalEnd,

        /// <remarks/>
        ApGlAccountChanged,

        /// <remarks/>
        EstimateRejected,

        /// <remarks/>
        EstimateApproved,

        /// <remarks/>
        ItemAddRemove,

        /// <remarks/>
        EstimateSubmitted,

        /// <remarks/>
        WonWoSend,

        /// <remarks/>
        WonWoRecall,

        /// <remarks/>
        WonWoUpdate,

        /// <remarks/>
        WonPaymentSend,

        /// <remarks/>
        Verified,

        /// <remarks/>
        CustomerNteChanged,

        /// <remarks/>
        PriorityChanged,

        /// <remarks/>
        SchedStartChanged,

        /// <remarks/>
        VendorNteChanged,

        /// <remarks/>
        WonDocAttach,

        /// <remarks/>
        QuoteSubmitted,

        /// <remarks/>
        FlagCleared,

        /// <remarks/>
        QuoteRejected,

        /// <remarks/>
        QuoteApproved,
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum LeasingSpaceStatus
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Historical,

        /// <remarks/>
        Current,

        /// <remarks/>
        OnNotice,

        /// <remarks/>
        Pending,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum LeaseContactType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Alternate,

        /// <remarks/>
        Emergency,

        /// <remarks/>
        Primary,
    }


    /// <summary>
    /// Employee WON status 
    /// matching [EmployeeObject.WONStatusID]
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum EmployeeWonStatus
    {

        /// <summary>
        /// Deleted employee or not a provider
        /// </summary>
        NA,

        /// <remarks/>
        NotConnected,

        /// <remarks/>
        Suspended,

        /// <remarks/>
        Connected,

        /// <remarks/>
        Invited,
    }

    /// <summary>
    /// Distances can be stored either in kilometers or miles.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum DistanceUnit
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Kilometer,

        /// <remarks/>
        Mile,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum PriceListType
    {

        /// <remarks/>
        Customer,

        /// <remarks/>
        Vendor,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum OrgContactType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Primary,

        /// <remarks/>
        Secondary,
    }

    /// <summary>
    /// List of cost category
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CostCategory
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Labor,

        /// <remarks/>
        Material,

        /// <remarks/>
        Misc,

        /// <remarks/>
        Vendor,

        /// <remarks/>
        SpotPurchase,

        /// <remarks/>
        AddCharges,

        /// <remarks/>
        Services,

        /// <remarks/>
        Shipping,

        /// <remarks/>
        Adjustments,

        /// <remarks/>
        Tax,
    }

    /// <summary>
    /// Payment State
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum PaymentState
    {

        /// <remarks/>
        Draft,

        /// <remarks/>
        Credit,

        /// <remarks/>
        Posted,
    }

    /// <summary>
    /// Payment methods
    /// <seealso cref="Corrigo.Constants.CLookup.PaymentMethod"/>
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum PaymentMethod
    {

        /// <remarks/>
        Check,

        /// <remarks/>
        Cash,

        /// <remarks/>
        CreditCard,

        /// <summary>
        /// Electronic funds transfer (T)
        /// </summary>
        EFT,

        /// <summary>
        /// Account Credit Only (X)
        /// </summary>
        AccountCredit,
    }


    /// <summary>
    /// Customer Invoice State
    /// CLookup[TypeID = 'CIST']
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CiInvoiceState
    {

        /// <remarks/>
        Draft,

        /// <remarks/>
        Posted,

        /// <remarks/>
        Credit,

        /// <remarks/>
        CreditUsed,

        /// <remarks/>
        Paid,

        /// <remarks/>
        PaidInFull,

        /// <remarks/>
        Approved,
    }

    ///<summary>
    /// Invoice line item type
    /// 'CILT' in CLookup
    ///</summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CiItemType
    {

        /// <summary>
        /// Item is based on WO Cost line item. 
        /// </summary>
        WorkOrder,

        ///<summary>
        /// Item is based on Customer Contract
        /// This is header of the group consisting of one or more line items of type GroupChild
        ///</summary>
        GroupHeader,

        ///<summary>
        /// Item is based on work order covered by Customer Contract
        ///</summary>
        GroupChild,

        ///<summary>
        ///Item is not based on work order. End user may create ad hoc line item which is not related to any work order. 
        ///</summary>
        None,
    }

    /// <summary>
    /// WO Quote statuses. Same enumeration is also used as Estimate Status
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum QuoteStatus
    {

        /// <remarks/>
        Unknown,

        /// <summary>
        /// Set when WON WO is recalled
        /// </summary>
        NotSubmitted,

        /// <remarks/>
        Requested,

        /// <remarks/>
        WaitingForApproval,

        /// <remarks/>
        Approved,

        /// <remarks/>
        Rejected,

        /// <summary>
        /// In-Proposal; in 9.G used only for Estimates
        /// </summary>
        InProposal,
    }

    /// <summary>
    /// On-site validation type
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum OnSiteValidationType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Barcode,

        /// <remarks/>
        Gps,

        /// <remarks/>
        Ivr,
    }

    /// <summary>
    /// On-Site validation result
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum OnSiteValidationResult
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Unverified,

        /// <remarks/>
        Invalid,

        /// <remarks/>
        Valid,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WoRating
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        NotVerified,

        /// <remarks/>
        Negative,

        /// <remarks/>
        Neutral,

        /// <remarks/>
        Positive,

        /// <remarks/>
        NotCompleted,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WonDocumentType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Document,

        /// <remarks/>
        Note,
    }


    /// <summary>
    /// WO Equipment record type
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WoEquipmentType
    {

        /// <summary>
        /// The equipment we repaired is not listed here
        /// </summary>
        Unknown,

        /// <summary>
        /// We installed a new piece of equipment
        /// </summary>
        New,

        /// <summary>
        /// Known equipment
        /// </summary>
        Known,

        /// <summary>
        /// Not related to equipment
        /// </summary>
        NotRelated,
    }

	/// <summary>
	/// Type of WO financial line item; matches [WOCostDetailObject.TypeID]
	/// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WoCostLineType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Cost,

        /// <remarks/>
        Vendor,

        /// <remarks/>
        ServiceFee,
    }


	/// <summary>
	/// WO Note types (character-based; CLookup.TypeID="WONT")
	/// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WONoteType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Completion,

        /// <remarks/>
        Public,

        /// <remarks/>
        Private,
    }


    /// <summary>
    /// WO action properties; matches contents of WOALPropertyLookup
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WOActionProperty
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        FlagId,

        /// <remarks/>
        SignedBy,

        /// <remarks/>
        SignedEmail,

        /// <remarks/>
        CostStatusId,

        /// <remarks/>
        CostStatus,

        /// <remarks/>
        Rating,

        /// <remarks/>
        ItemAdded,

        /// <remarks/>
        ItemRemoved,

        /// <remarks/>
        AssignmentRemoved,

        /// <remarks/>
        AssignmentAdded,

        /// <remarks/>
        InvoiceId,

        /// <remarks/>
        ApInvoiceId,

        /// <remarks/>
        ApInvoiceName,

        /// <remarks/>
        ByContactId,

        /// <remarks/>
        PrevWoStatus,

        /// <remarks/>
        MsgAddressedTo,

        /// <remarks/>
        MsgAddress,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum UIType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Corp,

        /// <remarks/>
        CallCenter,

        /// <remarks/>
        Wireless,

        /// <remarks/>
        Resident,

        /// <remarks/>
        Monitor,

        /// <remarks/>
        System,

        /// <remarks/>
        IVR,

        /// <remarks/>
        Offline,

        /// <remarks/>
        IntegrationWS,

        /// <remarks/>
        WON,

        /// <remarks/>
        OTHER,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum BillStatus
    {

        /// <remarks/>
        NotBilled,

        /// <remarks/>
        ReadyToBeBilled,

        /// <remarks/>
        Billed,

        /// <remarks/>
        ReadyToBeBilled_Billed,

        /// <remarks/>
        BilledAndModified,

        /// <remarks/>
        ReadyToBeBilled_BilledAndModified,

        /// <remarks/>
        Billed_BilledAndModified,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum BillingRule
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        VendorAndServiceFee,

        /// <remarks/>
        Contract,

        /// <remarks/>
        NotBilled,

        /// <remarks/>
        ServiceFee,

        /// <remarks/>
        All,

        /// <remarks/>
        CostsAndFees,
    }

    /// <summary>
    /// Tax validation statuses for Vendor Invoice.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum TaxValidationStatus
    {

        /// <summary>
        /// Unsupported value; an equivalent to NUL/empty
        /// </summary>
        Unknown,

        /// <summary>
        /// Tax validation status is unknown/uncertain
        /// </summary>
        None,

        /// <summary>
        /// Tax validation succeeded
        /// </summary>
        Success,

        /// <summary>
        /// Tax validation failed
        /// </summary>
        Failure,

        /// <summary>
        /// Tax information was supplied by provider
        /// </summary>
        Provider,
    }

    /// <summary>
    /// Cost States - grouping for Cost Statuses and also a source of business rules.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CostState
    {

        /// <summary>
        /// Default/initial. Assigned when application creates new Financial Record.
        /// </summary>
        Pending,

        /// <summary>
        /// Assigned manually when technician finishes recording costs.
        /// </summary>
        Submitted,

        /// <summary>
        /// Read-only.
        /// Assigned manually when manager finishes reviewing costs.
        /// Might require WO status to be Completed.
        /// This is terminal state.
        /// </summary>
        Approved,

        /// <summary>
        /// Read-only.
        /// Assigned when export routine is executed via web services.
        /// Might require WO status to be Completed.
        /// This is terminal state.
        /// </summary>
        Exported,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WorkOrderStatus
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Open,

        /// <remarks/>
        Paused,

        /// <remarks/>
        Cancelled,

        /// <remarks/>
        Closed,

        /// <remarks/>
        Attention,

        /// <remarks/>
        New,

        /// <remarks/>
        OnHold,

        /// <remarks/>
        InProgress,

        /// <remarks/>
        Completed,
    }

    /// <summary>
    /// "Permission To Enter" Type
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum PTEType
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        PTE,

        /// <remarks/>
        Appointment,

        /// <remarks/>
        CallFirst,

        /// <remarks/>
        NotApplicable,
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum Protocols
    {

        /// <remarks/>
        HTTP,

        /// <remarks/>
        HTTPS,
    }

	/// <summary>
	/// Work order status
	/// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WOStatus
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Open,

        /// <remarks/>
        Paused,

        /// <remarks/>
        Cancelled,

        /// <remarks/>
        Attention,

        /// <remarks/>
        New,

        /// <remarks/>
        OnHold,

        /// <remarks/>
        InProgress,

        /// <remarks/>
        Completed,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CompletionNoteOptions
    {

        /// <remarks/>
        Ignore,

        /// <remarks/>
        Replace,

        /// <remarks/>
        FillEmpty,
    }


    /// <summary>
    /// How Assignees parameter is treated. Four modes supported: Primary, AddSecondary, RemoveSecondary and Snapshot. In Snapshot mode, Assignees collection is treated as new list of assignees for WO; and first item in that list is treated as primary assignee. In all modes Assignees can be empty.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WoChangeAssigmentMode
    {

        /// <summary>
        /// Modify primary WO assignment record 
        /// </summary>
        Primary,

        /// <summary>
        /// Go through Assignees list and check whether particular Employee ID is already present in the whole WO Assignments collection
        /// </summary>
        AddSecondary,

        /// <summary>
        /// Go through Assignees list and check whether particular Employee ID is present among secondary WO Assignments
        /// </summary>
        RemoveSecondary,

        /// <summary>
        /// Allows making multiple assignment changes at once (it�s the most flexible mode)
        /// </summary>
        Snapshot,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum APInvoiceStatus
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        None,

        /// <remarks/>
        Received,

        /// <remarks/>
        Paid,

        /// <remarks/>
        Waiting,

        /// <remarks/>
        Authorized,

        /// <remarks/>
        Exported,

        /// <remarks/>
        Disputed,
    }


    /// <summary>
    /// Pre-defined Cost Statuses matching members of <see cref="CostState"/> with same ID values.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum CostStatus
    {

        /// <remarks/>
        Unknown,

        /// <remarks/>
        Pending,

        /// <remarks/>
        Submitted,

        /// <remarks/>
        Approved,

        /// <remarks/>
        Exported,
    }

    /// <remarks/>
    [System.FlagsAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum WoScheduleOptions
    {

        /// <remarks/>
        None = 1,

        /// <remarks/>
        SkipWarranty = 2,

        /// <remarks/>
        SkipScheduling = 4,

        /// <remarks/>
        SkipFinancial = 8,

        /// <remarks/>
        SkipPTE = 16,

        /// <remarks/>
        SkipDueDate = 32,

        /// <remarks/>
        SkipOnSiteBy = 64,
    }

    /// <summary>
    /// Specifies the possible values for the operator in a condition expression.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum ConditionOperator
    {

        /// <summary>
        /// Specifies that the value is between two values.
        /// </summary>
        Between,

        /// <summary>
        /// Specifies that two expressions are compared for equality.
        /// </summary>
        Equal,

        /// <summary>
        /// Specifies that two expressions are compared for greater than or equal to conditions.
        /// </summary>
        GreaterOrEqual,

        /// <summary>
        /// Specifies that two expressions are compared for greater than condition.
        /// </summary>
        GreaterThan,

        /// <summary>
        /// Specifies that a given value is matched to a value in a subquery or a list.
        /// </summary>
        In,

        /// <summary>
        /// Specifies that two expressions are compared for less than or equal to conditions.
        /// </summary>
        LessOrEqual,

        /// <summary>
        /// Specifies that two expressions are compared for less than condition.
        /// </summary>
        LessThan,

        /// <summary>
        /// Specifies that the character string is matched to a specified pattern.
        /// </summary>
        Like,

        /// <summary>
        /// Specifies that the value is not between two values.
        /// </summary>
        NotBetween,

        /// <summary>
        /// Specifies that two expressions are compared for inequality.
        /// </summary>
        NotEqual,

        /// <summary>
        /// Specifies that a given value is not matched to a value in a subquery or a list.
        /// </summary>
        NotIn,

        /// <summary>
        /// Specifies that the character string is not matched to a specified pattern.
        /// </summary>
        NotLike,

        /// <summary>
        /// Specifies that the value is not null.
        /// </summary>
        NotNull,

        /// <summary>
        /// Specifies that the value is null.
        /// </summary>
        Null,
    }


    /// <summary>
    /// Specifies the possible values for an operator in a Filter Expression.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum LogicalOperator
    {

        /// <summary>
        /// Specifies that a logical AND operation is performed.
        /// </summary>
        And,

        /// <summary>
        /// Specifies that a logical OR operation is performed.
        /// </summary>
        Or,
    }

    /// <summary>
    /// Specifies the possible values for the order type in an OrderExpression.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public enum OrderType
    {

        /// <summary>
        /// Specifies that the values of the specified attribute should be sorted in ascending order, from lowest value to highest value.
        /// </summary>
        Ascending,

        /// <summary>
        /// Specifies that the values of the specified attribute should be sorted in descending order, from highest value to lowest value.
        /// </summary>
        Descending,
    }











}