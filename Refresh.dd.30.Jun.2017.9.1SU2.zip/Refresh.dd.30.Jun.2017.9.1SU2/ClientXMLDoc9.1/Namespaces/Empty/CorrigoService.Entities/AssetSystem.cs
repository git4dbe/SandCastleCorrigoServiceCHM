    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://corrigo.com/integration/")]
    public partial class AssetSystem : CorrigoEntity {
        
        private string descriptionField;
        
        private string displayAsField;
        
        /// <remarks/>
        public string Description {
            get {
                return this.descriptionField;
            }
            set {
                this.descriptionField = value;
            }
        }
        
        /// <remarks/>
        public string DisplayAs {
            get {
                return this.displayAsField;
            }
            set {
                this.displayAsField = value;
            }
        }
    }
