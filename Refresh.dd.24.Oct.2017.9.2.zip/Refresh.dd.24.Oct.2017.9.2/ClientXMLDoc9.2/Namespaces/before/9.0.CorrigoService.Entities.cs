namespace CorrigoService.Entities
{
    using Enums;
    using Commands;




    /// <summary>
    /// Represents work order (read only).
    /// Table [WorkOrder2Object].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WorkOrder : CorrigoEntityWithOptimisticLock
    {

        private string numberField;

        private WOType typeCategoryField;

        private WorkOrderCost workOrderCostField;

        private WoPriority priorityField;

        private WorkOrderStatus statusIdField;

        private Contact requestorContactField;

        private PTEType accessField;

        private Location mainAssetField;

        private string shortLocationField;

        private string taskRefinementField;

        private Community communityField;

        private Employee employeeField;

        private int durationField;

        private decimal vendorNteField;

        private Specialty specialtyField;

        private string poNumberField;

        private WorkOrderType subTypeField;

        private RepairCode repairCodeField;

        private Customer customerField;

        private string contactNameField;

        private int wonIdField;

        private bool isWarrantyField;

        private WoActionReasonLookup flagField;

        private int timeZoneField;

        private System.DateTime lastActionDateField;

        private System.DateTime dtCreatedField;

        private System.Nullable<System.DateTime> dtScheduledStartField;

        private System.Nullable<System.DateTime> dtDueField;

        private System.DateTime lastActionDateUtcField;

        private System.DateTime createdDateUtcField;

        private System.Nullable<System.DateTime> scheduledStartUtcField;

        private System.Nullable<System.DateTime> dueDateUtcField;

        private System.Nullable<System.DateTime> dtOnSiteByField;

        private System.Nullable<System.DateTime> dtUtcOnSiteByField;

        private WoLastAction lastActionField;

        private Address2 addressField;

        private WoItem[] itemsField;

        private WoEquipment[] equipmentWorkedOnField;

        private WoNote[] notesField;

        private WoNote completionNoteField;

        private ContactInfo contactAddressField;

        private WoAssignment[] assignmentsField;

        private WoPunchListItem[] punchListItemsField;

        private Document[] documentsField;

        private CustomField2[] customFieldsField;

        private WoVerification[] verificationsField;

        private WoQuote quoteField;

        private WoOnSite[] checkInOutsField;

        private WoActionLog[] actionLogRecordsField;

        private WoEstimate estimateField;

        /// <summary>
        /// Gets a work order number.
        /// Automatically generated if not supplied automatically.
        /// Max Length=16
        /// </summary>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <summary>
        /// Type: Unknown, Basic, PMRM(Preventive Maintenance/Routine Maintenance), Turn, Request.
        /// It determines behavior of the work order during its lifecycle.
        /// Is required.
        /// </summary>
        public WOType TypeCategory
        {
            get
            {
                return this.typeCategoryField;
            }
            set
            {
                this.typeCategoryField = value;
            }
        }

        /// <summary>
        /// WO Invoice.
        /// Financial Record represents Work Order's data related to financial side of the workflow:
        /// costs tracking, vendor invoice, service fees etc.
        /// </summary>
        public WorkOrderCost WorkOrderCost
        {
            get
            {
                return this.workOrderCostField;
            }
            set
            {
                this.workOrderCostField = value;
            }
        }

        /// <summary>
        /// It indicates the urgency level of the work order.
        /// </summary>
        public WoPriority Priority
        {
            get
            {
                return this.priorityField;
            }
            set
            {
                this.priorityField = value;
            }
        }

        /// <summary>
        /// Status: Unknown, Open, Paused, Cancelled, Closed, Attention, New, OnHold, InProgress, Completed
        /// </summary>
        public WorkOrderStatus StatusId
        {
            get
            {
                return this.statusIdField;
            }
            set
            {
                this.statusIdField = value;
            }
        }

        /// <summary>
        /// Requestor contact data
        /// </summary>
        public Contact RequestorContact
        {
            get
            {
                return this.requestorContactField;
            }
            set
            {
                this.requestorContactField = value;
            }
        }

        /// <summary>
        /// Access: Unknown, PTE, Appointment, CallFirst, NotApplicable
        /// </summary>
        public PTEType Access
        {
            get
            {
                return this.accessField;
            }
            set
            {
                this.accessField = value;
            }
        }

        /// <summary>
        /// Asset representing main WO location
        /// </summary>
        public Location MainAsset
        {
            get
            {
                return this.mainAssetField;
            }
            set
            {
                this.mainAssetField = value;
            }
        }

        /// <summary>
        /// Shortened asset inventory location for display purposes.
        /// Max Length=128
        /// </summary>
        public string ShortLocation
        {
            get
            {
                return this.shortLocationField;
            }
            set
            {
                this.shortLocationField = value;
            }
        }

        /// <summary>
        /// Contains work description for the Work Order.
        /// This value is automatically generated or entered by user manually.
        /// Max Length=512
        /// </summary>
        public string TaskRefinement
        {
            get
            {
                return this.taskRefinementField;
            }
            set
            {
                this.taskRefinementField = value;
            }
        }

        /// <summary>
        /// NonUpdatable.
        /// Specifies an area (Work Zone) in which service is provided
        /// </summary>
        public Community Community
        {
            get
            {
                return this.communityField;
            }
            set
            {
                this.communityField = value;
            }
        }

        /// <summary>
        /// NonUpdatable.
        /// Primary technician responsible for executing of the work order
        /// </summary>
        public Employee Employee
        {
            get
            {
                return this.employeeField;
            }
            set
            {
                this.employeeField = value;
            }
        }

        /// <summary>
        /// Expected duration for the work related to this work order in minutes.
        /// </summary>
        public int Duration
        {
            get
            {
                return this.durationField;
            }
            set
            {
                this.durationField = value;
            }
        }

        /// <summary>
        /// NTE (Not to Exceed) for vendor invoice.
        /// </summary>
        public decimal VendorNte
        {
            get
            {
                return this.vendorNteField;
            }
            set
            {
                this.vendorNteField = value;
            }
        }

        /// <summary>
        /// Specifies what type of work needs to be done for this work order
        /// </summary>
        public Specialty Specialty
        {
            get
            {
                return this.specialtyField;
            }
            set
            {
                this.specialtyField = value;
            }
        }

        /// <summary>
        /// Purchase Order Number.
        /// Max Length=50
        /// </summary>
        public string PoNumber
        {
            get
            {
                return this.poNumberField;
            }
            set
            {
                this.poNumberField = value;
            }
        }

        /// <summary>
        /// Work order custom type.
        /// Each custom type corresponds to one of the base work order type.
        /// References table [vlangWOTypeLookup].
        /// Is required.
        /// </summary>
        public WorkOrderType SubType
        {
            get
            {
                return this.subTypeField;
            }
            set
            {
                this.subTypeField = value;
            }
        }

        /// <summary>
        /// Repair codes are a means of gathering completion data in the field.
        /// These codes are not limited to repair data.
        /// It can be customized and used to capture whatever kind of information that is most useful for organization to collect.
        /// </summary>
        public RepairCode RepairCode
        {
            get
            {
                return this.repairCodeField;
            }
            set
            {
                this.repairCodeField = value;
            }
        }

        /// <summary>
        /// Customer.
        /// Is required.
        /// </summary>
        public Customer Customer
        {
            get
            {
                return this.customerField;
            }
            set
            {
                this.customerField = value;
            }
        }

        /// <summary>
        /// Contact name.
        /// Max Length=256
        /// </summary>
        public string ContactName
        {
            get
            {
                return this.contactNameField;
            }
            set
            {
                this.contactNameField = value;
            }
        }

        /// <summary>
        /// WON (Work Order Network) Id.
        /// </summary>
        public int WonId
        {
            get
            {
                return this.wonIdField;
            }
            set
            {
                this.wonIdField = value;
            }
        }

        /// <summary>
        /// "True" means WO might be covered by provider�s warranty.
        /// </summary>
        public bool IsWarranty
        {
            get
            {
                return this.isWarrantyField;
            }
            set
            {
                this.isWarrantyField = value;
            }
        }

        /// <summary>
        /// Action Reason.
        /// References table [WOActionReasonLookup]
        /// </summary>
        public WoActionReasonLookup Flag
        {
            get
            {
                return this.flagField;
            }
            set
            {
                this.flagField = value;
            }
        }

        /// <summary>
        /// Time Zone
        /// </summary>
        public int TimeZone
        {
            get
            {
                return this.timeZoneField;
            }
            set
            {
                this.timeZoneField = value;
            }
        }

        /// <summary>
        /// Last Action Date
        /// </summary>
        public System.DateTime LastActionDate
        {
            get
            {
                return this.lastActionDateField;
            }
            set
            {
                this.lastActionDateField = value;
            }
        }

        /// <summary>
        /// Date the work order was created. If not specified will be Now().
        /// </summary>
        public System.DateTime DtCreated
        {
            get
            {
                return this.dtCreatedField;
            }
            set
            {
                this.dtCreatedField = value;
            }
        }

        /// <summary>
        /// Work Order scheduled start time
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtScheduledStart
        {
            get
            {
                return this.dtScheduledStartField;
            }
            set
            {
                this.dtScheduledStartField = value;
            }
        }

        /// <summary>
        /// Local time indicating moment when WO becomes overdue;
        /// Computed based on work zone settings and WO priority (which makes it dependent on WO items);
        /// can be overridden by end user
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtDue
        {
            get
            {
                return this.dtDueField;
            }
            set
            {
                this.dtDueField = value;
            }
        }

        /// <summary>
        /// Last Action Date Utc
        /// </summary>
        public System.DateTime LastActionDateUtc
        {
            get
            {
                return this.lastActionDateUtcField;
            }
            set
            {
                this.lastActionDateUtcField = value;
            }
        }

        /// <summary>
        /// Date Utc the work order was created.
        /// If not specified will be UtcNow().
        /// </summary>
        public System.DateTime CreatedDateUtc
        {
            get
            {
                return this.createdDateUtcField;
            }
            set
            {
                this.createdDateUtcField = value;
            }
        }

        /// <summary>
        /// Work Order scheduled Utc start time.
        /// If not specified will be UtcNow().
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> ScheduledStartUtc
        {
            get
            {
                return this.scheduledStartUtcField;
            }
            set
            {
                this.scheduledStartUtcField = value;
            }
        }


        /// <summary>
        /// Utc time indicating moment when WO becomes overdue
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DueDateUtc
        {
            get
            {
                return this.dueDateUtcField;
            }
            set
            {
                this.dueDateUtcField = value;
            }
        }


        /// <summary>
        /// Local time indicating moment by which WO needs to be "responded to", i.e. started;
        /// Computed based on WO priority (which makes it dependent on WO items);
        /// can be overridden by end user.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtOnSiteBy
        {
            get
            {
                return this.dtOnSiteByField;
            }
            set
            {
                this.dtOnSiteByField = value;
            }
        }

        /// <summary>
        /// Utc time indicating moment by which WO needs to be "responded to", i.e. started
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtUtcOnSiteBy
        {
            get
            {
                return this.dtUtcOnSiteByField;
            }
            set
            {
                this.dtUtcOnSiteByField = value;
            }
        }


        /// <summary>
        /// Last Action.
        /// WO Shadow record.
        /// </summary>
        public WoLastAction LastAction
        {
            get
            {
                return this.lastActionField;
            }
            set
            {
                this.lastActionField = value;
            }
        }

        /// <summary>
        /// Address
        /// </summary>
        public Address2 Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <summary>
        /// Work order tasks.
        /// </summary>
        public WoItem[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }

        /// <summary>
        /// Equipment
        /// </summary>
        public WoEquipment[] EquipmentWorkedOn
        {
            get
            {
                return this.equipmentWorkedOnField;
            }
            set
            {
                this.equipmentWorkedOnField = value;
            }
        }

        /// <summary>
        /// Notes
        /// </summary>
        public WoNote[] Notes
        {
            get
            {
                return this.notesField;
            }
            set
            {
                this.notesField = value;
            }
        }

        /// <summary>
        /// Completion Note
        /// </summary>
        public WoNote CompletionNote
        {
            get
            {
                return this.completionNoteField;
            }
            set
            {
                this.completionNoteField = value;
            }
        }

        /// <summary>
        /// Contact Address.
        /// Is required.
        /// </summary>
        public ContactInfo ContactAddress
        {
            get
            {
                return this.contactAddressField;
            }
            set
            {
                this.contactAddressField = value;
            }
        }

        /// <summary>
        /// Assignments
        /// </summary>
        public WoAssignment[] Assignments
        {
            get
            {
                return this.assignmentsField;
            }
            set
            {
                this.assignmentsField = value;
            }
        }

        /// <summary>
        /// Punch List Items
        /// </summary>
        public WoPunchListItem[] PunchListItems
        {
            get
            {
                return this.punchListItemsField;
            }
            set
            {
                this.punchListItemsField = value;
            }
        }

        /// <summary>
        /// Documents
        /// </summary>
        public Document[] Documents
        {
            get
            {
                return this.documentsField;
            }
            set
            {
                this.documentsField = value;
            }
        }

        /// <summary>
        /// Custom Fields
        /// </summary>
        public CustomField2[] CustomFields
        {
            get
            {
                return this.customFieldsField;
            }
            set
            {
                this.customFieldsField = value;
            }
        }

        /// <summary>
        /// Verifications. (WO Ratings)
        /// </summary>
        public WoVerification[] Verifications
        {
            get
            {
                return this.verificationsField;
            }
            set
            {
                this.verificationsField = value;
            }
        }

        /// <summary>
        /// Quote
        /// </summary>
        public WoQuote Quote
        {
            get
            {
                return this.quoteField;
            }
            set
            {
                this.quoteField = value;
            }
        }

        /// <summary>
        /// Check In/Outs Log
        /// </summary>
        public WoOnSite[] CheckInOuts
        {
            get
            {
                return this.checkInOutsField;
            }
            set
            {
                this.checkInOutsField = value;
            }
        }

        /// <summary>
        /// Action Logs
        /// </summary>
        public WoActionLog[] ActionLogRecords
        {
            get
            {
                return this.actionLogRecordsField;
            }
            set
            {
                this.actionLogRecordsField = value;
            }
        }

        /// <summary>
        /// Customer Estimate
        /// </summary>
        public WoEstimate Estimate
        {
            get
            {
                return this.estimateField;
            }
            set
            {
                this.estimateField = value;
            }
        }
    }



    /// <summary>
    /// Represents work order cost.
    /// The object is used to calculate how much money should be payed for the services were done in frame of the Work Order.
    /// Table [WorkOrderCostObject].
    /// Web service access scope - read and update only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WorkOrderCost : CorrigoEntityWithOptimisticLock
    {

        private BillToType billToTypeField;

        private decimal costsTotalField;

        private ApState apStateIdField;

        private int apStatusIdField;

        private string jobCodeField;

        private Contract contractField;

        private string authorizationCodeField;

        private string checkNumberField;

        private decimal paymentAmountField;

        private string paymentNotesField;

        private System.Nullable<System.DateTime> checkCutDateField;

        private System.Nullable<System.DateTime> checkClearDateField;

        private string glAccountField;

        private string numberField;

        private int wonCoverWarrantyIdField;

        private System.Nullable<System.DateTime> vendorInvoiceDateField;

        private System.Nullable<System.DateTime> vendorInvoiceReceivedDateField;

        private decimal vendorInvoiceTotalField;

        private bool isPreBilledField;

        private decimal expensesTotalField;

        private BillingRule billingRuleField;

        private TaxValidationStatus taxStatusField;

        private decimal customerNteField;

        private FinancialItem[] itemsField;

        private Blob taxValidationNoteField;

        private decimal serviceFeesTotalField;

        private int costStatusIdField;

        private CostState costStateField;

        private ChargeCodeLookup chargeCodeField;

        private BillingAccount billingAccountField;

        private string externalIdField;

        /// <summary>
        /// Enumeration of values: None, Customer, WorkZone, Other.
        /// This field defines type of entity which will be billed for this WO, or lack thereof.
        /// </summary>
        public BillToType BillToType
        {
            get
            {
                return this.billToTypeField;
            }
            set
            {
                this.billToTypeField = value;
            }
        }

        /// <summary>
        /// Total amount of Costs associated with WO. Zero value is allowed.
        /// </summary>
        public decimal CostsTotal
        {
            get
            {
                return this.costsTotalField;
            }
            set
            {
                this.costsTotalField = value;
            }
        }

        /// <summary>
        /// AP State matching current Vendor Invoice status.
        /// </summary>
        public ApState ApStateId
        {
            get
            {
                return this.apStateIdField;
            }
            set
            {
                this.apStateIdField = value;
            }
        }

        /// <summary>
        /// Vendor Invoice status
        /// </summary>
        public int ApStatusId
        {
            get
            {
                return this.apStatusIdField;
            }
            set
            {
                this.apStatusIdField = value;
            }
        }

        /// <summary>
        /// Job Code; this field has no associated business logic and set manually by user.
        /// Max Length=32
        /// </summary>	
        public string JobCode
        {
            get
            {
                return this.jobCodeField;
            }
            set
            {
                this.jobCodeField = value;
            }
        }

        /// <summary>
        /// Contract associated with WO; references WOCostDefaultObject.ID.
        /// </summary>	
        public Contract Contract
        {
            get
            {
                return this.contractField;
            }
            set
            {
                this.contractField = value;
            }
        }

        /// <summary>
        /// Authorization code for Vendor Invoice; set by user when Vendor Invoice status is set to predefined status �Authorized�.
        /// Max Length=32
        /// </summary>	
        public string AuthorizationCode
        {
            get
            {
                return this.authorizationCodeField;
            }
            set
            {
                this.authorizationCodeField = value;
            }
        }

        /// <summary>
        /// Check number; set by user when Vendor Invoice status is set to predefined status �Paid�.
        /// Max Length=64
        /// </summary>	
        public string CheckNumber
        {
            get
            {
                return this.checkNumberField;
            }
            set
            {
                this.checkNumberField = value;
            }
        }

        /// <summary>
        /// Amount paid to vendor; set by user when Vendor Invoice status is set to predefined status �Paid�.
        /// </summary>	
        public decimal PaymentAmount
        {
            get
            {
                return this.paymentAmountField;
            }
            set
            {
                this.paymentAmountField = value;
            }
        }

        /// <summary>
        /// Payment Notes.
        /// Max Length=3072
        /// </summary>	
        public string PaymentNotes
        {
            get
            {
                return this.paymentNotesField;
            }
            set
            {
                this.paymentNotesField = value;
            }
        }

        /// <summary>
        /// Payment date; set by user when Vendor Invoice status is set to predefined status �Paid�. Value is date only, no time part.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> CheckCutDate
        {
            get
            {
                return this.checkCutDateField;
            }
            set
            {
                this.checkCutDateField = value;
            }
        }

        /// <summary>
        /// Date when check to vendor was cleared. There is no business logic for this field. Value is date only, no time part.
        /// </summary>	
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> CheckClearDate
        {
            get
            {
                return this.checkClearDateField;
            }
            set
            {
                this.checkClearDateField = value;
            }
        }

        /// <summary>
        /// GL Account number matching GLAccountObject.DisplayAs.
        /// Max Length=32
        /// </summary>	
        public string GlAccount
        {
            get
            {
                return this.glAccountField;
            }
            set
            {
                this.glAccountField = value;
            }
        }

        /// <summary>
        /// Vendor Invoice Number. This value is set either manually or by WON provider when invoice is submitted.
        /// Max Length=32
        /// </summary>	
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        public int WonCoverWarrantyId
        {
            get
            {
                return this.wonCoverWarrantyIdField;
            }
            set
            {
                this.wonCoverWarrantyIdField = value;
            }
        }

        /// <summary>
        /// Vendor invoice submission date provided received from 6.x. Value is date only, no time part.
        /// </summary>	
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> VendorInvoiceDate
        {
            get
            {
                return this.vendorInvoiceDateField;
            }
            set
            {
                this.vendorInvoiceDateField = value;
            }
        }

        /// <summary>
        /// Actual vendor invoice submission date (automatically set when invoice is received from 6.x). Value is date only, no time part.
        /// </summary>	
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> VendorInvoiceReceivedDate
        {
            get
            {
                return this.vendorInvoiceReceivedDateField;
            }
            set
            {
                this.vendorInvoiceReceivedDateField = value;
            }
        }

        /// <summary>
        /// Vendor Invoice total amount. Zero value is allowed.
        /// </summary>
        public decimal VendorInvoiceTotal
        {
            get
            {
                return this.vendorInvoiceTotalField;
            }
            set
            {
                this.vendorInvoiceTotalField = value;
            }
        }

        /// <summary>
        /// True means this is pre-billed vendor invoice. Such vendor invoices can be created from PM/RM templates; they have distinct WON workflow in 6.x.
        /// </summary>
        public bool IsPreBilled
        {
            get
            {
                return this.isPreBilledField;
            }
            set
            {
                this.isPreBilledField = value;
            }
        }

        /// <summary>
        /// Total amount of costs plus Vendor Invoice total. This represents total amount of expenses associated with WO. Zero value is allowed.
        /// </summary>	
        public decimal ExpensesTotal
        {
            get
            {
                return this.expensesTotalField;
            }
            set
            {
                this.expensesTotalField = value;
            }
        }

        /// <summary>
        /// Enumeration of values: Unknown, VendorAndServiceFee, Contract, NotBilled, ServiceFee, All, CostsAndFees.
        /// </summary>
        public BillingRule BillingRule
        {
            get
            {
                return this.billingRuleField;
            }
            set
            {
                this.billingRuleField = value;
            }
        }

        /// <summary>
        /// Enumeration of values: Unknown, None, Success, Failure, Provider
        /// </summary>
        public TaxValidationStatus TaxStatus
        {
            get
            {
                return this.taxStatusField;
            }
            set
            {
                this.taxStatusField = value;
            }
        }

        /// <summary>
        /// Customer NTE (not to exceed).
        /// </summary>	
        public decimal CustomerNte
        {
            get
            {
                return this.customerNteField;
            }
            set
            {
                this.customerNteField = value;
            }
        }

        /// <summary>
        /// Financial Items
        /// </summary>
        public FinancialItem[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }

        /// <summary>
        /// Tax Validation Note
        /// </summary>
        public Blob TaxValidationNote
        {
            get
            {
                return this.taxValidationNoteField;
            }
            set
            {
                this.taxValidationNoteField = value;
            }
        }

        /// <summary>
        /// Total amount of service fees. Precision 2 digits; negative and zero values are allowed. This value is computed by BO.
        /// </summary>	
        public decimal ServiceFeesTotal
        {
            get
            {
                return this.serviceFeesTotalField;
            }
            set
            {
                this.serviceFeesTotalField = value;
            }
        }

        /// <summary>
        /// Cost status; references vlangARBillStatusLookup.ID.
        /// </summary>
        public int CostStatusId
        {
            get
            {
                return this.costStatusIdField;
            }
            set
            {
                this.costStatusIdField = value;
            }
        }

        /// <summary>
        /// Enumeration of values:  Pending, Submitted, Approved, Exported
        /// Cost State matching current Cost status; references vlangCostState.ID and matches enumeration CostState.
        /// Is required.
        /// </summary>
        public CostState CostState
        {
            get
            {
                return this.costStateField;
            }
            set
            {
                this.costStateField = value;
            }
        }

        /// <summary>
        /// Custom charge back classification defined by client; used only when Customer Invoicing module is off. References ChargeCodeObject.ID; there is predefined default value ChargeCode.None which is used by BO.
        /// Is Required.
        /// </summary>
        public ChargeCodeLookup ChargeCode
        {
            get
            {
                return this.chargeCodeField;
            }
            set
            {
                this.chargeCodeField = value;
            }
        }

        /// <summary>
        /// Billing Account associated with WO; references lsGroupObject.ID and  must match record with IsBillAcct == True.
        /// </summary>
        public BillingAccount BillingAccount
        {
            get
            {
                return this.billingAccountField;
            }
            set
            {
                this.billingAccountField = value;
            }
        }

        /// <summary>
        /// External ID; used by integration clients.
        /// Max Length=64
        /// </summary>
        public string ExternalId
        {
            get
            {
                return this.externalIdField;
            }
            set
            {
                this.externalIdField = value;
            }
        }
    }




    /// <summary>
    /// Contract defines billing settings for work orders.
    /// Table [WOCostDefaultObject].
    /// Web service access scope - read only.
    /// Contract.DisplayAs Max Length=128
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Contract : SimpleLookupCorrigoEntity
    {
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Contract))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public abstract partial class SimpleLookupCorrigoEntity : CorrigoEntity
    {

        private string displayAsField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }
    }

    /// <summary>
    /// Represents the abstract base class for all CorrigoNet entity classes.
    /// </summary>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ContactAddress))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PunchListMasterNote))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ToDoItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorrigoEntityWithComposedIdOfAssetTreeEntitySpecifierInvTree))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AssetTree))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorrigoEntityWithComposedIdOfGLAccountEntitySpecifierGlAccount))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GLAccount))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoAssignment))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoNote))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoActionLogProp))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoActionLog))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoLastAction))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorrigoEntityWithComposedIdOfBlobEntitySpecifierBlob))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Blob))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Product))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoPriority))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PunchListMasterItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkCustomerAndGroup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorrigoEntityWithComposedIdOfActorEntitySpecifierActor))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Actor))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Note))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AssetInfo))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Location))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(SimpleLookupCorrigoEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Contract))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WorkZoneDetails))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkContactAndGroup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Contact))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Address))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(EmployeeBridgeCorrigoEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndPortfolio))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndWorkZone))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkProviderAndService))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndCustomerGroup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndSpecialty))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndStockLocation))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndTeam))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkEmployeeAndOrganization))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CustomField2))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorrigoEntityWithOptimisticLock))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WpTree))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PriceListItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Payment))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PaymentItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoEstimate))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoOnSite))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoQuote))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoVerification))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(DocumentType))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Document))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoPunchListItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoEquipment))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Invoice))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(FinancialItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WorkOrderCost))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WorkOrder))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(InvoiceLine))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(TaxRegionItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(SimpleLookupWithOptimisticLockCorrigoEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(TaxRegion))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Community))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorporateEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LookupCorrigoEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ChargeCodeLookup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(InvoiceDictionaryItem))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AlertScope))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CorrigoEntityWithComposedIdAndOptimisticLockOfAlertSubscriptionEntitySpecifierAlertSubscription))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AlertSubscription))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(UserPayRate))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Address2))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ContactInfo))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkProviderPriceList))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PriceList))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Role))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CustomFieldOption))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(RemovableCorrigoEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AttributeDescriptor))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Model))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PunchListMaster))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Task))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Disposition))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(TimePeriod))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoActionReasonLookup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CustomerNoteType))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Space))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Customer))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(RepairCode))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WorkOrderType))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Specialty))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(RemovableWithOriginalCorrigoEntity))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(BillingAccount))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LaborCode))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Employee))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(TaxCode))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CustomFieldDescriptor))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CustomField))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(Organization))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public abstract partial class CorrigoEntity
    {

        private int idField;

        private bool performDeletionField;

        /// <summary>
        /// Gets or sets a Corrigo entity identifier.
        /// </summary>
        public int Id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <summary>
        /// Gets or sets the boolean value indicating is an entity should be deleted.
        /// </summary>
        public bool PerformDeletion
        {
            get
            {
                return this.performDeletionField;
            }
            set
            {
                this.performDeletionField = value;
            }
        }
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class ContactAddress : CorrigoEntity
    {

        private ContactAddrType typeIdField;

        private string addressField;

        private bool isDefaultField;

        private bool isAlertField;

        private bool isLockedField;

        private bool isReportField;

        /// <remarks/>
        public ContactAddrType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <remarks/>
        public string Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <remarks/>
        public bool IsDefault
        {
            get
            {
                return this.isDefaultField;
            }
            set
            {
                this.isDefaultField = value;
            }
        }

        /// <remarks/>
        public bool IsAlert
        {
            get
            {
                return this.isAlertField;
            }
            set
            {
                this.isAlertField = value;
            }
        }

        /// <remarks/>
        public bool IsLocked
        {
            get
            {
                return this.isLockedField;
            }
            set
            {
                this.isLockedField = value;
            }
        }

        /// <remarks/>
        public bool IsReport
        {
            get
            {
                return this.isReportField;
            }
            set
            {
                this.isReportField = value;
            }
        }
    }




    /// <summary>
    /// Represents Punch List exception notes.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PunchListMasterNote : CorrigoEntity
    {

        private string displayAsField;

        private int idxField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public int Idx
        {
            get
            {
                return this.idxField;
            }
            set
            {
                this.idxField = value;
            }
        }
    }

    /// <summary>
    /// To-do Item represents abstract task with due date, short description and simple status (done/not done) which CorrigoNet user must do. 
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class ToDoItem : CorrigoEntity
    {

        private int actorIdField;

        private ActorType actorTypeIdField;

        private System.Nullable<System.DateTime> dtUtcDueField;

        private bool doneField;

        private string descriptionField;

        private string commentsField;

        private int employeeIdField;

        private int createdEmployeeIdField;

        private int completedEmployeeIdField;

        private System.Nullable<System.DateTime> dtUtcCompletedField;

        /// <summary>
        /// Standard link to parent object along with ActorTypeID
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Standard link to parent object along with ActorId
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// Due date
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtUtcDue
        {
            get
            {
                return this.dtUtcDueField;
            }
            set
            {
                this.dtUtcDueField = value;
            }
        }

        /// <summary>
        /// True means item is done/completed
        /// </summary>
        public bool Done
        {
            get
            {
                return this.doneField;
            }
            set
            {
                this.doneField = value;
            }
        }

        /// <summary>
        /// Description, required.
        /// </summary>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string Comments
        {
            get
            {
                return this.commentsField;
            }
            set
            {
                this.commentsField = value;
            }
        }

        /// <summary>
        /// Assigned Employee; references EmployeeObject.ID, optional.
        /// </summary>
        public int EmployeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }

        /// <summary>
        /// Employee who created item, references EmployeeObject.ID. This field equals to NULL if item was created as part of WO creation or escalation workflow.
        /// </summary>
        public int CreatedEmployeeId
        {
            get
            {
                return this.createdEmployeeIdField;
            }
            set
            {
                this.createdEmployeeIdField = value;
            }
        }

        /// <summary>
        /// When item is done, this field may contain ID of the Employee who completed item. References EmployeeObject.ID.
        /// </summary>
        public int CompletedEmployeeId
        {
            get
            {
                return this.completedEmployeeIdField;
            }
            set
            {
                this.completedEmployeeIdField = value;
            }
        }

        /// <summary>
        /// When item is done, this field contains UTC timestamp of the completion event.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtUtcCompleted
        {
            get
            {
                return this.dtUtcCompletedField;
            }
            set
            {
                this.dtUtcCompletedField = value;
            }
        }
    }

    /// <summary>
    /// Exposed as integration entity: AssetTree. This is read-only entity. It�s used mostly for data retrieval. Asset Tree hierarchy is not expected to be modified directly.
    /// AssetTree stores asset hierarchy relations - all "parent->child" and "parent->..->"descendant relations. It's used for quick search through hierarchy.
    /// Table [InvTreeObject].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class AssetTree : CorrigoEntityWithComposedIdOfAssetTreeEntitySpecifierInvTree
    {

        private int parentIdField;

        private int childIdField;

        private Location childField;

        private byte distanceField;

        /// <summary>
        /// Parent Id of <see cref="Location"/>(Asset)
        /// </summary>
        public int ParentId
        {
            get
            {
                return this.parentIdField;
            }
            set
            {
                this.parentIdField = value;
            }
        }

        /// <summary>
        /// Child Id of <see cref="Location"/>(Asset)
        /// </summary>
        public int ChildId
        {
            get
            {
                return this.childIdField;
            }
            set
            {
                this.childIdField = value;
            }
        }

        /// <summary>
        /// Child <see cref="Location"/>(Asset)
        /// </summary>
        public Location Child
        {
            get
            {
                return this.childField;
            }
            set
            {
                this.childField = value;
            }
        }

        /// <summary>
        /// Tells how deep Child asset is situated relative to Parent(ParentId)
        /// </summary>
        public byte Distance
        {
            get
            {
                return this.distanceField;
            }
            set
            {
                this.distanceField = value;
            }
        }
    }

    /// <summary>
    /// Represents location, an asset of any type.
    /// Table [InvItemObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Location : CorrigoEntity
    {

        private string nameField;

        private Address2 addressField;

        private int modelIdField;

        private bool orphanField;

        private AssetType typeIdField;

        private int parentIdField;

        private int rootIdField;

        private bool isTemplateField;

        private AssetInfo infoField;

        /// <summary>
        /// Gets a location name.
        /// Max Length=64.
        /// Is required.
        /// </summary>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <summary>
        /// Gets a location address.
        /// Is required.
        /// </summary>
        public Address2 Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <summary>
        /// Model Id.
        /// Is required.
        /// </summary>
        public int ModelId
        {
            get
            {
                return this.modelIdField;
            }
            set
            {
                this.modelIdField = value;
            }
        }

        /// <summary>
        /// True means Asset is orphaned.
        /// Is required.
        /// </summary>
        public bool Orphan
        {
            get
            {
                return this.orphanField;
            }
            set
            {
                this.orphanField = value;
            }
        }

        /// <summary>
        /// Asset Category:
        /// Unknown, Regular, Building, Unit, Community, RoomArea, Floor, Utility, Equipment.
        /// Is required.
        /// </summary>	
        public AssetType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <summary>
        /// �Fake� field without underlying table field; used only in insert/update operations.
        /// Can�t be used in query conditions and can�t be retrieved.
        /// Is required.
        /// </summary>
        public int ParentId
        {
            get
            {
                return this.parentIdField;
            }
            set
            {
                this.parentIdField = value;
            }
        }


        /// <summary>
        /// �Fake� field without underlying table field; used only in insert operations.
        /// Can�t be used in query conditions and can�t be retrieved.
        /// Is required.
        /// </summary>
        public int RootId
        {
            get
            {
                return this.rootIdField;
            }
            set
            {
                this.rootIdField = value;
            }
        }

        /// <summary>
        /// �Fake� field without underlying table field; used only in insert/update/delete operations.
        /// �True� when asset is a part of template hierarchy - not real work zone asset.
        /// Is required.
        /// </summary>
        public bool IsTemplate
        {
            get
            {
                return this.isTemplateField;
            }
            set
            {
                this.isTemplateField = value;
            }
        }

        /// <summary>
        ///  Asset additional info.
        /// </summary>
        public AssetInfo Info
        {
            get
            {
                return this.infoField;
            }
            set
            {
                this.infoField = value;
            }
        }
    }

    /// <summary>
    /// Street address integration entity.
    /// It can only exist as a part of some object, like Customer, Location, Employee.
    /// Table [AddrObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Address2 : CorrigoEntityWithOptimisticLock
    {

        private ActorType actorTypeIdField;

        private int actorIdField;

        private StreetAddrType typeIdField;

        private string streetField;

        private string street2Field;

        private string cityField;

        private string stateField;

        private string zipField;

        private string countryField;

        private bool isGeoFailedField;

        private double latitudeField;

        private double longitudeField;

        /// <summary>
        /// Actor Type of the parent object.
        /// Is required.
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// ID of the parent object.
        /// Is required.
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Type of the address (CLookup records of type 'SADT'). Unknown, Primary or Home.
        /// Is required.
        /// </summary>
        public StreetAddrType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <summary>
        /// Street name.
        /// Max Length=128.
        /// Is required.
        /// </summary>
        public string Street
        {
            get
            {
                return this.streetField;
            }
            set
            {
                this.streetField = value;
            }
        }

        /// <summary>
        /// Street name (extension).
        /// Max Length=128
        /// </summary>
        public string Street2
        {
            get
            {
                return this.street2Field;
            }
            set
            {
                this.street2Field = value;
            }
        }


        /// <summary>
        /// City name.
        /// Max Length=40
        /// </summary>
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <summary>
        /// State abbreviation. 
        /// Max Length=2
        /// </summary>
        public string State
        {
            get
            {
                return this.stateField;
            }
            set
            {
                this.stateField = value;
            }
        }

        /// <summary>
        /// ZIP code. 
        /// Max Length=10
        /// </summary>
        public string Zip
        {
            get
            {
                return this.zipField;
            }
            set
            {
                this.zipField = value;
            }
        }

        /// <summary>
        /// Country abbreviation. 
        /// Max Length=2
        /// </summary>
        public string Country
        {
            get
            {
                return this.countryField;
            }
            set
            {
                this.countryField = value;
            }
        }

        /// <remarks/>
        public bool IsGeoFailed
        {
            get
            {
                return this.isGeoFailedField;
            }
            set
            {
                this.isGeoFailedField = value;
            }
        }

        /// <summary>
        /// Location�s latitude 
        /// </summary>
        public double Latitude
        {
            get
            {
                return this.latitudeField;
            }
            set
            {
                this.latitudeField = value;
            }
        }

        /// <summary>
        /// Location�s longitude
        /// </summary>
        public double Longitude
        {
            get
            {
                return this.longitudeField;
            }
            set
            {
                this.longitudeField = value;
            }
        }
    }

    /// <summary>
    /// Work Plan Links records define hierarchical structure called Work Plan. 
    /// The idea behind Work Plan is that Work Orders may have child and grandchild Work Orders 
    /// (no more than 2 levels of hierarchy though); 
    /// such hierarchical structure is used to execute projects requiring different assignees with different billing, 
    /// multiple quotes etc.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WpTree : CorrigoEntityWithOptimisticLock
    {

        private int childWoIdField;

        private WorkOrder dependOnWorkOrderField;

        private int levelField;

        private int numberField;

        private WorkOrder parentWorkOrderField;

        private WorkOrder rootWorkOrderField;

        /// <summary>
        ///	ID of the Work Order participating in Work Plan. This field is unique for all WPTreeObject table; references WorkOrder2Object.ID.
        /// </summary>
        public int ChildWoId
        {
            get
            {
                return this.childWoIdField;
            }
            set
            {
                this.childWoIdField = value;
            }
        }

        /// <summary>
        /// Peer sibling WO on which WO defined by cWOID depends; NULL means no dependency. References WorkOrder2Object.ID.
        /// </summary>
        public WorkOrder DependOnWorkOrder
        {
            get
            {
                return this.dependOnWorkOrderField;
            }
            set
            {
                this.dependOnWorkOrderField = value;
            }
        }

        /// <summary>
        ///This field tells on which level of Work Plan WO defined by cWOID is placed. Only values 0, 1 and 2 are allowed: 0 means cWOID is the root (in this case RootWOID == cWOID); 1 means it�s a child; 2 means it�s a grandchild. References WorkOrder2Object.ID.
        /// </summary>
        public int Level
        {
            get
            {
                return this.levelField;
            }
            set
            {
                this.levelField = value;
            }
        }

        /// <summary>
        ///Numeric suffix used to build WO number for WO defined by cWOID. If cWOID is root this field is zero. Allowed values are 0 � 100, which means single parent cannot have more than 100 children.
        /// </summary>
        public int Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <summary>
        ///	Immediate parent of the Work Order defined by cWOID; references WorkOrder2Object.ID. If cWOID is root, pWOID == cWOID.
        /// </summary>
        public WorkOrder ParentWorkOrder
        {
            get
            {
                return this.parentWorkOrderField;
            }
            set
            {
                this.parentWorkOrderField = value;
            }
        }

        /// <summary>
        ///	Root of the Work Plan; references WorkOrder2Object.ID.
        /// </summary>
        public WorkOrder RootWorkOrder
        {
            get
            {
                return this.rootWorkOrderField;
            }
            set
            {
                this.rootWorkOrderField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PriceListItem : CorrigoEntityWithOptimisticLock
    {

        private decimal vendorRateField;

        private string descriptionField;

        private RateType rateTypeField;

        private VendorType vendorTypeField;

        private int priceListIdField;

        private decimal rateField;

        private InvoiceDictionaryItem invoiceItemField;

        /// <remarks/>
        public decimal VendorRate
        {
            get
            {
                return this.vendorRateField;
            }
            set
            {
                this.vendorRateField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public RateType RateType
        {
            get
            {
                return this.rateTypeField;
            }
            set
            {
                this.rateTypeField = value;
            }
        }

        /// <remarks/>
        public VendorType VendorType
        {
            get
            {
                return this.vendorTypeField;
            }
            set
            {
                this.vendorTypeField = value;
            }
        }

        /// <remarks/>
        public int PriceListId
        {
            get
            {
                return this.priceListIdField;
            }
            set
            {
                this.priceListIdField = value;
            }
        }

        /// <remarks/>
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }

        /// <remarks/>
        public InvoiceDictionaryItem InvoiceItem
        {
            get
            {
                return this.invoiceItemField;
            }
            set
            {
                this.invoiceItemField = value;
            }
        }
    }







    /// <summary>
    /// Represents invoice dictionary item.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class InvoiceDictionaryItem : LookupCorrigoEntity
    {

        private string descrField;

        private TaxCode taxCodeField;

        private CostCategory costCategoryField;

        private string glExpenseField;

        private string glIncomeField;

        ///<summary>
        /// Gets or sets a description, this field is optional
        ///</summary>
        public string Descr
        {
            get
            {
                return this.descrField;
            }
            set
            {
                this.descrField = value;
            }
        }

        ///<summary>
        /// Gets or sets a tax code object
        ///</summary>
        public TaxCode TaxCode
        {
            get
            {
                return this.taxCodeField;
            }
            set
            {
                this.taxCodeField = value;
            }
        }

        ///<summary>
        /// Gest or sets a cost category
        ///</summary>
        public CostCategory CostCategory
        {
            get
            {
                return this.costCategoryField;
            }
            set
            {
                this.costCategoryField = value;
            }
        }

        ///<summary>
        /// Gets or sets GL expense code, this field is optional
        ///</summary>
        public string GlExpense
        {
            get
            {
                return this.glExpenseField;
            }
            set
            {
                this.glExpenseField = value;
            }
        }

        ///<summary>
        /// Gets or sets GL expense code, this field is optional
        ///</summary>
        public string GlIncome
        {
            get
            {
                return this.glIncomeField;
            }
            set
            {
                this.glIncomeField = value;
            }
        }
    }

    /// <summary>
    /// Represents tax code
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class TaxCode : RemovableCorrigoEntity
    {

        private string displayAsField;

        private string extIdField;

        private string descrField;

        /// <summary>
        /// Displayable name.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        ///<summary>
        /// Gets or sets a external ID (used to communicate with third-party tax service)
        ///</summary>
        public string ExtId
        {
            get
            {
                return this.extIdField;
            }
            set
            {
                this.extIdField = value;
            }
        }

        ///<summary>
        /// Gets or sets a description, this field is optional
        ///</summary>
        public string Descr
        {
            get
            {
                return this.descrField;
            }
            set
            {
                this.descrField = value;
            }
        }
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Model : RemovableCorrigoEntity
    {

        private string displayAsField;

        private string descriptionField;

        private AssetType assetCategoryIdField;

        private bool publicField;

        private char subComponentIdxField;

        private string glAccountField;

        private string instructionsField;

        private Task[] tasksField;

        private string numberField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public AssetType AssetCategoryId
        {
            get
            {
                return this.assetCategoryIdField;
            }
            set
            {
                this.assetCategoryIdField = value;
            }
        }

        /// <remarks/>
        public bool Public
        {
            get
            {
                return this.publicField;
            }
            set
            {
                this.publicField = value;
            }
        }

        /// <remarks/>
        public char SubComponentIdx
        {
            get
            {
                return this.subComponentIdxField;
            }
            set
            {
                this.subComponentIdxField = value;
            }
        }

        /// <remarks/>
        public string GlAccount
        {
            get
            {
                return this.glAccountField;
            }
            set
            {
                this.glAccountField = value;
            }
        }

        /// <remarks/>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }

        /// <remarks/>
        public Task[] Tasks
        {
            get
            {
                return this.tasksField;
            }
            set
            {
                this.tasksField = value;
            }
        }

        /// <remarks/>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }
    }




    /// <summary>
    /// Represents Kb Task, the action to be completed in satisfying the work order.
    /// Table [kbTaskObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Task : RemovableCorrigoEntity
    {

        private int modelIdField;

        private string displayAsField;

        private bool preventiveField;

        private bool routineField;

        private bool correctiveField;

        private bool defaultField;

        private bool symptomField;

        private int completionTimeField;

        private Specialty specialtyField;

        private PunchListMaster punchListField;

        private WoPriority priorityField;

        private System.Nullable<TaskSelfHelpType> selfHelpTypeField;

        private string instructionsField;

        private string selfHelpContentField;

        private int peopleRequiredField;

        private int skillLevelField;

        private decimal nteField;

        private string glAccountField;

        private string numberField;

        /// <summary>
        /// Asset model which supports this task.
        /// Is required.
        /// </summary>
        public int ModelId
        {
            get
            {
                return this.modelIdField;
            }
            set
            {
                this.modelIdField = value;
            }
        }

        /// <summary>
        /// Task name for UI.
        /// Max Length=400.
        /// Is required.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// "True" for preventative task.
        /// Is required.
        /// </summary>
        public bool Preventive
        {
            get
            {
                return this.preventiveField;
            }
            set
            {
                this.preventiveField = value;
            }
        }

        /// <summary>
        /// "True" for routine task.
        /// Is required.
        /// </summary>
        public bool Routine
        {
            get
            {
                return this.routineField;
            }
            set
            {
                this.routineField = value;
            }
        }

        /// <summary>
        /// "True" for corrective task.
        /// Is required.
        /// </summary>
        public bool Corrective
        {
            get
            {
                return this.correctiveField;
            }
            set
            {
                this.correctiveField = value;
            }
        }

        /// <summary>
        /// "True" if this is default Asset�s(its Model�s) task in work order.
        /// Is required.
        /// </summary>
        public bool Default
        {
            get
            {
                return this.defaultField;
            }
            set
            {
                this.defaultField = value;
            }
        }

        /// <summary>
        /// "True" for symptom task.
        /// Is required.
        public bool Symptom
        {
            get
            {
                return this.symptomField;
            }
            set
            {
                this.symptomField = value;
            }
        }

        /// <summary>
        /// Time to complete task in minutes, supported values 0-599999.
        /// Is required.
        /// </summary>
        public int CompletionTime
        {
            get
            {
                return this.completionTimeField;
            }
            set
            {
                this.completionTimeField = value;
            }
        }

        /// <summary>
        /// Specialty that is needed to resolve that task - used for work order employee assignment.
        /// </summary>
        public Specialty Specialty
        {
            get
            {
                return this.specialtyField;
            }
            set
            {
                this.specialtyField = value;
            }
        }

        /// <summary>
        /// The 9x list of points to check when task is performed.
        /// </summary>
        public PunchListMaster PunchList
        {
            get
            {
                return this.punchListField;
            }
            set
            {
                this.punchListField = value;
            }
        }

        /// <summary>
        /// Priority associated with Task - set to work order priority when created.
        /// Is required.
        /// </summary>
        public WoPriority Priority
        {
            get
            {
                return this.priorityField;
            }
            set
            {
                this.priorityField = value;
            }
        }

        /// <summary>
        /// Instructions format: Html, Hyperlink, YouTube      
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<TaskSelfHelpType> SelfHelpType
        {
            get
            {
                return this.selfHelpTypeField;
            }
            set
            {
                this.selfHelpTypeField = value;
            }
        }

        /// <summary>
        /// Set of instructions for a task.
        /// Max Length=Nvarchar(max)
        /// </summary>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }

        /// <summary>
        /// Links to auxilary information in different format.
        /// Max Length=2048
        /// </summary>
        public string SelfHelpContent
        {
            get
            {
                return this.selfHelpContentField;
            }
            set
            {
                this.selfHelpContentField = value;
            }
        }

        /// <summary>
        /// Number of employees required.
        /// </summary>
        public int PeopleRequired
        {
            get
            {
                return this.peopleRequiredField;
            }
            set
            {
                this.peopleRequiredField = value;
            }
        }

        /// <summary>
        /// Necessary skill level.
        /// </summary>
        public int SkillLevel
        {
            get
            {
                return this.skillLevelField;
            }
            set
            {
                this.skillLevelField = value;
            }
        }

        /// <summary>
        /// Task max price limit - Not to exceed amount.
        /// </summary>
        public decimal Nte
        {
            get
            {
                return this.nteField;
            }
            set
            {
                this.nteField = value;
            }
        }

        /// <summary>
        /// GL Account number.
        /// Max Length=32
        /// </summary>
        public string GlAccount
        {
            get
            {
                return this.glAccountField;
            }
            set
            {
                this.glAccountField = value;
            }
        }

        /// <summary>
        /// External number.
        /// Might be provided by integration; also used by WON (Work Order Network).
        /// Max Length=64
        /// </summary>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }
    }

    /// <summary>
    /// Specialty, f.i. Carpentry, Doors, Electrical, Lighting, Plumbing...
    /// This entity answers the question �What type of work needs to be done for a Work Order or a Task?".
    /// Table [SpecialtyObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Specialty : RemovableCorrigoEntity
    {

        private string displayAsField;

        private int wONServiceIdField;

        private decimal nteField;

        private decimal avgCostVendorField;

        private decimal avgCostTechField;

        private decimal avgCostAllField;

        private string instructionsField;

        private TaxCode taxCodeField;

        /// <summary>
        /// The name of the Specialty.
        /// Max Length=40.
        /// Is required.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// Related to WON (Work Order Network) Service
        /// </summary>
        public int WONServiceId
        {
            get
            {
                return this.wONServiceIdField;
            }
            set
            {
                this.wONServiceIdField = value;
            }
        }

        /// <summary>
        /// Not to Exceed : approval must not be higher than this value.
        /// </summary>
        public decimal Nte
        {
            get
            {
                return this.nteField;
            }
            set
            {
                this.nteField = value;
            }
        }

        /// <summary>
        /// Vendor Average Cost.
        /// </summary>
        public decimal AvgCostVendor
        {
            get
            {
                return this.avgCostVendorField;
            }
            set
            {
                this.avgCostVendorField = value;
            }
        }

        /// <summary>
        /// Technician Average Cost.
        /// </summary>
        public decimal AvgCostTech
        {
            get
            {
                return this.avgCostTechField;
            }
            set
            {
                this.avgCostTechField = value;
            }
        }

        /// <summary>
        /// Total Average Cost.
        /// </summary>
        public decimal AvgCostAll
        {
            get
            {
                return this.avgCostAllField;
            }
            set
            {
                this.avgCostAllField = value;
            }
        }

        /// <summary>
        /// Service instructions to relay to team members; HTML content supported.
        /// Max Length=3072.
        /// </summary>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }


        /// <summary>
        /// Labor Tax Code.
        /// </summary>
        public TaxCode TaxCode
        {
            get
            {
                return this.taxCodeField;
            }
            set
            {
                this.taxCodeField = value;
            }
        }
    }

    /// <summary>
    /// Represents Punch List Template.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PunchListMaster : RemovableCorrigoEntity
    {

        private string displayAsField;

        private Community communityField;

        private System.DateTime dtUpdatedField;

        private Actor updatedByField;

        private PunchListMasterItem[] tasksField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public Community Community
        {
            get
            {
                return this.communityField;
            }
            set
            {
                this.communityField = value;
            }
        }

        /// <remarks/>
        public System.DateTime DtUpdated
        {
            get
            {
                return this.dtUpdatedField;
            }
            set
            {
                this.dtUpdatedField = value;
            }
        }

        /// <remarks/>
        public Actor UpdatedBy
        {
            get
            {
                return this.updatedByField;
            }
            set
            {
                this.updatedByField = value;
            }
        }

        /// <remarks/>
        public PunchListMasterItem[] Tasks
        {
            get
            {
                return this.tasksField;
            }
            set
            {
                this.tasksField = value;
            }
        }
    }

    /// <summary>
    ///  In CorrigoNet, Work Zone is a grouping or parent entity for Customers, Work Orders and Assets.
    ///  Table [CommunityObject].
    ///  Web service access scope - Read only
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Community : CorrigoEntityWithOptimisticLock
    {

        private string displayAsField;

        private int assetIdField;

        private int timeZoneField;

        private WorkZoneDetails detailsField;

        /// <summary>
        ///  Name.
        ///  Max Length=50.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        ///  Name.
        ///  Max Length=50.
        /// </summary>
        public int AssetId
        {
            get
            {
                return this.assetIdField;
            }
            set
            {
                this.assetIdField = value;
            }
        }

        /// <remarks/>
        public int TimeZone
        {
            get
            {
                return this.timeZoneField;
            }
            set
            {
                this.timeZoneField = value;
            }
        }

        /// <remarks/>
        public WorkZoneDetails Details
        {
            get
            {
                return this.detailsField;
            }
            set
            {
                this.detailsField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WorkZoneDetails : CorrigoEntity
    {

        private int communityIdField;

        private string numberField;

        private Contract contractField;

        private TaxRegion taxRegionField;

        /// <remarks/>
        public int CommunityId
        {
            get
            {
                return this.communityIdField;
            }
            set
            {
                this.communityIdField = value;
            }
        }

        /// <remarks/>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        public Contract Contract
        {
            get
            {
                return this.contractField;
            }
            set
            {
                this.contractField = value;
            }
        }

        /// <remarks/>
        public TaxRegion TaxRegion
        {
            get
            {
                return this.taxRegionField;
            }
            set
            {
                this.taxRegionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class TaxRegion : SimpleLookupWithOptimisticLockCorrigoEntity
    {

        private TaxRegionItem[] itemsField;

        /// <remarks/>
        public TaxRegionItem[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class TaxRegionItem : CorrigoEntityWithOptimisticLock
    {

        private int taxRegionIdField;

        private TaxCode taxCodeField;

        private decimal taxRateField;

        /// <remarks/>
        public int TaxRegionId
        {
            get
            {
                return this.taxRegionIdField;
            }
            set
            {
                this.taxRegionIdField = value;
            }
        }

        /// <remarks/>
        public TaxCode TaxCode
        {
            get
            {
                return this.taxCodeField;
            }
            set
            {
                this.taxCodeField = value;
            }
        }

        /// <remarks/>
        public decimal TaxRate
        {
            get
            {
                return this.taxRateField;
            }
            set
            {
                this.taxRateField = value;
            }
        }
    }

    /// <summary>
    /// Actor describes what kind of entity can perform an action over WorkOrder in 9x.
    /// Table [Actors].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Actor : CorrigoEntityWithComposedIdOfActorEntitySpecifierActor
    {

        private ActorType typeIdField;

        private string displayAsField;


        /// <summary>
        /// Enumeration which defines type of object the Actor is (e.g. Employee)
        /// </summary>
        public ActorType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <summary>
        /// How an object is represented on UI.
        /// Max Length=256
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }
    }

    /// <summary>
    /// Defines the work order implementation time scope and the way employee is auto-assigned to the work order.
    /// Table [WOPriorityLookup].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoPriority : CorrigoEntity
    {

        private string displayAsField;

        private bool isEmergencyField;

        private int respondInHoursField;

        private int dueInHoursField;

        /// <summary>
        /// Label, unique value.
        /// Max Length=40.
        /// Is required.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// Escalate.
        /// Is required.
        /// </summary>
        public bool IsEmergency
        {
            get
            {
                return this.isEmergencyField;
            }
            set
            {
                this.isEmergencyField = value;
            }
        }

        /// <summary>
        /// Response hrs.
        /// Is required.
        /// </summary>
        public int RespondInHours
        {
            get
            {
                return this.respondInHoursField;
            }
            set
            {
                this.respondInHoursField = value;
            }
        }

        /// <summary>
        /// Complete hrs.
        /// Is required.
        /// </summary>
        public int DueInHours
        {
            get
            {
                return this.dueInHoursField;
            }
            set
            {
                this.dueInHoursField = value;
            }
        }
    }



    /// <summary>
    /// Represents Punch List task items.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PunchListMasterItem : CorrigoEntity
    {

        private string displayAsField;

        private int idxField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public int Idx
        {
            get
            {
                return this.idxField;
            }
            set
            {
                this.idxField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Disposition : RemovableCorrigoEntity
    {

        private string displayAsField;

        private bool isCompletedField;

        private bool isCancelledField;

        private bool onCreateField;

        private bool onCompleteField;

        private bool onCancelField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public bool IsCompleted
        {
            get
            {
                return this.isCompletedField;
            }
            set
            {
                this.isCompletedField = value;
            }
        }

        /// <remarks/>
        public bool IsCancelled
        {
            get
            {
                return this.isCancelledField;
            }
            set
            {
                this.isCancelledField = value;
            }
        }

        /// <remarks/>
        public bool OnCreate
        {
            get
            {
                return this.onCreateField;
            }
            set
            {
                this.onCreateField = value;
            }
        }

        /// <remarks/>
        public bool OnComplete
        {
            get
            {
                return this.onCompleteField;
            }
            set
            {
                this.onCompleteField = value;
            }
        }

        /// <remarks/>
        public bool OnCancel
        {
            get
            {
                return this.onCancelField;
            }
            set
            {
                this.onCancelField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class TimePeriod : RemovableCorrigoEntity
    {

        private string displayAsField;

        private System.DateTime startDateField;

        private System.DateTime endDateField;

        private System.Nullable<System.DateTime> dtStartField;

        private System.Nullable<System.DateTime> dtEndField;

        private bool isFinancialField;

        private bool isTimeField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public System.DateTime StartDate
        {
            get
            {
                return this.startDateField;
            }
            set
            {
                this.startDateField = value;
            }
        }

        /// <remarks/>
        public System.DateTime EndDate
        {
            get
            {
                return this.endDateField;
            }
            set
            {
                this.endDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> dtStart
        {
            get
            {
                return this.dtStartField;
            }
            set
            {
                this.dtStartField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> dtEnd
        {
            get
            {
                return this.dtEndField;
            }
            set
            {
                this.dtEndField = value;
            }
        }

        /// <remarks/>
        public bool IsFinancial
        {
            get
            {
                return this.isFinancialField;
            }
            set
            {
                this.isFinancialField = value;
            }
        }

        /// <remarks/>
        public bool IsTime
        {
            get
            {
                return this.isTimeField;
            }
            set
            {
                this.isTimeField = value;
            }
        }
    }

    /// <summary>
    /// The object allows to describe what was the reason of WorkOrder status change.
    /// Hence it�s created any time WorkOrder status is changed.
    /// Table [WOActionReasonLookup].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoActionReasonLookup : RemovableCorrigoEntity
    {

        private string displayAsField;

        private WOActionType actionIdField;

        private byte reasonIdField;

        private bool hideField;

        private string descrField;

        /// <summary>
        /// How the reason is represented in UI.
        /// Max Length=128
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// Enumeration which describes an action had been taken over the WorkOrder.
        /// </summary>
        public WOActionType ActionId
        {
            get
            {
                return this.actionIdField;
            }
            set
            {
                this.actionIdField = value;
            }
        }

        /// <summary>
        /// Link to reason object, unique within WO Action.
        /// </summary>
        public byte ReasonId
        {
            get
            {
                return this.reasonIdField;
            }
            set
            {
                this.reasonIdField = value;
            }
        }

        /// <summary>
        /// Flag to decide whether the object is shown on UI.
        /// </summary>
        public bool Hide
        {
            get
            {
                return this.hideField;
            }
            set
            {
                this.hideField = value;
            }
        }

        /// <summary>
        /// Comment for the action reason.
        /// Max Length=256
        /// </summary>
        public string Descr
        {
            get
            {
                return this.descrField;
            }
            set
            {
                this.descrField = value;
            }
        }
    }




    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CustomerNoteType : RemovableCorrigoEntity
    {

        private string displayAsField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }
    }

    /// <summary>
    /// Space (sometimes called Location) is occupancy record connecting Customer and Unit.
    /// Table [lnklsUnitLeaseObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Space : RemovableCorrigoEntity
    {

        private int customerIdField;

        private Location assetField;

        private System.Nullable<System.DateTime> startDateField;

        private System.Nullable<System.DateTime> endDateField;

        private System.Nullable<System.DateTime> moveOutDateField;

        private Community communityField;

        private LeasingSpaceStatus statusIdField;

        private Address2[] addressesField;

        private string instructionsField;

        /// <summary>
        /// Customer Id.
        /// Is required.
        /// </summary>
        public int CustomerId
        {
            get
            {
                return this.customerIdField;
            }
            set
            {
                this.customerIdField = value;
            }
        }

        /// <summary>
        /// Unit Asset occupied by Customer.
        /// Is required.
        /// </summary>
        public Location Asset
        {
            get
            {
                return this.assetField;
            }
            set
            {
                this.assetField = value;
            }
        }

        /// <summary>
        /// Start date of lease.
        /// Is required.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> StartDate
        {
            get
            {
                return this.startDateField;
            }
            set
            {
                this.startDateField = value;
            }
        }

        /// <summary>
        /// End date of lease.
        /// Is required.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> EndDate
        {
            get
            {
                return this.endDateField;
            }
            set
            {
                this.endDateField = value;
            }
        }

        /// <summary>
        /// Date of expected or actual Move Out date.
        /// Is required.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> MoveOutDate
        {
            get
            {
                return this.moveOutDateField;
            }
            set
            {
                this.moveOutDateField = value;
            }
        }

        /// <summary>
        /// Space work zone - taken from customer.
        /// Is required.
        /// </summary>
        public Community Community
        {
            get
            {
                return this.communityField;
            }
            set
            {
                this.communityField = value;
            }
        }

        /// <summary>
        /// Unknown, Historical, Current, OnNotice, Pending.
        /// Is required.
        /// </summary>
        public LeasingSpaceStatus StatusId
        {
            get
            {
                return this.statusIdField;
            }
            set
            {
                this.statusIdField = value;
            }
        }

        /// <summary>
        /// One address from unit asset(Asset).
        /// Is required.
        /// </summary>
        public Address2[] Addresses
        {
            get
            {
                return this.addressesField;
            }
            set
            {
                this.addressesField = value;
            }
        }

        /// <summary>
        /// Space instructions.
        /// Max Length=256.
        /// </summary>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }
    }



    /// <summary>
    /// Represents customer, a client that makes service orders.
    /// Customer is required to be in some work zone.
    /// Table [lsLeaseObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Customer : RemovableCorrigoEntity
    {

        private string displayAsField;

        private string nameField;

        private Community communityField;

        private string dbaField;

        private string instructionsField;

        private string tenantCodeField;

        private bool taxExemptField;

        private Space[] spacesField;

        private Contact[] contactsField;

        private CustomField2[] customFieldsField;

        private Note[] notesField;

        private Address2[] addressesField;

        private Contract contractField;

        private LinkCustomerAndGroup[] groupsBridgeField;

        ///<summary>
        /// Gets a display as value.
        /// Max Length=64.
        /// Is required.
        ///</summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        ///<summary>
        /// Customer's name.
        /// Max Length=64.
        /// Is required.
        ///</summary>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <summary>
        /// Community, the Work Zone to which Customer belongs.
        /// Is required.
        /// </summary>
        public Community Community
        {
            get
            {
                return this.communityField;
            }
            set
            {
                this.communityField = value;
            }
        }

        ///<summary>
        /// Gets a DBA (Doing business as) value.
        /// Max Length=64.
        /// Is required.
        ///</summary>
        public string Dba
        {
            get
            {
                return this.dbaField;
            }
            set
            {
                this.dbaField = value;
            }
        }

        ///<summary>
        /// Service instructions to relay to team members who are visiting this customer,
        /// HTML content supported.
        /// Max Length=3072.
        ///</summary>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }

        ///<summary>
        /// Gets a tenant code - unique number, usually used to map customer to external system.
        /// Max Length=64.
        /// Is required.
        ///</summary>
        public string TenantCode
        {
            get
            {
                return this.tenantCodeField;
            }
            set
            {
                this.tenantCodeField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this customer can be defined as tax exemption,
        /// True means Customer doesn�t pay sales taxes (used by Customer Invoices).
        /// Is required.
        /// </summary>
        public bool TaxExempt
        {
            get
            {
                return this.taxExemptField;
            }
            set
            {
                this.taxExemptField = value;
            }
        }

        /// <summary>
        /// Spaces. Space (sometimes called Location) is occupancy record connecting Customer and Unit.
        /// Space means that Customer occupies particular Unit Asset. 
        /// </summary>
        public Space[] Spaces
        {
            get
            {
                return this.spacesField;
            }
            set
            {
                this.spacesField = value;
            }
        }

        /// <summary>
        /// Contacts are persons who are working for Customer and who actively participate in Work Order lifecycle.
        /// Is required.
        /// </summary>
        public Contact[] Contacts
        {
            get
            {
                return this.contactsField;
            }
            set
            {
                this.contactsField = value;
            }
        }

        /// <summary>
        /// Custom Fields
        /// </summary>
        public CustomField2[] CustomFields
        {
            get
            {
                return this.customFieldsField;
            }
            set
            {
                this.customFieldsField = value;
            }
        }

        /// <summary>
        /// Notes
        /// </summary>
        public Note[] Notes
        {
            get
            {
                return this.notesField;
            }
            set
            {
                this.notesField = value;
            }
        }

        /// <summary>
        /// Zero or one Street Address.
        /// Is required.
        /// </summary>
        public Address2[] Addresses
        {
            get
            {
                return this.addressesField;
            }
            set
            {
                this.addressesField = value;
            }
        }

        /// <summary>
        /// Default Financial contract assigned when work order is created for this customer,
        /// if it�s not defined - the work zone contract will be used.
        /// Contract affects costs, vendor invoice/WON, charges etc.
        /// </summary>
        public Contract Contract
        {
            get
            {
                return this.contractField;
            }
            set
            {
                this.contractField = value;
            }
        }


        /// <summary>
        /// Customer Groups.
        /// Is required.
        /// </summary>
        public LinkCustomerAndGroup[] GroupsBridge
        {
            get
            {
                return this.groupsBridgeField;
            }
            set
            {
                this.groupsBridgeField = value;
            }
        }
    }

    /// <summary>
    /// Represents Contact.
    /// Defines information about customer�s contact person/organization.
    /// Table [lsAccessObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Contact : CorrigoEntity
    {

        private string displayAsField;

        private string firstNameField;

        private string lastNameField;

        private LeaseContactType typeIdField;

        private int customerIdField;

        private bool canViewAnyRequestField;

        private decimal authorizationLimitField;

        private bool canCreateRequestField;

        private decimal requestLimitField;

        private decimal notificationThresholdField;

        private int priorityThresholdField;

        private CustomField2[] customFieldsField;

        private ContactInfo[] contactAddressesField;

        private LinkContactAndGroup[] groupsBridgeField;

        private string usernameField;

        private string numberField;

        private bool mustResetPasswordField;

        private bool noAlertEmailsField;

        private string commentField;

        ///<summary>
        /// Gets or sets a display as value.
        /// Max Length=256.
        /// Is required.
        ///</summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        ///<summary>
        /// First Name.
        /// Max Length=50
        ///</summary>
        public string FirstName
        {
            get
            {
                return this.firstNameField;
            }
            set
            {
                this.firstNameField = value;
            }
        }

        ///<summary>
        /// Last Name.
        /// Max Length=50.
        /// Is required.
        ///</summary>
        public string LastName
        {
            get
            {
                return this.lastNameField;
            }
            set
            {
                this.lastNameField = value;
            }
        }

        ///<summary>
        /// Type: Unknown, Alternate, Emergency, Primary
        ///</summary>
        public LeaseContactType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        ///<summary>
        /// Customer Id.
        ///</summary>
        public int CustomerId
        {
            get
            {
                return this.customerIdField;
            }
            set
            {
                this.customerIdField = value;
            }
        }

        ///<summary>
        /// Flag to determine level of access.
        /// �True� allows authorization for other�s expense.
        /// No is only for contact�s own expenses.
        /// Default is �False�.
        ///</summary>
        public bool CanViewAnyRequest
        {
            get
            {
                return this.canViewAnyRequestField;
            }
            set
            {
                this.canViewAnyRequestField = value;
            }
        }

        ///<summary>
        /// Authorization Limit
        ///</summary>
        public decimal AuthorizationLimit
        {
            get
            {
                return this.authorizationLimitField;
            }
            set
            {
                this.authorizationLimitField = value;
            }
        }

        ///<summary>
        /// Allow Request Creation. Default is "True".
        ///</summary>
        public bool CanCreateRequest
        {
            get
            {
                return this.canCreateRequestField;
            }
            set
            {
                this.canCreateRequestField = value;
            }
        }

        ///<summary>
        /// Request Limit.
        ///</summary>
        public decimal RequestLimit
        {
            get
            {
                return this.requestLimitField;
            }
            set
            {
                this.requestLimitField = value;
            }
        }

        ///<summary>
        /// Notification threshold. Money.
        ///</summary>
        public decimal NotificationThreshold
        {
            get
            {
                return this.notificationThresholdField;
            }
            set
            {
                this.notificationThresholdField = value;
            }
        }

        ///<summary>
        /// Priority threshold.
        ///</summary>
        public int PriorityThreshold
        {
            get
            {
                return this.priorityThresholdField;
            }
            set
            {
                this.priorityThresholdField = value;
            }
        }

        ///<summary>
        /// Custom Fields.
        ///</summary>
        public CustomField2[] CustomFields
        {
            get
            {
                return this.customFieldsField;
            }
            set
            {
                this.customFieldsField = value;
            }
        }

        ///<summary>
        /// Phone, Email, other can be defined here.
        ///</summary>
        public ContactInfo[] ContactAddresses
        {
            get
            {
                return this.contactAddressesField;
            }
            set
            {
                this.contactAddressesField = value;
            }
        }

        ///<summary>
        /// Contact/Customer Group Bridge records.
        ///</summary>	
        public LinkContactAndGroup[] GroupsBridge
        {
            get
            {
                return this.groupsBridgeField;
            }
            set
            {
                this.groupsBridgeField = value;
            }
        }

        ///<summary>
        /// If using the Customer Portal, then this is the login id.
        /// The login must be unique amongst the user community.
        /// Suggest using their phone number, employee number or e-mail address.
        /// Max Length=64.
        /// Is required.
        ///</summary>	
        public string Username
        {
            get
            {
                return this.usernameField;
            }
            set
            {
                this.usernameField = value;
            }
        }

        ///<summary>
        /// Number which can be used as a unique identifier for integration purposes.
        /// Max Length=64.
        /// Is required.
        ///</summary>	
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        ///<summary>
        /// True in case user has to change password.
        ///</summary>	
        public bool MustResetPassword
        {
            get
            {
                return this.mustResetPasswordField;
            }
            set
            {
                this.mustResetPasswordField = value;
            }
        }

        ///<summary>
        /// Disable alert emails.
        ///</summary>
        public bool NoAlertEmails
        {
            get
            {
                return this.noAlertEmailsField;
            }
            set
            {
                this.noAlertEmailsField = value;
            }
        }

        ///<summary>
        /// Comments.
        /// Max Length=256.
        /// Is required.
        ///</summary>	
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }
    }



    /// <summary>
    /// Represents Custom Field (will replace CustomField).
    /// Used to store extended object field values.
    /// Table [cfValObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CustomField2 : CorrigoEntity
    {

        private CustomFieldDescriptor descriptorField;

        private int objectIdField;

        private ActorType objectTypeIdField;

        private string valueField;

        /// <summary>
        /// Gets custom field metadata.
        /// Is required.
        /// </summary>
        public CustomFieldDescriptor Descriptor
        {
            get
            {
                return this.descriptorField;
            }
            set
            {
                this.descriptorField = value;
            }
        }

        /// <summary>
        /// Parent Object ID.
        /// Is required.
        /// </summary>
        public int ObjectId
        {
            get
            {
                return this.objectIdField;
            }
            set
            {
                this.objectIdField = value;
            }
        }

        /// <summary>
        /// Parent Object Type ID.
        /// Is required.
        /// </summary>
        public ActorType ObjectTypeId
        {
            get
            {
                return this.objectTypeIdField;
            }
            set
            {
                this.objectTypeIdField = value;
            }
        }

        /// <summary>
        /// Gets Custom Field value.
        /// Max Length=1024.
        /// Is required.
        /// </summary>
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <summary>
    /// Represents custom field metadata.
    /// Table [cfDescrObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CustomFieldDescriptor : RemovableCorrigoEntity
    {

        private ActorType actorTypeIdField;

        private int lengthField;

        private CfType typeField;

        private string nameField;

        private CustomFieldOption[] optionsField;

        /// <summary>
        /// Custom field object type and field type.
        /// Is required.
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// Field length.
        /// Max value string length (if string type)
        /// </summary>
        public int Length
        {
            get
            {
                return this.lengthField;
            }
            set
            {
                this.lengthField = value;
            }
        }

        /// <summary>
        /// Field type : Unknown, String, Integer, Decimal, Money, Phone, Date, Time, Boolean, Url.
        /// Is required.
        /// </summary>
        public CfType Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <summary>
        /// Custom field name.
        /// Max Length=64.
        /// Is required.
        /// </summary>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <summary>
        /// A list of values that can be set in custom field - null for strings
        /// </summary>
        public CustomFieldOption[] Options
        {
            get
            {
                return this.optionsField;
            }
            set
            {
                this.optionsField = value;
            }
        }
    }









    /// <summary>
    ///  Pick list item (predefined value for custom field).
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CustomFieldOption : CorrigoEntityWithOptimisticLock
    {

        private int parentIdField;

        private int idxField;

        private string valueField;

        /// <remarks/>
        public int ParentId
        {
            get
            {
                return this.parentIdField;
            }
            set
            {
                this.parentIdField = value;
            }
        }

        /// <remarks/>
        public int Idx
        {
            get
            {
                return this.idxField;
            }
            set
            {
                this.idxField = value;
            }
        }

        /// <remarks/>
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }


    /// <summary>
    /// Contact address integration entity.
    /// Used to specify additional contact address parts.
    /// Table [CAddrObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class ContactInfo : CorrigoEntityWithOptimisticLock
    {

        private ActorType actorTypeIdField;

        private int actorIdField;

        private ContactAddrType addrTypeIdField;

        private string addressField;

        private bool isAlertField;

        private bool isReportField;

        /// <summary>
        /// Actor Type of the parent object : Customer, Employee, etc.
        /// Is required.
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// ID of the parent object.
        /// Is required.
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Contact Address Type Id.
        /// Is required.
        /// </summary>
        public ContactAddrType AddrTypeId
        {
            get
            {
                return this.addrTypeIdField;
            }
            set
            {
                this.addrTypeIdField = value;
            }
        }

        /// <summary>
        /// Contact address value.
        /// Max Length=512
        /// Is required.
        /// </summary>
        public string Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <summary>
        /// True means this contact address is suitable for sending alerts.
        /// </summary>
        public bool IsAlert
        {
            get
            {
                return this.isAlertField;
            }
            set
            {
                this.isAlertField = value;
            }
        }

        /// <summary>
        /// True means this contact address is suitable for sending report subscriptions.
        /// </summary>	
        public bool IsReport
        {
            get
            {
                return this.isReportField;
            }
            set
            {
                this.isReportField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkContactAndGroup : CorrigoEntity
    {

        private int contactIdField;

        private int customerGroupIdField;

        private bool isBillingContactField;

        /// <remarks/>
        public int ContactId
        {
            get
            {
                return this.contactIdField;
            }
            set
            {
                this.contactIdField = value;
            }
        }

        /// <remarks/>
        public int CustomerGroupId
        {
            get
            {
                return this.customerGroupIdField;
            }
            set
            {
                this.customerGroupIdField = value;
            }
        }

        /// <remarks/>
        public bool IsBillingContact
        {
            get
            {
                return this.isBillingContactField;
            }
            set
            {
                this.isBillingContactField = value;
            }
        }
    }

    /// <summary>
    /// Represents Customer Note
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Note : CorrigoEntity
    {

        private int actorIdField;

        private ActorType actorTypeIdField;

        private CustomerNoteType noteTypeLookupField;

        private bool isResolvedField;

        private System.DateTime createdAtField;

        private Actor createdByField;

        private System.Nullable<System.DateTime> updatedAtField;

        private Actor updatedByField;

        private string noteTextField;

        /// <summary>
        /// Parent Object ID
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Parent Object Type ID
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// Note type
        /// </summary>
        public CustomerNoteType NoteTypeLookup
        {
            get
            {
                return this.noteTypeLookupField;
            }
            set
            {
                this.noteTypeLookupField = value;
            }
        }

        /// <summary>
        /// True means Note was �resolved�
        /// </summary>
        public bool IsResolved
        {
            get
            {
                return this.isResolvedField;
            }
            set
            {
                this.isResolvedField = value;
            }
        }

        /// <summary>
        /// Local date/time when Note was created
        /// </summary>
        public System.DateTime CreatedAt
        {
            get
            {
                return this.createdAtField;
            }
            set
            {
                this.createdAtField = value;
            }
        }

        /// <summary>
        /// Actor who created the Note
        /// </summary>
        public Actor CreatedBy
        {
            get
            {
                return this.createdByField;
            }
            set
            {
                this.createdByField = value;
            }
        }


        /// <summary>
        /// Local date/time when Note was created
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> UpdatedAt
        {
            get
            {
                return this.updatedAtField;
            }
            set
            {
                this.updatedAtField = value;
            }
        }

        /// <summary>
        /// Actor who last modified the Note
        /// </summary>
        public Actor UpdatedBy
        {
            get
            {
                return this.updatedByField;
            }
            set
            {
                this.updatedByField = value;
            }
        }

        /// <summary>
        /// Customer note text
        /// </summary>
        public string NoteText
        {
            get
            {
                return this.noteTextField;
            }
            set
            {
                this.noteTextField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkCustomerAndGroup : CorrigoEntity
    {

        private int customerIdField;

        private int customerGroupIdField;

        private bool isBillingAccountField;

        private bool isParentRemovedField;

        /// <remarks/>
        public int CustomerId
        {
            get
            {
                return this.customerIdField;
            }
            set
            {
                this.customerIdField = value;
            }
        }

        /// <remarks/>
        public int CustomerGroupId
        {
            get
            {
                return this.customerGroupIdField;
            }
            set
            {
                this.customerGroupIdField = value;
            }
        }

        /// <remarks/>
        public bool IsBillingAccount
        {
            get
            {
                return this.isBillingAccountField;
            }
            set
            {
                this.isBillingAccountField = value;
            }
        }

        /// <remarks/>
        public bool IsParentRemoved
        {
            get
            {
                return this.isParentRemovedField;
            }
            set
            {
                this.isParentRemovedField = value;
            }
        }
    }

    /// <summary>
    /// Represents repair categories and codes.
    /// Table [WORepairCodeObject].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class RepairCode : RemovableCorrigoEntity
    {

        private string displayAsField;

        private int parentIdField;

        private RepairCode[] codesField;

        /// <summary>
        /// Name of the object. Is shown on UI.
        /// Max Length=64.
        /// Is required.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// References parent Category; null indicates Category records.
        /// Is required.
        /// </summary>	
        public int ParentId
        {
            get
            {
                return this.parentIdField;
            }
            set
            {
                this.parentIdField = value;
            }
        }


        /// <summary>
        /// Child Repair Codes.
        /// Always empty for Repair Code with ParentID equals to NULL. 
        /// </summary>
        public RepairCode[] Codes
        {
            get
            {
                return this.codesField;
            }
            set
            {
                this.codesField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WorkOrderType : RemovableCorrigoEntity
    {

        private string displayAsField;

        private WOType typeIdField;

        private string abbrField;

        private bool isDefSRField;

        private bool isDefBasicField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public WOType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <remarks/>
        public string Abbr
        {
            get
            {
                return this.abbrField;
            }
            set
            {
                this.abbrField = value;
            }
        }

        /// <remarks/>
        public bool IsDefSR
        {
            get
            {
                return this.isDefSRField;
            }
            set
            {
                this.isDefSRField = value;
            }
        }

        /// <remarks/>
        public bool IsDefBasic
        {
            get
            {
                return this.isDefBasicField;
            }
            set
            {
                this.isDefBasicField = value;
            }
        }
    }


    /// <summary>
    /// Represents billing account (read only).
    /// Specifies billing rules for a group of customers.
    /// Table [lsGroupObject].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class BillingAccount : RemovableWithOriginalCorrigoEntity
    {

        private System.Nullable<int> portalImageSetIdField;

        private System.Nullable<int> cpThemeIdField;

        private bool isBillAcctField;

        private string numberField;

        private string payTermsField;

        private short payDaysField;

        private string payInstrField;

        private bool isCreditHoldField;

        private short accrualMarginField;

        private string salesRepField;

        private bool isTaxExemptField;

        private CorporateEntity corporateEntityField;

        private Address addressField;

        private bool isInactiveField;

        private byte payDayWeekdayField;

        private byte payDayNumberField;

        private Contact billingContactField;

        /// <summary>
        /// Portal Image set id.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<int> PortalImageSetId
        {
            get
            {
                return this.portalImageSetIdField;
            }
            set
            {
                this.portalImageSetIdField = value;
            }
        }

        /// <summary>
        /// Gets a customer portal theme id
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<int> CpThemeId
        {
            get
            {
                return this.cpThemeIdField;
            }
            set
            {
                this.cpThemeIdField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this customer group is a billing account
        /// </summary>
        public bool IsBillAcct
        {
            get
            {
                return this.isBillAcctField;
            }
            set
            {
                this.isBillAcctField = value;
            }
        }

        /// <summary>
        /// Gets a number. 
        /// Max Length=20
        /// </summary>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <summary>
        /// Gets a payment terms. 
        /// Max Length=256
        /// </summary>
        public string PayTerms
        {
            get
            {
                return this.payTermsField;
            }
            set
            {
                this.payTermsField = value;
            }
        }

        /// <summary>
        /// Gets a  numerical value that represents the number of days AFTER INVOICE DATE by which the Invoice DUE DATE is calculated (Default = 0)
        /// </summary>
        public short PayDays
        {
            get
            {
                return this.payDaysField;
            }
            set
            {
                this.payDaysField = value;
            }
        }

        /// <summary>
        /// Gets a payment insrtuctions. 
        /// Max Length=256
        /// </summary>
        public string PayInstr
        {
            get
            {
                return this.payInstrField;
            }
            set
            {
                this.payInstrField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether credit for this account is held
        /// </summary>
        public bool IsCreditHold
        {
            get
            {
                return this.isCreditHoldField;
            }
            set
            {
                this.isCreditHoldField = value;
            }
        }

        /// <summary>
        /// Gets a value that is used in the calculation of Revenue Accruals (Default = 10)
        /// </summary>
        public short AccrualMargin
        {
            get
            {
                return this.accrualMarginField;
            }
            set
            {
                this.accrualMarginField = value;
            }
        }

        /// <summary>
        /// Gets a value used to record the sales representative for this account. 
        /// Max Length=256
        /// </summary>
        public string SalesRep
        {
            get
            {
                return this.salesRepField;
            }
            set
            {
                this.salesRepField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this account has tax exemption
        /// </summary>
        public bool IsTaxExempt
        {
            get
            {
                return this.isTaxExemptField;
            }
            set
            {
                this.isTaxExemptField = value;
            }
        }

        /// <summary>
        /// Gets a corporate entity object
        /// </summary>
        public CorporateEntity CorporateEntity
        {
            get
            {
                return this.corporateEntityField;
            }
            set
            {
                this.corporateEntityField = value;
            }
        }

        /// <summary>
        /// Gets billing account address
        /// </summary>
        public Address Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this account inactivated
        /// </summary>
        public bool IsInactive
        {
            get
            {
                return this.isInactiveField;
            }
            set
            {
                this.isInactiveField = value;
            }
        }

        /// <summary>
        /// Billing day type (Billing Day of Month)
        /// </summary>
        public byte PayDayWeekday
        {
            get
            {
                return this.payDayWeekdayField;
            }
            set
            {
                this.payDayWeekdayField = value;
            }
        }

        /// <summary>
        /// Week number or day number depending on PayDayWeekday value (Billing Day of Month)
        /// </summary>
        public byte PayDayNumber
        {
            get
            {
                return this.payDayNumberField;
            }
            set
            {
                this.payDayNumberField = value;
            }
        }

        /// <summary>
        /// Billing Contact
        /// </summary>
        public Contact BillingContact
        {
            get
            {
                return this.billingContactField;
            }
            set
            {
                this.billingContactField = value;
            }
        }
    }


    /// <summary>
    /// Represents corporate entity.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CorporateEntity : CorrigoEntityWithOptimisticLock
    {

        private string displayAsField;

        private string numberField;


        /// <summary>
        /// Gets or sets a display as value
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// Gets or sets a number
        /// </summary>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }
    }


    /// <summary>
    /// Represents legacy address entity (read only).
    /// See <see cref="Address2"/> for new entity
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Address : CorrigoEntity
    {

        private string streetField;

        private string cityField;

        private string stateField;

        private string zipField;

        private string street2Field;

        private int actorTypeIdField;

        private char typeIdField;

        private int actorIdField;

        private double latitudeField;

        private double longitudeField;

        private string countryField;

        /// <summary>
        /// Gets a street
        /// </summary>
        public string Street
        {
            get
            {
                return this.streetField;
            }
            set
            {
                this.streetField = value;
            }
        }

        /// <summary>
        /// Gets a city
        /// </summary>
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <summary>
        /// Gets a state
        /// </summary>
        public string State
        {
            get
            {
                return this.stateField;
            }
            set
            {
                this.stateField = value;
            }
        }

        /// <summary>
        /// Gets a zip code
        /// </summary>
        public string Zip
        {
            get
            {
                return this.zipField;
            }
            set
            {
                this.zipField = value;
            }
        }

        /// <summary>
        /// Gets a street2
        /// </summary>
        public string Street2
        {
            get
            {
                return this.street2Field;
            }
            set
            {
                this.street2Field = value;
            }
        }

        /// <summary>
        /// Gets a actor type id
        /// </summary>
        public int ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// Gets a address type id
        /// </summary>
        public char TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <summary>
        /// Gets a actor id
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Gets a latitude
        /// </summary>
        public double Latitude
        {
            get
            {
                return this.latitudeField;
            }
            set
            {
                this.latitudeField = value;
            }
        }

        /// <summary>
        /// Gets a longitude
        /// </summary>
        public double Longitude
        {
            get
            {
                return this.longitudeField;
            }
            set
            {
                this.longitudeField = value;
            }
        }

        /// <summary>
        /// Gets a country
        /// </summary>
        public string Country
        {
            get
            {
                return this.countryField;
            }
            set
            {
                this.countryField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LaborCode : RemovableCorrigoEntity
    {

        private InvoiceDictionaryItem invoiceItemField;

        private string descriptionField;

        private string displayAsField;

        private bool isDefaultField;

        private bool showForWoField;

        private bool isTimeCardField;

        private bool isProductiveField;

        private bool isPaidField;

        private bool isShortcutField;

        private bool isDefTimeCardField;

        /// <remarks/>
        public InvoiceDictionaryItem InvoiceItem
        {
            get
            {
                return this.invoiceItemField;
            }
            set
            {
                this.invoiceItemField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public bool IsDefault
        {
            get
            {
                return this.isDefaultField;
            }
            set
            {
                this.isDefaultField = value;
            }
        }

        /// <remarks/>
        public bool ShowForWo
        {
            get
            {
                return this.showForWoField;
            }
            set
            {
                this.showForWoField = value;
            }
        }

        /// <remarks/>
        public bool IsTimeCard
        {
            get
            {
                return this.isTimeCardField;
            }
            set
            {
                this.isTimeCardField = value;
            }
        }

        /// <remarks/>
        public bool IsProductive
        {
            get
            {
                return this.isProductiveField;
            }
            set
            {
                this.isProductiveField = value;
            }
        }

        /// <remarks/>
        public bool IsPaid
        {
            get
            {
                return this.isPaidField;
            }
            set
            {
                this.isPaidField = value;
            }
        }

        /// <remarks/>
        public bool IsShortcut
        {
            get
            {
                return this.isShortcutField;
            }
            set
            {
                this.isShortcutField = value;
            }
        }

        /// <remarks/>
        public bool IsDefTimeCard
        {
            get
            {
                return this.isDefTimeCardField;
            }
            set
            {
                this.isDefTimeCardField = value;
            }
        }
    }




    /// <summary>
    /// Represent employees or organizations.
    /// Table [EmployeeObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Employee : RemovableCorrigoEntity
    {

        private string firstNameField;

        private string lastNameField;

        private string displayAsField;

        private Role roleField;

        private bool accessToAllWorkZonesField;

        private int languageIdField;

        private ActorType actorTypeIdField;

        private string usernameField;

        private System.DateTime dtPwdChangeField;

        private System.Nullable<System.DateTime> providerInvitedOnField;

        private string instructionsField;

        private int wonMemberIdField;

        private int wonLocationIdField;

        private int wonServiceRadiusField;

        private bool isElectronicPaymentField;

        private EmployeeWonStatus providerStatusIdField;

        private int labelIdField;

        private bool freeTextAllowedField;

        private DistanceUnit radiusUnitField;

        private string passwordField;

        private string numberField;

        private string jobTitleField;

        private string federalIdField;

        private string externalIdField;

        private bool forcePasswordResetField;

        private bool taxWarnOnlyField;

        private PriceList defaultPriceListField;

        private LinkProviderPriceList[] priceListsField;

        private CustomField2[] customFieldsField;

        private LinkEmployeeAndOrganization organizationBridgeField;

        private ContactInfo[] contactAddressesField;

        private Address2 addressField;

        private LinkUserAndTeam[] teamsField;

        private LinkUserAndWorkZone[] workZonesField;

        private LinkUserAndPortfolio[] portfoliosField;

        private LinkUserAndCustomerGroup[] customerGroupsField;

        private LinkUserAndSpecialty[] specialtiesField;

        private UserPayRate[] payRatesField;

        private LinkUserAndStockLocation[] stockLocationsField;

        private LinkProviderAndService[] servicesField;

        private AlertSubscription[] alertSubscriptionsField;

        /// <summary>
        /// First name.
        /// Max Length=80.
        /// Is required.
        /// </summary>
        public string FirstName
        {
            get
            {
                return this.firstNameField;
            }
            set
            {
                this.firstNameField = value;
            }
        }

        /// <summary>
        /// Last name.
        /// Max Length=176.
        /// Is required.
        /// </summary>
        public string LastName
        {
            get
            {
                return this.lastNameField;
            }
            set
            {
                this.lastNameField = value;
            }
        }

        /// <summary>
        /// Displayable name.
        /// Max Length=256.
        /// Is required.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <summary>
        /// Role.
        /// Is required.
        /// </summary>
        public Role Role
        {
            get
            {
                return this.roleField;
            }
            set
            {
                this.roleField = value;
            }
        }

        /// <summary>
        /// True means Technician has access to all work zones and thus his Team,
        /// Portfolio and direct Work Zone scope are irrelevant for determining list of accessible work zones.
        /// </summary>
        public bool AccessToAllWorkZones
        {
            get
            {
                return this.accessToAllWorkZonesField;
            }
            set
            {
                this.accessToAllWorkZonesField = value;
            }
        }

        /// <summary>
        /// Preferred language
        /// </summary>
        public int LanguageId
        {
            get
            {
                return this.languageIdField;
            }
            set
            {
                this.languageIdField = value;
            }
        }

        /// <summary>
        /// Should be ActorType.Employee.
        /// Is required.
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// User ID.
        /// Max Length=256.
        /// Is required.
        /// </summary>
        public string Username
        {
            get
            {
                return this.usernameField;
            }
            set
            {
                this.usernameField = value;
            }
        }

        /// <summary>
        /// Date (no time part) when password was set/changed last time; based on server time.
        /// This value is used by code enforcing password policies. 
        /// </summary>
        public System.DateTime DtPwdChange
        {
            get
            {
                return this.dtPwdChangeField;
            }
            set
            {
                this.dtPwdChangeField = value;
            }
        }

        /// <summary>
        /// Date (no time part) when Provider was invited to WON (Work Order Network) last time.
        /// This field is not used by Technicians.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> ProviderInvitedOn
        {
            get
            {
                return this.providerInvitedOnField;
            }
            set
            {
                this.providerInvitedOnField = value;
            }
        }

        /// <summary>
        /// Special instructions.
        /// Max Length=3072.
        /// </summary>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }

        /// <summary>
        /// WON (Work Order Network) member ID; non-zero indicates connected Providers.
        /// This field is not used by Technicians. 
        /// </summary>
        public int WonMemberId
        {
            get
            {
                return this.wonMemberIdField;
            }
            set
            {
                this.wonMemberIdField = value;
            }
        }

        /// <summary>
        /// WON (Work Order Network) location ID; 
        /// </summary>
        public int WonLocationId
        {
            get
            {
                return this.wonLocationIdField;
            }
            set
            {
                this.wonLocationIdField = value;
            }
        }

        /// <summary>
        /// Service radius in miles or kilometers, depending on WonRadiusType value.
        /// Is required.
        /// </summary>
        public int WonServiceRadius
        {
            get
            {
                return this.wonServiceRadiusField;
            }
            set
            {
                this.wonServiceRadiusField = value;
            }
        }

        /// <summary>
        /// True means Provider prefers electronic payments.
        /// This field is not used by Technicians.
        /// </summary>
        public bool IsElectronicPayment
        {
            get
            {
                return this.isElectronicPaymentField;
            }
            set
            {
                this.isElectronicPaymentField = value;
            }
        }

        /// <summary>
        /// WON (Work Order Network) status.
        /// This field is computed automatically in response to modifications for certain fields.
        /// </summary>
        public EmployeeWonStatus ProviderStatusId
        {
            get
            {
                return this.providerStatusIdField;
            }
            set
            {
                this.providerStatusIdField = value;
            }
        }

        /// <summary>
        /// User-defined Provider label.
        /// This field is not used by Technicians.
        /// </summary>
        public int LabelId
        {
            get
            {
                return this.labelIdField;
            }
            set
            {
                this.labelIdField = value;
            }
        }

        /// <summary>
        /// True means Provider can enter free-text entries (i.e. not based on price list imposed by requestor) when preparing invoices.
        /// This field is not used by Technicians.
        /// </summary>
        public bool FreeTextAllowed
        {
            get
            {
                return this.freeTextAllowedField;
            }
            set
            {
                this.freeTextAllowedField = value;
            }
        }

        /// <summary>
        /// Stores units for service radius.
        /// Supported values are kilometers and miles.
        /// </summary>
        public DistanceUnit RadiusUnit
        {
            get
            {
                return this.radiusUnitField;
            }
            set
            {
                this.radiusUnitField = value;
            }
        }

        /// <summary>
        /// User�s password for login.
        /// Max Length=64.
        /// Is required.
        /// </summary>
        public string Password
        {
            get
            {
                return this.passwordField;
            }
            set
            {
                this.passwordField = value;
            }
        }


        /// <summary>
        /// Number (often used as integration key).
        /// Max Length=64.
        /// </summary>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <summary>
        /// Job Title.
        /// Max Length=256.
        /// </summary>
        public string JobTitle
        {
            get
            {
                return this.jobTitleField;
            }
            set
            {
                this.jobTitleField = value;
            }
        }

        /// <summary>
        /// Federal ID#. Used for tax purposes.
        /// Max Length=64.
        /// </summary>
        public string FederalId
        {
            get
            {
                return this.federalIdField;
            }
            set
            {
                this.federalIdField = value;
            }
        }

        /// <summary>
        /// Used by Providers.
        /// Max Length=64.
        /// </summary>
        public string ExternalId
        {
            get
            {
                return this.externalIdField;
            }
            set
            {
                this.externalIdField = value;
            }
        }


        /// <summary>
        /// True means Technician must reset his password upon login.
        /// This field is not used by Providers.
        /// </summary>
        public bool ForcePasswordReset
        {
            get
            {
                return this.forcePasswordResetField;
            }
            set
            {
                this.forcePasswordResetField = value;
            }
        }

        /// <summary>
        /// Tax Warn Only
        /// </summary>
        public bool TaxWarnOnly
        {
            get
            {
                return this.taxWarnOnlyField;
            }
            set
            {
                this.taxWarnOnlyField = value;
            }
        }
        /// <summary>
        /// Default Price List
        /// </summary>
        public PriceList DefaultPriceList
        {
            get
            {
                return this.defaultPriceListField;
            }
            set
            {
                this.defaultPriceListField = value;
            }
        }

        /// <summary>
        /// Price Lists
        /// </summary>
        public LinkProviderPriceList[] PriceLists
        {
            get
            {
                return this.priceListsField;
            }
            set
            {
                this.priceListsField = value;
            }
        }

        /// <summary>
        /// Custom Fields
        /// </summary>
        public CustomField2[] CustomFields
        {
            get
            {
                return this.customFieldsField;
            }
            set
            {
                this.customFieldsField = value;
            }
        }

        /// <summary>
        /// Organization Bridge
        /// </summary>
        public LinkEmployeeAndOrganization OrganizationBridge
        {
            get
            {
                return this.organizationBridgeField;
            }
            set
            {
                this.organizationBridgeField = value;
            }
        }

        /// <summary>
        /// Contact Addresses
        /// </summary>
        public ContactInfo[] ContactAddresses
        {
            get
            {
                return this.contactAddressesField;
            }
            set
            {
                this.contactAddressesField = value;
            }
        }

        /// <summary>
        /// Address
        /// </summary>
        public Address2 Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <summary>
        /// Teams
        /// </summary>
        public LinkUserAndTeam[] Teams
        {
            get
            {
                return this.teamsField;
            }
            set
            {
                this.teamsField = value;
            }
        }

        /// <summary>
        /// Work Zones
        /// </summary>
        public LinkUserAndWorkZone[] WorkZones
        {
            get
            {
                return this.workZonesField;
            }
            set
            {
                this.workZonesField = value;
            }
        }

        /// <summary>
        /// Portfolios
        /// </summary>
        public LinkUserAndPortfolio[] Portfolios
        {
            get
            {
                return this.portfoliosField;
            }
            set
            {
                this.portfoliosField = value;
            }
        }


        /// <summary>
        /// Customer Groups
        /// </summary>
        public LinkUserAndCustomerGroup[] CustomerGroups
        {
            get
            {
                return this.customerGroupsField;
            }
            set
            {
                this.customerGroupsField = value;
            }
        }

        /// <summary>
        /// Specialties
        /// </summary>
        public LinkUserAndSpecialty[] Specialties
        {
            get
            {
                return this.specialtiesField;
            }
            set
            {
                this.specialtiesField = value;
            }
        }

        /// <summary>
        /// Pay Rates
        /// </summary>
        public UserPayRate[] PayRates
        {
            get
            {
                return this.payRatesField;
            }
            set
            {
                this.payRatesField = value;
            }
        }

        /// <summary>
        /// Stock Locations
        /// </summary>
        public LinkUserAndStockLocation[] StockLocations
        {
            get
            {
                return this.stockLocationsField;
            }
            set
            {
                this.stockLocationsField = value;
            }
        }

        /// <summary>
        /// Services
        /// </summary>
        public LinkProviderAndService[] Services
        {
            get
            {
                return this.servicesField;
            }
            set
            {
                this.servicesField = value;
            }
        }

        /// <summary>
        /// Alert Subscriptions
        /// </summary>
        public AlertSubscription[] AlertSubscriptions
        {
            get
            {
                return this.alertSubscriptionsField;
            }
            set
            {
                this.alertSubscriptionsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Role : CorrigoEntityWithOptimisticLock
    {

        private string displayAsField;

        private int rankField;

        private decimal nteLimitField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public int Rank
        {
            get
            {
                return this.rankField;
            }
            set
            {
                this.rankField = value;
            }
        }

        /// <remarks/>
        public decimal NteLimit
        {
            get
            {
                return this.nteLimitField;
            }
            set
            {
                this.nteLimitField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PriceList : CorrigoEntityWithOptimisticLock
    {

        private string displayAsField;

        private PriceListType typeIdField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public PriceListType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkProviderPriceList : CorrigoEntityWithOptimisticLock
    {

        private int providerIdField;

        private int portfolioIdField;

        private int priceListIdField;

        private int idxField;

        /// <remarks/>
        public int ProviderId
        {
            get
            {
                return this.providerIdField;
            }
            set
            {
                this.providerIdField = value;
            }
        }

        /// <remarks/>
        public int PortfolioId
        {
            get
            {
                return this.portfolioIdField;
            }
            set
            {
                this.portfolioIdField = value;
            }
        }

        /// <remarks/>
        public int PriceListId
        {
            get
            {
                return this.priceListIdField;
            }
            set
            {
                this.priceListIdField = value;
            }
        }

        /// <remarks/>
        public int Idx
        {
            get
            {
                return this.idxField;
            }
            set
            {
                this.idxField = value;
            }
        }
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkEmployeeAndOrganization : EmployeeBridgeCorrigoEntity
    {

        private OrgContactType contactTypeField;

        private int organizationIdField;

        private int employeeIdField;

        /// <remarks/>
        public OrgContactType ContactType
        {
            get
            {
                return this.contactTypeField;
            }
            set
            {
                this.contactTypeField = value;
            }
        }

        /// <remarks/>
        public int OrganizationId
        {
            get
            {
                return this.organizationIdField;
            }
            set
            {
                this.organizationIdField = value;
            }
        }

        /// <remarks/>
        public int EmployeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }
    }


    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndPortfolio))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndWorkZone))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkProviderAndService))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndCustomerGroup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndSpecialty))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndStockLocation))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkUserAndTeam))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LinkEmployeeAndOrganization))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public abstract partial class EmployeeBridgeCorrigoEntity : CorrigoEntity
    {
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkUserAndPortfolio : EmployeeBridgeCorrigoEntity
    {

        private int userIdField;

        private int portfolioIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int PortfolioId
        {
            get
            {
                return this.portfolioIdField;
            }
            set
            {
                this.portfolioIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkUserAndWorkZone : EmployeeBridgeCorrigoEntity
    {

        private int userIdField;

        private int workZoneIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int WorkZoneId
        {
            get
            {
                return this.workZoneIdField;
            }
            set
            {
                this.workZoneIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkProviderAndService : EmployeeBridgeCorrigoEntity
    {

        private int providerIdField;

        private int serviceIdField;

        /// <remarks/>
        public int ProviderId
        {
            get
            {
                return this.providerIdField;
            }
            set
            {
                this.providerIdField = value;
            }
        }

        /// <remarks/>
        public int ServiceId
        {
            get
            {
                return this.serviceIdField;
            }
            set
            {
                this.serviceIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkUserAndCustomerGroup : EmployeeBridgeCorrigoEntity
    {

        private int userIdField;

        private int customerGroupIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int CustomerGroupId
        {
            get
            {
                return this.customerGroupIdField;
            }
            set
            {
                this.customerGroupIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkUserAndSpecialty : EmployeeBridgeCorrigoEntity
    {

        private int userIdField;

        private int specialtyIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int SpecialtyId
        {
            get
            {
                return this.specialtyIdField;
            }
            set
            {
                this.specialtyIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkUserAndStockLocation : EmployeeBridgeCorrigoEntity
    {

        private int userIdField;

        private int stockLocationIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int StockLocationId
        {
            get
            {
                return this.stockLocationIdField;
            }
            set
            {
                this.stockLocationIdField = value;
            }
        }
    }





    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LinkUserAndTeam : EmployeeBridgeCorrigoEntity
    {

        private int userIdField;

        private int teamIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int TeamId
        {
            get
            {
                return this.teamIdField;
            }
            set
            {
                this.teamIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class UserPayRate : CorrigoEntityWithOptimisticLock
    {

        private int laborCodeIdField;

        private int userIdField;

        private decimal rateField;

        private bool isDefaultField;

        /// <remarks/>
        public int LaborCodeId
        {
            get
            {
                return this.laborCodeIdField;
            }
            set
            {
                this.laborCodeIdField = value;
            }
        }

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }

        /// <remarks/>
        public bool IsDefault
        {
            get
            {
                return this.isDefaultField;
            }
            set
            {
                this.isDefaultField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class AlertSubscription : CorrigoEntityWithComposedIdAndOptimisticLockOfAlertSubscriptionEntitySpecifierAlertSubscription
    {

        private int userIdField;

        private AlertType alertTypeIdField;

        private bool fullScopeSubscriptionField;

        private AlertScope[] subscriptionScopeField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public AlertType AlertTypeId
        {
            get
            {
                return this.alertTypeIdField;
            }
            set
            {
                this.alertTypeIdField = value;
            }
        }

        /// <remarks/>
        public bool FullScopeSubscription
        {
            get
            {
                return this.fullScopeSubscriptionField;
            }
            set
            {
                this.fullScopeSubscriptionField = value;
            }
        }

        /// <remarks/>
        public AlertScope[] SubscriptionScope
        {
            get
            {
                return this.subscriptionScopeField;
            }
            set
            {
                this.subscriptionScopeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class AlertScope : CorrigoEntityWithOptimisticLock
    {

        private int userIdField;

        private AlertType alertTypeIdField;

        private int scopeIdField;

        private ActorType scopeTypeIdField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public AlertType AlertTypeId
        {
            get
            {
                return this.alertTypeIdField;
            }
            set
            {
                this.alertTypeIdField = value;
            }
        }

        /// <remarks/>
        public int ScopeId
        {
            get
            {
                return this.scopeIdField;
            }
            set
            {
                this.scopeIdField = value;
            }
        }

        /// <remarks/>
        public ActorType ScopeTypeId
        {
            get
            {
                return this.scopeTypeIdField;
            }
            set
            {
                this.scopeTypeIdField = value;
            }
        }
    }




    /// <summary>
    /// Represents the abstract base class for all referenced entities that support deletion protection.
    /// </summary>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ChargeCodeLookup))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(InvoiceDictionaryItem))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public abstract partial class LookupCorrigoEntity : CorrigoEntityWithOptimisticLock
    {

        private bool isRemovedField;

        private string displayAsField;

        /// <summary>
        /// Gets or sets the boolean flag indicating if an entity was deleted.
        /// </summary>
        public bool IsRemoved
        {
            get
            {
                return this.isRemovedField;
            }
            set
            {
                this.isRemovedField = value;
            }
        }


        /// <summary>
        /// Gets or sets the display as CorrigoNet entity value.
        /// </summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class ChargeCodeLookup : LookupCorrigoEntity
    {

        private string codeField;

        /// <remarks/>
        public string Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }
    }

    /// <summary>
    /// Represents payment.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Payment : CorrigoEntityWithOptimisticLock
    {

        private BillingAccount groupField;

        private string numberField;

        private PaymentState stateField;

        private string commentsField;

        private PaymentMethod methodField;

        private string referenceField;

        private System.DateTime dtStampField;

        private decimal amtPaymentField;

        private decimal amtBalanceField;

        private System.Nullable<System.DateTime> dtPostedField;

        private int timeSetIdField;

        private PaymentItem[] itemsField;

        /// <summary>
        /// Gets or sets a billing account object
        /// </summary>
        public BillingAccount Group
        {
            get
            {
                return this.groupField;
            }
            set
            {
                this.groupField = value;
            }
        }

        /// <summary>
        /// Gets a payment number; initially empty, generated by Post action.
        /// </summary>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <summary>
        /// Gets a payment state; Supported values are draft, posted, posted-credit.
        /// </summary>
        public PaymentState State
        {
            get
            {
                return this.stateField;
            }
            set
            {
                this.stateField = value;
            }
        }

        /// <summary>
        /// Gets or sets comments, optional.
        /// </summary>
        public string Comments
        {
            get
            {
                return this.commentsField;
            }
            set
            {
                this.commentsField = value;
            }
        }

        /// <summary>
        /// Gets or sets a payment method; Supported values are check (default), cash, credit card, EFT, account credit.
        /// </summary>
        public PaymentMethod Method
        {
            get
            {
                return this.methodField;
            }
            set
            {
                this.methodField = value;
            }
        }

        /// <summary>
        /// Gets o sets reference or check number, optional.
        /// </summary>
        public string Reference
        {
            get
            {
                return this.referenceField;
            }
            set
            {
                this.referenceField = value;
            }
        }

        /// <summary>
        /// Gets or sets a payment date (set by user explicitly), required. 
        /// </summary>
        public System.DateTime DtStamp
        {
            get
            {
                return this.dtStampField;
            }
            set
            {
                this.dtStampField = value;
            }
        }

        /// <summary>
        /// Gets or sets amount that came from customer (credits not included), cannot be negative.
        /// </summary>
        public decimal AmtPayment
        {
            get
            {
                return this.amtPaymentField;
            }
            set
            {
                this.amtPaymentField = value;
            }
        }

        /// <remarks/>
        public decimal AmtBalance
        {
            get
            {
                return this.amtBalanceField;
            }
            set
            {
                this.amtBalanceField = value;
            }
        }

        /// <summary>
        /// Gets a remaining balance, cannot be negative. Calculated automatically as payment amount plus used credits minus amounts applied to invoices.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtPosted
        {
            get
            {
                return this.dtPostedField;
            }
            set
            {
                this.dtPostedField = value;
            }
        }

        /// <summary>
        /// Gets or sets a time period ID
        /// </summary>
        public int TimeSetId
        {
            get
            {
                return this.timeSetIdField;
            }
            set
            {
                this.timeSetIdField = value;
            }
        }

        /// <summary>
        ///  Gets or sets an items collection.
        /// </summary>
        public PaymentItem[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }
    }



    /// <summary>
    /// Represents payment item.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PaymentItem : CorrigoEntityWithOptimisticLock
    {

        private ActorType objectTypeIdField;

        private int objectIdField;

        private bool isCreditField;

        private decimal amtBalanceField;

        private decimal amtUsedField;

        private Invoice refInvoiceField;

        private Payment refPaymentField;

        /// <summary>
        /// Gets or sets type ID of the object referenced by record. Required. For credit records it either #29 (credit memo) or #30 (payment). For non-credit records it's always #29 (invoice).
        /// </summary>
        public ActorType ObjectTypeId
        {
            get
            {
                return this.objectTypeIdField;
            }
            set
            {
                this.objectTypeIdField = value;
            }
        }

        /// <summary>
        /// Gets or sets reference to object which record is based upon, either invoice/credit memo or payment. Required.
        /// </summary>
        public int ObjectId
        {
            get
            {
                return this.objectIdField;
            }
            set
            {
                this.objectIdField = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this record stores credit used (true - credit otherwise debit).
        /// </summary>
        public bool IsCredit
        {
            get
            {
                return this.isCreditField;
            }
            set
            {
                this.isCreditField = value;
            }
        }

        /// <summary>
        /// Gets an object's (credit memo/invoice or payment) remaining balance BEFORE payment was posted. Optional. Zero for draft payments.
        /// </summary>
        public decimal AmtBalance
        {
            get
            {
                return this.amtBalanceField;
            }
            set
            {
                this.amtBalanceField = value;
            }
        }

        /// <summary>
        /// Gets or sets amount taken from credit (auto-calculated), or amount applied to invoice (entered by user). Cannot be negative; zero is allowed only for credit records.
        /// </summary>
        public decimal AmtUsed
        {
            get
            {
                return this.amtUsedField;
            }
            set
            {
                this.amtUsedField = value;
            }
        }

        /// <summary>
        /// Gets an invoice on which payment is based. 
        /// Based on <seealso cref="ObjectId"/> and <seealso cref="ObjectTypeId"/>
        /// </summary>
        public Invoice RefInvoice
        {
            get
            {
                return this.refInvoiceField;
            }
            set
            {
                this.refInvoiceField = value;
            }
        }

        /// <summary>
        /// Gets a payment on which payment is based.
        /// Based on <seealso cref="ObjectId"/> and <seealso cref="ObjectTypeId"/>
        /// </summary>
        public Payment RefPayment
        {
            get
            {
                return this.refPaymentField;
            }
            set
            {
                this.refPaymentField = value;
            }
        }
    }

    /// <summary>
    /// Represents invoice.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Invoice : CorrigoEntityWithOptimisticLock
    {

        private int timeSetIdField;

        private TimePeriod periodField;

        private BillingAccount groupField;

        private string numberField;

        private CiInvoiceState stateField;

        private string poNumberField;

        private System.Nullable<System.DateTime> dtDueField;

        private string glAccountField;

        private string commentsField;

        private decimal amtBaseField;

        private decimal amtTaxField;

        private decimal amtTotalField;

        private bool isMultilineField;

        private string taxTransactionIdField;

        private bool isTaxDirtyField;

        private InvoiceLine[] lineItemsField;

        private string extNumberField;

        private System.Nullable<System.DateTime> dtPostedField;

        /// <summary>
        /// Gets a time period ID
        /// </summary>
        public int TimeSetId
        {
            get
            {
                return this.timeSetIdField;
            }
            set
            {
                this.timeSetIdField = value;
            }
        }

        /// <remarks/>
        public TimePeriod Period
        {
            get
            {
                return this.periodField;
            }
            set
            {
                this.periodField = value;
            }
        }

        /// <summary>
        /// Gets a billing account object
        /// </summary>
        public BillingAccount Group
        {
            get
            {
                return this.groupField;
            }
            set
            {
                this.groupField = value;
            }
        }

        /// <summary>
        /// Gets a invoice number; initially empty, generated by Post action
        /// </summary>	
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <summary>
        /// Gets a invoice state; supported values are draft, posted, paid, paid in full, credit, credit used.
        /// </summary>
        public CiInvoiceState State
        {
            get
            {
                return this.stateField;
            }
            set
            {
                this.stateField = value;
            }
        }

        /// <summary>
        /// Gets an optional field used for customer reference
        /// </summary>	
        public string PoNumber
        {
            get
            {
                return this.poNumberField;
            }
            set
            {
                this.poNumberField = value;
            }
        }

        /// <summary>
        /// Gets an invoice due date computed when invoice is posted; initially empty
        /// </summary>	
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtDue
        {
            get
            {
                return this.dtDueField;
            }
            set
            {
                this.dtDueField = value;
            }
        }

        /// <summary>
        /// Gets a GL account number
        /// </summary>
        public string GlAccount
        {
            get
            {
                return this.glAccountField;
            }
            set
            {
                this.glAccountField = value;
            }
        }

        /// <summary>
        /// Gets a comments
        /// </summary>
        public string Comments
        {
            get
            {
                return this.commentsField;
            }
            set
            {
                this.commentsField = value;
            }
        }

        /// <summary>
        /// Gets an invoice subtotal before tax
        /// </summary>	
        public decimal AmtBase
        {
            get
            {
                return this.amtBaseField;
            }
            set
            {
                this.amtBaseField = value;
            }
        }

        /// <summary>
        /// Gets an invoice total tax amount
        /// </summary>	
        public decimal AmtTax
        {
            get
            {
                return this.amtTaxField;
            }
            set
            {
                this.amtTaxField = value;
            }
        }

        /// <summary>
        /// Gets an invoice total amount (base + tax)
        /// </summary>	
        public decimal AmtTotal
        {
            get
            {
                return this.amtTotalField;
            }
            set
            {
                this.amtTotalField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this invoice consists of more than one line item
        /// </summary>	
        public bool IsMultiline
        {
            get
            {
                return this.isMultilineField;
            }
            set
            {
                this.isMultilineField = value;
            }
        }

        /// <summary>
        /// Gets a tax transaction ID (non-empty value means tax was computed)
        /// </summary>	
        public string TaxTransactionId
        {
            get
            {
                return this.taxTransactionIdField;
            }
            set
            {
                this.taxTransactionIdField = value;
            }
        }

        /// <summary>
        /// Gets a value indicating whether invoice content was changed since tax was computed.
        /// </summary>
        public bool IsTaxDirty
        {
            get
            {
                return this.isTaxDirtyField;
            }
            set
            {
                this.isTaxDirtyField = value;
            }
        }

        ///<summary>
        /// Gets a line items collection.
        ///</summary>
        public InvoiceLine[] LineItems
        {
            get
            {
                return this.lineItemsField;
            }
            set
            {
                this.lineItemsField = value;
            }
        }

        ///<summary>
        /// Gets or sets an external number
        ///</summary>
        public string ExtNumber
        {
            get
            {
                return this.extNumberField;
            }
            set
            {
                this.extNumberField = value;
            }
        }

        /// <summary>
        /// Date of "posted" action; a.k.a. Invoice Date
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtPosted
        {
            get
            {
                return this.dtPostedField;
            }
            set
            {
                this.dtPostedField = value;
            }
        }
    }



    /// <summary>
    /// Represents invoice line (read only).
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class InvoiceLine : CorrigoEntityWithOptimisticLock
    {

        private InvoiceDictionaryItem invoiceItemField;

        private WorkOrder workOrderField;

        private Location locationField;

        private Customer customerField;

        private CiItemType typeField;

        private System.Nullable<System.DateTime> dtServiceField;

        private string descrField;

        private decimal qtyField;

        private decimal rateField;

        private decimal taxRateField;

        private decimal amtTaxField;

        private decimal amtTotalField;

        private string taxCodeField;

        ///<summary>
        /// Gets an invoice dictionary item object
        ///</summary>
        public InvoiceDictionaryItem InvoiceItem
        {
            get
            {
                return this.invoiceItemField;
            }
            set
            {
                this.invoiceItemField = value;
            }
        }

        ///<summary>
        /// Gets a work order object
        ///</summary>
        public WorkOrder WorkOrder
        {
            get
            {
                return this.workOrderField;
            }
            set
            {
                this.workOrderField = value;
            }
        }

        ///<summary>
        /// Gets a location object
        ///</summary>
        public Location Location
        {
            get
            {
                return this.locationField;
            }
            set
            {
                this.locationField = value;
            }
        }

        ///<summary>
        /// Gets a customer object
        ///</summary>
        public Customer Customer
        {
            get
            {
                return this.customerField;
            }
            set
            {
                this.customerField = value;
            }
        }

        ///<summary>
        /// Gets a type of the relationship with WO; supported values are single WO, group header, group child, none
        ///</summary>
        public CiItemType Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        ///<summary>
        /// Gets a date of service; suported for items associated with WOs
        ///</summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtService
        {
            get
            {
                return this.dtServiceField;
            }
            set
            {
                this.dtServiceField = value;
            }
        }

        ///<summary>
        /// Gets a description
        ///</summary>
        public string Descr
        {
            get
            {
                return this.descrField;
            }
            set
            {
                this.descrField = value;
            }
        }

        ///<summary>
        /// Gets a quantity, precision is up to 5 digits
        ///</summary>
        public decimal Qty
        {
            get
            {
                return this.qtyField;
            }
            set
            {
                this.qtyField = value;
            }
        }

        ///<summary>
        /// Gets a rate (computed by tax software, precision is up to 4 digits)
        ///</summary>
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }

        /// <summary>
        /// Gets a tax rate, precision is up to 5 digits
        /// </summary>
        public decimal TaxRate
        {
            get
            {
                return this.taxRateField;
            }
            set
            {
                this.taxRateField = value;
            }
        }

        /// <summary>
        /// Gets a tax amount (computed by tax software)
        /// </summary>
        public decimal AmtTax
        {
            get
            {
                return this.amtTaxField;
            }
            set
            {
                this.amtTaxField = value;
            }
        }

        /// <summary>
        /// Gets a total amount
        /// </summary>
        public decimal AmtTotal
        {
            get
            {
                return this.amtTotalField;
            }
            set
            {
                this.amtTotalField = value;
            }
        }

        ///<summary>
        /// Get or tax code.
        ///</summary>
        public string TaxCode
        {
            get
            {
                return this.taxCodeField;
            }
            set
            {
                this.taxCodeField = value;
            }
        }
    }



    /// <summary>
    /// Customer has an ability to estimate his order price before the work started.
    /// This estimate is used then as a limit value for work order price - Not to exceed amount(NTE) value.
    /// Table [WOEstimateObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoEstimate : CorrigoEntityWithOptimisticLock
    {

        private int workOrderIdField;

        private decimal amountField;

        private string commentField;

        private QuoteStatus statusIdField;

        private string reasonField;

        private int contactIdField;

        private string contactNameField;

        /// <summary>
        /// Estimate work order id.
        /// Is required.
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <summary>
        /// Requested NTE (Not to Exceed) amount. Negative values are not allowed; zero value might be blocked by pre-commit check.
        /// </summary>
        public decimal Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <summary>
        /// When new NTE (Not to Exceed) is requested - contains request comment.
        /// After request was approved it contains response from customer.
        /// Max Length=2048
        /// </summary>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <summary>
        /// Unknown, NotSubmitted (obsolete state), Requested, WaitingForApproval, Approved,Rejected, InProposal (reserved).
        /// Is required.
        /// </summary>
        public QuoteStatus StatusId
        {
            get
            {
                return this.statusIdField;
            }
            set
            {
                this.statusIdField = value;
            }
        }

        /// <summary>
        /// Contains response from customer after reject.
        /// Max Length=256
        /// </summary>
        public string Reason
        {
            get
            {
                return this.reasonField;
            }
            set
            {
                this.reasonField = value;
            }
        }

        /// <summary>
        /// Id of the contact that approves or rejects estimate.
        /// Required for approved and rejected state when ContactName is not defined.
        /// </summary>
        public int ContactId
        {
            get
            {
                return this.contactIdField;
            }
            set
            {
                this.contactIdField = value;
            }
        }

        /// <summary>
        /// Contact that approved or rejected comment.
        /// Required for approved and rejected state when ContactId is not defined.
        /// Max Length=256
        /// </summary>
        public string ContactName
        {
            get
            {
                return this.contactNameField;
            }
            set
            {
                this.contactNameField = value;
            }
        }
    }



    /// <summary>
    /// Represents check in/out record (read only).
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoOnSite : CorrigoEntityWithOptimisticLock
    {

        private int workOrderIdField;

        private int employeeIdField;

        private int timeZoneField;

        private System.DateTime dtCheckInField;

        private OnSiteValidationType inCheckTypeIdField;

        private string inValidationValueField;

        private decimal inLatitudeField;

        private decimal inLongitudeField;

        private int inInvItemIdField;

        private decimal inDistanceField;

        private OnSiteValidationResult inStatusIdField;

        private System.Nullable<System.DateTime> dtCheckOutField;

        private OnSiteValidationType outCheckTypeIdField;

        private string outValidationValueField;

        private decimal outLatitudeField;

        private decimal outLongitudeField;

        private int outInvItemIdField;

        private decimal outDistanceField;

        private OnSiteValidationResult outStatusIdField;

        /// <remarks/>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <remarks/>
        public int EmployeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }

        /// <remarks/>
        public int TimeZone
        {
            get
            {
                return this.timeZoneField;
            }
            set
            {
                this.timeZoneField = value;
            }
        }

        /// <remarks/>
        public System.DateTime DtCheckIn
        {
            get
            {
                return this.dtCheckInField;
            }
            set
            {
                this.dtCheckInField = value;
            }
        }

        /// <remarks/>
        public OnSiteValidationType InCheckTypeId
        {
            get
            {
                return this.inCheckTypeIdField;
            }
            set
            {
                this.inCheckTypeIdField = value;
            }
        }

        /// <remarks/>
        public string InValidationValue
        {
            get
            {
                return this.inValidationValueField;
            }
            set
            {
                this.inValidationValueField = value;
            }
        }

        /// <remarks/>
        public decimal InLatitude
        {
            get
            {
                return this.inLatitudeField;
            }
            set
            {
                this.inLatitudeField = value;
            }
        }

        /// <remarks/>
        public decimal InLongitude
        {
            get
            {
                return this.inLongitudeField;
            }
            set
            {
                this.inLongitudeField = value;
            }
        }

        /// <remarks/>
        public int InInvItemId
        {
            get
            {
                return this.inInvItemIdField;
            }
            set
            {
                this.inInvItemIdField = value;
            }
        }

        /// <remarks/>
        public decimal InDistance
        {
            get
            {
                return this.inDistanceField;
            }
            set
            {
                this.inDistanceField = value;
            }
        }

        /// <remarks/>
        public OnSiteValidationResult InStatusId
        {
            get
            {
                return this.inStatusIdField;
            }
            set
            {
                this.inStatusIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> DtCheckOut
        {
            get
            {
                return this.dtCheckOutField;
            }
            set
            {
                this.dtCheckOutField = value;
            }
        }

        /// <remarks/>
        public OnSiteValidationType OutCheckTypeId
        {
            get
            {
                return this.outCheckTypeIdField;
            }
            set
            {
                this.outCheckTypeIdField = value;
            }
        }

        /// <remarks/>
        public string OutValidationValue
        {
            get
            {
                return this.outValidationValueField;
            }
            set
            {
                this.outValidationValueField = value;
            }
        }

        /// <remarks/>
        public decimal OutLatitude
        {
            get
            {
                return this.outLatitudeField;
            }
            set
            {
                this.outLatitudeField = value;
            }
        }

        /// <remarks/>
        public decimal OutLongitude
        {
            get
            {
                return this.outLongitudeField;
            }
            set
            {
                this.outLongitudeField = value;
            }
        }

        /// <remarks/>
        public int OutInvItemId
        {
            get
            {
                return this.outInvItemIdField;
            }
            set
            {
                this.outInvItemIdField = value;
            }
        }

        /// <remarks/>
        public decimal OutDistance
        {
            get
            {
                return this.outDistanceField;
            }
            set
            {
                this.outDistanceField = value;
            }
        }

        /// <remarks/>
        public OnSiteValidationResult OutStatusId
        {
            get
            {
                return this.outStatusIdField;
            }
            set
            {
                this.outStatusIdField = value;
            }
        }
    }



    /// <summary>
    /// Quote is object used by a workflow used when Work Order is assigned to provider; and requestor wants to know how much work will cost beforehand.
    /// Quote object is basically an object where answer to the question �how much will this cost?� is stored.
    /// It is based on [WOQuoteObject] table; there can be either 0 or 1 Quote record for each WO.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoQuote : CorrigoEntityWithOptimisticLock
    {

        private int woIdField;

        private decimal amountField;

        private string descriptionField;

        private string reasonField;

        private QuoteStatus statusIdField;

        /// <remarks/>
        public int WoId
        {
            get
            {
                return this.woIdField;
            }
            set
            {
                this.woIdField = value;
            }
        }

        /// <remarks/>
        public decimal Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <summary>
        /// Comments provided from either provider or requestor; zero length not always accepted.
        /// </summary>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <summary>
        /// Reason for rejection; free-text. Required when Quote is Rejected.
        /// </summary>
        public string Reason
        {
            get
            {
                return this.reasonField;
            }
            set
            {
                this.reasonField = value;
            }
        }

        /// <remarks/>
        public QuoteStatus StatusId
        {
            get
            {
                return this.statusIdField;
            }
            set
            {
                this.statusIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoVerification : CorrigoEntityWithOptimisticLock
    {

        private int idxField;

        private int workOrderIdField;

        private WoRating woRatingIdField;

        private string commentField;

        private System.DateTime editedDateField;

        private Actor actorField;

        /// <remarks/>
        public int Idx
        {
            get
            {
                return this.idxField;
            }
            set
            {
                this.idxField = value;
            }
        }

        /// <remarks/>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <remarks/>
        public WoRating WoRatingId
        {
            get
            {
                return this.woRatingIdField;
            }
            set
            {
                this.woRatingIdField = value;
            }
        }

        /// <remarks/>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <remarks/>
        public System.DateTime EditedDate
        {
            get
            {
                return this.editedDateField;
            }
            set
            {
                this.editedDateField = value;
            }
        }

        /// <remarks/>
        public Actor Actor
        {
            get
            {
                return this.actorField;
            }
            set
            {
                this.actorField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class DocumentType : CorrigoEntityWithOptimisticLock
    {

        private string descriptionField;

        private string displayAsField;

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }
    }


    /// <summary>
    /// Document e.g.: link or file (txt, xlsx, pdf, docx, bmp).
    /// Table [dmDocObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Document : CorrigoEntityWithOptimisticLock
    {

        private int actorIdField;

        private ActorType actorTypeIdField;

        private string descriptionField;

        private string titleField;

        private DocumentType docTypeField;

        private System.Nullable<System.DateTime> endDateField;

        private System.DateTime startDateField;

        private System.DateTime updatedDateField;

        private int extensionIdField;

        private bool isLinkField;

        private string mimeTypeField;

        private Actor updatedByField;

        private int wonIdField;

        private int wonMemberIdField;

        private WonDocumentType wonTypeIdField;

        private Blob blobField;

        /// <summary>
        /// Id of document owner.
        /// Is required.
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Actor Type of the parent object. Work Order, Inventory Asset.
        /// Is required.
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// Description.
        /// Max Length=512.
        /// Is required.
        /// </summary>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <summary>
        /// Title.
        /// Max Length=80.
        /// Is required.
        /// </summary>
        public string Title
        {
            get
            {
                return this.titleField;
            }
            set
            {
                this.titleField = value;
            }
        }

        /// <summary>
        /// Document Type.
        /// Is required.
        /// </summary>
        public DocumentType DocType
        {
            get
            {
                return this.docTypeField;
            }
            set
            {
                this.docTypeField = value;
            }
        }

        /// <summary>
        /// Defines end of document's lifetime.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> EndDate
        {
            get
            {
                return this.endDateField;
            }
            set
            {
                this.endDateField = value;
            }
        }

        /// <summary>
        /// Defines start of document's lifetime.
        /// </summary>
        public System.DateTime StartDate
        {
            get
            {
                return this.startDateField;
            }
            set
            {
                this.startDateField = value;
            }
        }

        /// <summary>
        /// Updated Date.
        /// </summary>
        public System.DateTime UpdatedDate
        {
            get
            {
                return this.updatedDateField;
            }
            set
            {
                this.updatedDateField = value;
            }
        }

        /// <summary>
        /// Extension Id
        /// </summary>
        public int ExtensionId
        {
            get
            {
                return this.extensionIdField;
            }
            set
            {
                this.extensionIdField = value;
            }
        }

        /// <remarks/>
        public bool IsLink
        {
            get
            {
                return this.isLinkField;
            }
            set
            {
                this.isLinkField = value;
            }
        }

        /// <summary>
        /// Mime Type.
        /// Is required.
        /// </summary>
        public string MimeType
        {
            get
            {
                return this.mimeTypeField;
            }
            set
            {
                this.mimeTypeField = value;
            }
        }

        /// <summary>
        /// Updated By
        /// </summary>
        public Actor UpdatedBy
        {
            get
            {
                return this.updatedByField;
            }
            set
            {
                this.updatedByField = value;
            }
        }

        /// <summary>
        /// WON (Work Order Network) Id
        /// </summary>
        public int WonId
        {
            get
            {
                return this.wonIdField;
            }
            set
            {
                this.wonIdField = value;
            }
        }

        /// <summary>
        /// WON (Work Order Network) member ID
        /// </summary>
        public int WonMemberId
        {
            get
            {
                return this.wonMemberIdField;
            }
            set
            {
                this.wonMemberIdField = value;
            }
        }

        /// <remarks/>
        public WonDocumentType WonTypeId
        {
            get
            {
                return this.wonTypeIdField;
            }
            set
            {
                this.wonTypeIdField = value;
            }
        }

        /// <summary>
        /// File object is a content of the file stored in BLOB
        /// </summary>
        public Blob Blob
        {
            get
            {
                return this.blobField;
            }
            set
            {
                this.blobField = value;
            }
        }
    }



    /// <summary>
    /// Stores the file content.
    /// Table [BLOBObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Blob : CorrigoEntityWithComposedIdOfBlobEntitySpecifierBlob
    {

        private int actorIdField;

        private ActorType actorTypeIdField;

        private byte[] bodyField;

        private string fileNameField;

        private char typeIdField;

        /// <summary>
        /// Entity that owns this blob - work order id or other.
        /// Is required.
        /// </summary>
        public int ActorId
        {
            get
            {
                return this.actorIdField;
            }
            set
            {
                this.actorIdField = value;
            }
        }

        /// <summary>
        /// Work Order or other.
        /// Is required.
        /// </summary>
        public ActorType ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <summary>
        /// File content.
        /// Is required.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "base64Binary")]
        public byte[] Body
        {
            get
            {
                return this.bodyField;
            }
            set
            {
                this.bodyField = value;
            }
        }

        /// <summary>
        /// File name
        /// </summary>
        public string FileName
        {
            get
            {
                return this.fileNameField;
            }
            set
            {
                this.fileNameField = value;
            }
        }

        /// <summary>
        /// File type identifier
        /// </summary>
        public char TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoPunchListItem : CorrigoEntityWithOptimisticLock
    {

        private int workOrderIdField;

        private int idxField;

        private string commentField;

        private bool doneField;

        private string descriptionField;

        private string exceptionField;

        /// <remarks/>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <remarks/>
        public int Idx
        {
            get
            {
                return this.idxField;
            }
            set
            {
                this.idxField = value;
            }
        }

        /// <remarks/>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <remarks/>
        public bool Done
        {
            get
            {
                return this.doneField;
            }
            set
            {
                this.doneField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string Exception
        {
            get
            {
                return this.exceptionField;
            }
            set
            {
                this.exceptionField = value;
            }
        }
    }

    /// <summary>
    /// Stores information about equipment used in work order.
    /// Table [WoEquipmentObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoEquipment : CorrigoEntityWithOptimisticLock
    {

        private int woIdField;

        private Location assetField;

        private string commentField;

        private bool refrigerantUsedField;

        private WoEquipmentType typeField;


        /// <summary>
        /// Work Order Id.
        /// Is required.
        /// </summary>
        public int WoId
        {
            get
            {
                return this.woIdField;
            }
            set
            {
                this.woIdField = value;
            }
        }

        /// <summary>
        /// Asset of type equipment. This asset must reside under some of spaces used in work order.
        /// </summary>
        public Location Asset
        {
            get
            {
                return this.assetField;
            }
            set
            {
                this.assetField = value;
            }
        }


        /// <summary>
        /// Comments provided from user; zero-length value is accepted.
        /// Max Length=1024
        /// </summary>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <summary>
        /// A three-state Boolean flag (NULL means �no value�) indicating refrigerant was used when work for particular equipment was done.
        /// </summary>
        public bool RefrigerantUsed
        {
            get
            {
                return this.refrigerantUsedField;
            }
            set
            {
                this.refrigerantUsedField = value;
            }
        }

        /// <summary>
        /// Type: Unknown, New, Known, NotRelated.
        /// Is required.
        /// </summary>
        public WoEquipmentType Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }
    }



    /// <summary>
    /// This object represents line items included into work order.
    /// Each line item is separate task with location (where job is needed),
    /// task (what needs to be done) and even status (called disposition). 
    /// Table [WOItemObject].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoItem : CorrigoEntityWithOptimisticLock
    {

        private int workOrderIdField;

        private int sortOrderIdxField;

        private Disposition dispositionField;

        private string assetLocationField;

        private Location assetField;

        private Task taskField;

        private string commentField;

        /// <summary>
        /// Parent Work Order Id.
        /// Is required.
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <summary>
        /// Order in parents container.
        /// Sort index; 1-based; must has unique value per WO and used to sort items on UI.
        /// Only positive values are allowed (>= 1).
        /// Is required.
        /// 
        /// </summary>
        public int SortOrderIdx
        {
            get
            {
                return this.sortOrderIdxField;
            }
            set
            {
                this.sortOrderIdxField = value;
            }
        }

        /// <summary>
        /// Allows to define a point of WorkOrder workflow at which the item is to be processed (e.g. on WorkOrder status changed to Completed).
        /// </summary>
        public Disposition Disposition
        {
            get
            {
                return this.dispositionField;
            }
            set
            {
                this.dispositionField = value;
            }
        }

        /// <summary>
        /// Free-text value representing item�s location in the asset hierarchy, relative to WO�s main location.
        /// This value is computed by BO.
        /// Max Length=128.
        /// 
        /// </summary>
        public string AssetLocation
        {
            get
            {
                return this.assetLocationField;
            }
            set
            {
                this.assetLocationField = value;
            }
        }

        /// <summary>
        /// Asset to work with.
        /// Is required.
        /// </summary>
        public Location Asset
        {
            get
            {
                return this.assetField;
            }
            set
            {
                this.assetField = value;
            }
        }

        /// <summary>
        /// The task to be done in frame of the item.
        /// Is required.
        /// </summary>
        public Task Task
        {
            get
            {
                return this.taskField;
            }
            set
            {
                this.taskField = value;
            }
        }

        /// <summary>
        /// Plain text to clarify the items purpose.
        /// Max Length=3096.
        /// </summary>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class FinancialItem : CorrigoEntityWithOptimisticLock
    {

        private int woIdField;

        private string commentField;

        private decimal amountField;

        private CostCategory costCategoryIdField;

        private decimal rateField;

        private System.Nullable<System.DateTime> startDateField;

        private int durationField;

        private InvoiceDictionaryItem invoiceItemField;

        private bool excludeField;

        private Product productField;

        private Employee employeeField;

        private decimal quantityField;

        private LaborCode laborCodeField;

        private WoCostLineType typeIdField;

        private decimal taxAmountField;

        /// <remarks/>
        public int WoId
        {
            get
            {
                return this.woIdField;
            }
            set
            {
                this.woIdField = value;
            }
        }

        /// <remarks/>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <remarks/>
        public decimal Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <remarks/>
        public CostCategory CostCategoryId
        {
            get
            {
                return this.costCategoryIdField;
            }
            set
            {
                this.costCategoryIdField = value;
            }
        }

        /// <remarks/>
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> StartDate
        {
            get
            {
                return this.startDateField;
            }
            set
            {
                this.startDateField = value;
            }
        }

        /// <remarks/>
        public int Duration
        {
            get
            {
                return this.durationField;
            }
            set
            {
                this.durationField = value;
            }
        }

        /// <remarks/>
        public InvoiceDictionaryItem InvoiceItem
        {
            get
            {
                return this.invoiceItemField;
            }
            set
            {
                this.invoiceItemField = value;
            }
        }

        /// <remarks/>
        public bool Exclude
        {
            get
            {
                return this.excludeField;
            }
            set
            {
                this.excludeField = value;
            }
        }

        /// <remarks/>
        public Product Product
        {
            get
            {
                return this.productField;
            }
            set
            {
                this.productField = value;
            }
        }

        /// <remarks/>
        public Employee Employee
        {
            get
            {
                return this.employeeField;
            }
            set
            {
                this.employeeField = value;
            }
        }

        /// <remarks/>
        public decimal Quantity
        {
            get
            {
                return this.quantityField;
            }
            set
            {
                this.quantityField = value;
            }
        }

        /// <remarks/>
        public LaborCode LaborCode
        {
            get
            {
                return this.laborCodeField;
            }
            set
            {
                this.laborCodeField = value;
            }
        }

        /// <remarks/>
        public WoCostLineType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <remarks/>
        public decimal TaxAmount
        {
            get
            {
                return this.taxAmountField;
            }
            set
            {
                this.taxAmountField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Product : CorrigoEntity
    {

        private InvoiceDictionaryItem invoiceItemField;

        private string partNameField;

        /// <remarks/>
        public InvoiceDictionaryItem InvoiceItem
        {
            get
            {
                return this.invoiceItemField;
            }
            set
            {
                this.invoiceItemField = value;
            }
        }

        /// <remarks/>
        public string PartName
        {
            get
            {
                return this.partNameField;
            }
            set
            {
                this.partNameField = value;
            }
        }
    }


    /// <summary>
    /// Additional asset info.
    /// Table [rcsEquipment].
    /// Web service access scope - Full access.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class AssetInfo : CorrigoEntity
    {

        private int assetIdField;

        private int communityIdField;

        private string serialNumberField;

        private string tagIdField;

        private string checkPhoneField;

        /// <summary>
        /// Asset id.
        /// Is required.
        /// </summary>
        public int AssetId
        {
            get
            {
                return this.assetIdField;
            }
            set
            {
                this.assetIdField = value;
            }
        }

        /// <summary>
        /// Work zone id.
        /// Is required.
        /// </summary>
        public int CommunityId
        {
            get
            {
                return this.communityIdField;
            }
            set
            {
                this.communityIdField = value;
            }
        }

        /// <summary>
        /// Asset serial number.
        /// Max Length=50.
        /// </summary>
        public string SerialNumber
        {
            get
            {
                return this.serialNumberField;
            }
            set
            {
                this.serialNumberField = value;
            }
        }

        /// <summary>
        /// Asset Tag Id.
        /// Max Length=892.
        /// </summary>
        public string TagId
        {
            get
            {
                return this.tagIdField;
            }
            set
            {
                this.tagIdField = value;
            }
        }


        /// <summary>
        /// Phone.
        /// Max Length=256.
        /// </summary>
        public string CheckPhone
        {
            get
            {
                return this.checkPhoneField;
            }
            set
            {
                this.checkPhoneField = value;
            }
        }
    }

    /// <summary>
    /// Represents GL account.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class GLAccount : CorrigoEntityWithComposedIdOfGLAccountEntitySpecifierGlAccount
    {

        private string displayAsField;

        private string descrField;

        private bool isIncomeField;

        ///<summary>
        /// Gets or sets a display as value.
        ///</summary>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        ///<summary>
        /// Gets or sets a description, this field is optional.
        ///</summary>
        public string Descr
        {
            get
            {
                return this.descrField;
            }
            set
            {
                this.descrField = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this account is income
        /// </summary>
        public bool IsIncome
        {
            get
            {
                return this.isIncomeField;
            }
            set
            {
                this.isIncomeField = value;
            }
        }
    }



    /// <summary>
    /// WO Assignment contains information about Employees (both technicians and providers) assigned to Work Orders (bith primary and secondary assignments). It is essentially a bridge record between Work Order and Employee, with a couple of additional fields. 
    /// Table [lnWOEmpl2Object].
    /// Web service access scope - Full access
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoAssignment : CorrigoEntity
    {

        private int workOrderIdField;

        private bool isPrimaryField;

        private int employeeIdField;

        /// <summary>
        /// Assignment work order id.
        /// Is required.
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <summary>
        /// True means primary assignment; in this case Actor_ID value matches WorkOrder2Object.Owner_EmployeeID.
        /// </summary>
        public bool IsPrimary
        {
            get
            {
                return this.isPrimaryField;
            }
            set
            {
                this.isPrimaryField = value;
            }
        }

        /// <summary>
        /// Id of an Employee the WorkOrder assigned to.
        /// Is required.
        /// </summary>
        public int EmployeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }
    }

    /// <summary>
    /// Persists user notes during work order flow.
    /// Table [WONote2Object].
    /// Web service access scope - Full access (as a property of WorkOrder)
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoNote : CorrigoEntity
    {

        private System.DateTime createdDateField;

        private string bodyField;

        private int workOrderIdField;

        private WONoteType noteTypeIdField;

        private Actor createdByField;

        /// <summary>
        /// Note creation date and time in work zone time.
        /// Is required.
        /// </summary>
        public System.DateTime CreatedDate
        {
            get
            {
                return this.createdDateField;
            }
            set
            {
                this.createdDateField = value;
            }
        }

        /// <summary>
        /// Note text.
        /// Max Length=6144.
        /// Is required.
        /// </summary>
        public string Body
        {
            get
            {
                return this.bodyField;
            }
            set
            {
                this.bodyField = value;
            }
        }

        /// <summary>
        /// Work Order Id.
        /// Is required.
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <summary>
        /// Type: Unknown, Completion, Public, Private.
        /// Is required.
        /// </summary>
        public WONoteType NoteTypeId
        {
            get
            {
                return this.noteTypeIdField;
            }
            set
            {
                this.noteTypeIdField = value;
            }
        }

        /// <summary>
        /// Represents the user, provider or other part that created that note.
        /// </summary>
        public Actor CreatedBy
        {
            get
            {
                return this.createdByField;
            }
            set
            {
                this.createdByField = value;
            }
        }
    }



    /// <summary>
    /// WO Action Property object implements property bag for WO Action Log. Each WO Action has its own set of properties (some might be required, other optional); and when WO Action Log record is created, property bag consisting of WO Action Property records. Typically, each property record stores single value (either numeric integer or free-text); the whole approach is similar to custom fields.
    /// Table [WOALogData2Object].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoActionLogProp : CorrigoEntity
    {

        private int woActionLogIdField;

        private System.Nullable<int> valueIntField;

        private string valueStrField;

        private WOActionProperty typeIdField;

        /// <summary>
        /// Reference to parent Action Log record, WOActionLog2Object.ID.
        /// </summary>
        public int WoActionLogId
        {
            get
            {
                return this.woActionLogIdField;
            }
            set
            {
                this.woActionLogIdField = value;
            }
        }


        /// <summary>
        /// Field where values for integer-based properties are stored. This property is nullable. E.g. default value is null; and BO must understand the difference between zero and null.
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<int> ValueInt
        {
            get
            {
                return this.valueIntField;
            }
            set
            {
                this.valueIntField = value;
            }
        }


        /// <summary>
        /// Field where values for text-based properties are stored. This property is nullable. E.g. default value is null; and BO must understand the difference between zero-length string and null.
        /// </summary>
        public string ValueStr
        {
            get
            {
                return this.valueStrField;
            }
            set
            {
                this.valueStrField = value;
            }
        }

        /// <summary>
        /// Property type (enumeration member); references WOALPropertyLookup.ID.
        /// </summary>
        public WOActionProperty TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }
    }


    /// <summary>
    /// Used to keep action history information for work order.
    /// Table [WOActionLog2Object].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoActionLog : CorrigoEntity
    {

        private int workOrderIdField;

        private WOActionType typeIdField;

        private Actor actorField;

        private System.DateTime actionDateField;

        private string commentField;

        private int actionReasonIdField;

        private bool isBackDateField;

        private UIType uiTypeIdField;

        private int timeZoneField;

        private System.DateTime systemDateUtcField;

        private int objectIdField;

        private WoActionLogProp[] propertiesField;

        /// <summary>
        /// Work Order Id
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <summary>
        /// Type of the action.
        /// </summary>
        public WOActionType TypeId
        {
            get
            {
                return this.typeIdField;
            }
            set
            {
                this.typeIdField = value;
            }
        }

        /// <summary>
        /// Link to actor who performed this action.
        /// </summary>
        public Actor Actor
        {
            get
            {
                return this.actorField;
            }
            set
            {
                this.actorField = value;
            }
        }


        /// <summary>
        /// Local timestamp of the action
        /// </summary>
        public System.DateTime ActionDate
        {
            get
            {
                return this.actionDateField;
            }
            set
            {
                this.actionDateField = value;
            }
        }

        /// <summary>
        /// Comment.
        /// Max Length=3072
        /// </summary>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <summary>
        /// Link to Action Reason
        /// </summary>
        public int ActionReasonId
        {
            get
            {
                return this.actionReasonIdField;
            }
            set
            {
                this.actionReasonIdField = value;
            }
        }

        /// <summary>
        /// True indicates action was backdated by end user; e.g. time when action is recorded is different from time when action was taken, according to the user.
        /// </summary>
        public bool IsBackDate
        {
            get
            {
                return this.isBackDateField;
            }
            set
            {
                this.isBackDateField = value;
            }
        }

        /// <summary>
        /// Change was made from: Unknown, Corp, CallCenter, Wireless, Resident, Monitor, System, IVR, Offline, IntegrationWS, WON, OTHER.
        /// Indicates CorrigoNet interface/application where action was recorded;
        /// </summary>
        public UIType UiTypeId
        {
            get
            {
                return this.uiTypeIdField;
            }
            set
            {
                this.uiTypeIdField = value;
            }
        }

        /// <summary>
        /// Time zone ID inherited from Work Order.
        /// </summary>
        public int TimeZone
        {
            get
            {
                return this.timeZoneField;
            }
            set
            {
                this.timeZoneField = value;
            }
        }

        /// <summary>
        /// UTC timestamp of the action. This value is computed by application rather than provided by user.
        /// </summary>
        public System.DateTime SystemDateUtc
        {
            get
            {
                return this.systemDateUtcField;
            }
            set
            {
                this.systemDateUtcField = value;
            }
        }

        /// <summary>
        /// Action-specific value referencing object (typically, WO child) linked to this action record. Supported only for some action types.
        /// </summary>
        public int ObjectId
        {
            get
            {
                return this.objectIdField;
            }
            set
            {
                this.objectIdField = value;
            }
        }

        /// <summary>
        ///  Additional action information records.
        /// </summary>
        public WoActionLogProp[] Properties
        {
            get
            {
                return this.propertiesField;
            }
            set
            {
                this.propertiesField = value;
            }
        }
    }



    /// <summary>
    /// Describes last action performed on a WorkOrder. Contains action reason, invoice, bill status, total bill amount.
    /// Table [AutoWOLastAction].
    /// Web service access scope - read only.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoLastAction : CorrigoEntity
    {

        private int workOrderIdField;

        private WoActionLog lastActionField;

        private WoActionReasonLookup emergencyReasonField;

        private WoActionReasonLookup reasonField;

        private BillStatus billStatusField;

        private Invoice invoiceField;

        private System.Nullable<decimal> billedTotalField;

        private string xNumberField;

        /// <summary>
        /// NOTE: It's used as ID
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <summary>
        /// Reference to last status-changing action for WO
        /// Table [WOActionLog2Object.ID].
        /// </summary>
        public WoActionLog LastAction
        {
            get
            {
                return this.lastActionField;
            }
            set
            {
                this.lastActionField = value;
            }
        }

        /// <summary>
        /// Reason for escalating WO to Emergency when creating new WO from Customer Portal. References WOActionReasonLookup.(ActionID = WOActionType.PriorityChanged, ReasonID).
        /// </summary>
        public WoActionReasonLookup EmergencyReason
        {
            get
            {
                return this.emergencyReasonField;
            }
            set
            {
                this.emergencyReasonField = value;
            }
        }

        /// <summary>
        ///Reason matching current WO status. Only On Hold and Cancelled statuses support and require reasons; for other statuses this field is null/empty.
        /// </summary>
        public WoActionReasonLookup Reason
        {
            get
            {
                return this.reasonField;
            }
            set
            {
                this.reasonField = value;
            }
        }

        /// <summary>
        /// WO billing status computed based on WO status and financial status(es). It�s a bitmask matching enumeration BillStatus. Cumulative mask value is a reference to vlangWOBillingStatusLookup.ID.
        /// </summary>
        public BillStatus BillStatus
        {
            get
            {
                return this.billStatusField;
            }
            set
            {
                this.billStatusField = value;
            }
        }

        /// <summary>
        /// Customer Invoice associated with WO; 
        /// references table ciInvoiceObject.ID.
        /// </summary>	
        public Invoice Invoice
        {
            get
            {
                return this.invoiceField;
            }
            set
            {
                this.invoiceField = value;
            }
        }

        /// <summary>
        /// Contains total billed value; either preview (when ciInvoiceID == NULL) or actual version (otherwise). This field is nullable; NULL value is different from zero; it means total billed preview was never computed (when ciInvoiceID == NULL) or total billed amount is not applicable to this WO (otherwise).
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<decimal> BilledTotal
        {
            get
            {
                return this.billedTotalField;
            }
            set
            {
                this.billedTotalField = value;
            }
        }

        /// <summary>
        /// �External� WO number provided by third-party application. Used by integration.
        /// Max Length=256
        /// </summary>
        public string XNumber
        {
            get
            {
                return this.xNumberField;
            }
            set
            {
                this.xNumberField = value;
            }
        }
    }


    /// <summary>
    /// Represents custom field (read only).
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CustomField : CorrigoEntity
    {

        private CustomFieldDescriptor descriptorField;

        private int objectIdField;

        private string valueField;

        /// <summary>
        /// Gets custom field metadata
        /// </summary>
        public CustomFieldDescriptor Descriptor
        {
            get
            {
                return this.descriptorField;
            }
            set
            {
                this.descriptorField = value;
            }
        }

        /// <summary>
        /// Object ID
        /// </summary>
        public int ObjectId
        {
            get
            {
                return this.objectIdField;
            }
            set
            {
                this.objectIdField = value;
            }
        }

        /// <summary>
        /// Gets Custom Field name
        /// </summary>
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }


    /// <summary>
    /// Represents organization.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class Organization : CorrigoEntity
    {

        private string displayAsField;

        private string numberField;

        private bool isCompliantField;

        /// <remarks/>
        public string DisplayAs
        {
            get
            {
                return this.displayAsField;
            }
            set
            {
                this.displayAsField = value;
            }
        }

        /// <remarks/>
        public string Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        public bool IsCompliant
        {
            get
            {
                return this.isCompliantField;
            }
            set
            {
                this.isCompliantField = value;
            }
        }
    }


}