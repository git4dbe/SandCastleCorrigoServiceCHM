namespace CorrigoService.Commands
{
    using System;
    using System.Web.Services;
    using System.Diagnostics;
    using System.Web.Services.Protocols;
    using System.Xml.Serialization;
    using System.ComponentModel;
    using Enums;
    using Entities;

    /// <summary>
    /// Specifies the command response abstract class used as return value in the Execute method.
    /// </summary>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(OperationCommandResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CompositeCommandResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoActionResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(FinancialStatusChangeResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoLastModificationResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetCompanyWsdkUrlResult))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(LoginResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(EmployeeResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(SpaceCreateCommandResponse))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(MatchAssetsResponse))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CommandResponse
    {

        private ErrorInfo errorInfoField;

        /// <summary>
        /// Gets or sets an error info. If null, no error occurred.
        /// </summary>
        public ErrorInfo ErrorInfo
        {
            get
            {
                return this.errorInfoField;
            }
            set
            {
                this.errorInfoField = value;
            }
        }
    }

    /// <summary>
    ///  Contains result of an entity operation like Create, Update or Delete.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class OperationCommandResponse : CommandResponse
    {

        private EntitySpecifier entitySpecifierField;

        private NestedEntityOperationResult[] nestedEntitiesOperationResultsField;

        /// <summary>
        /// Gets or sets the entity specifier.
        /// </summary>
        public EntitySpecifier EntitySpecifier
        {
            get
            {
                return this.entitySpecifierField;
            }
            set
            {
                this.entitySpecifierField = value;
            }
        }

        /// <summary>
        /// Gets or sets the collection of operation results performed on nested entities.
        /// </summary>
        public NestedEntityOperationResult[] NestedEntitiesOperationResults
        {
            get
            {
                return this.nestedEntitiesOperationResultsField;
            }
            set
            {
                this.nestedEntitiesOperationResultsField = value;
            }
        }
    }

    /// <summary>
    /// Contains result of an CompositeCommand.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CompositeCommandResponse : CommandResponse
    {

        private CommandResponse[] responsesField;

        /// <summary>
        /// Contains a list of CommandResponse for executed commands.
        /// </summary>
        public CommandResponse[] Responses
        {
            get
            {
                return this.responsesField;
            }
            set
            {
                this.responsesField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoActionResponse : CommandResponse
    {

        private WorkOrder woField;

        private PropertySet updatedPropertySetField;

        /// <summary>
        /// Reference to WorkOrder entity; contains up-to-date WO state after WO action finishes. Only scalar properties are returned.
        /// </summary>
        public WorkOrder Wo
        {
            get
            {
                return this.woField;
            }
            set
            {
                this.woField = value;
            }
        }

        /// <remarks/>
        public PropertySet UpdatedPropertySet
        {
            get
            {
                return this.updatedPropertySetField;
            }
            set
            {
                this.updatedPropertySetField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class FinancialStatusChangeResponse : CommandResponse
    {

        private WorkOrderCost financialField;

        /// <summary>
        /// Reference to WorkOrderCost entity; contains up-to-date Financial Record state after action finishes.
        /// </summary>
        public WorkOrderCost Financial
        {
            get
            {
                return this.financialField;
            }
            set
            {
                this.financialField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoLastModificationResponse : CommandResponse
    {

        private System.DateTime dtLastModifiedField;

        private int workOrderIdField;

        /// <remarks/>
        public System.DateTime DtLastModified
        {
            get
            {
                return this.dtLastModifiedField;
            }
            set
            {
                this.dtLastModifiedField = value;
            }
        }

        /// <remarks/>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class GetCompanyWsdkUrlResult : CommandResponse
    {

        private string urlField;

        private string compaqnyNameField;

        private Protocols protocolField;

        /// <remarks/>
        public string Url
        {
            get
            {
                return this.urlField;
            }
            set
            {
                this.urlField = value;
            }
        }

        /// <remarks/>
        public string CompanyName
        {
            get
            {
                return this.compaqnyNameField;
            }
            set
            {
                this.compaqnyNameField = value;
            }
        }

        /// <remarks/>
        public Protocols Protocol
        {
            get
            {
                return this.protocolField;
            }
            set
            {
                this.protocolField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class LoginResponse : CommandResponse
    {

        private int userIdField;

        private int actorTypeIdField;

        private bool successField;

        /// <remarks/>
        public int UserId
        {
            get
            {
                return this.userIdField;
            }
            set
            {
                this.userIdField = value;
            }
        }

        /// <remarks/>
        public int ActorTypeId
        {
            get
            {
                return this.actorTypeIdField;
            }
            set
            {
                this.actorTypeIdField = value;
            }
        }

        /// <remarks/>
        public bool Success
        {
            get
            {
                return this.successField;
            }
            set
            {
                this.successField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class EmployeeResponse : CommandResponse
    {

        private int employeeIdField;

        /// <remarks/>
        public int EmployeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }
    }


    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class SpaceCreateCommandResponse : CommandResponse
    {

        private Space newSpaceField;

        /// <summary>
        /// New Space entity with only scalar properties initialized.
        /// </summary>
        public Space NewSpace
        {
            get
            {
                return this.newSpaceField;
            }
            set
            {
                this.newSpaceField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class MatchAssetsResponse : CommandResponse
    {

        private Location[] locationsField;

        /// <remarks/>
        public Location[] Locations
        {
            get
            {
                return this.locationsField;
            }
            set
            {
                this.locationsField = value;
            }
        }
    }

    /// <summary>
    /// Specifies the command request abstract class used in the Execute method.
    /// </summary>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(PostPaymentCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(SpaceCreateCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AssetMatchByTaskCodeCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(UpdateInvoiceStateCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoLastModificationCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CreateCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(UpdateCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(DeleteCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(RestoreCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CompositeCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(BaseWoActionCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoFlagCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoCreateCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoCancelCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoPickUpCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoStartCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoPauseCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoOnHoldCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoReopenCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoCompleteCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoAssignCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ApStatusChangeCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ApSubmitPaymentCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CostStatusChangeCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoScheduleRoutine))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(GetCompanyWsdkUrlCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoAutoAssignRoutine))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public abstract partial class CommandRequest
    {
    }


    /// <summary>
    ///  Represents a command to set <see cref="PaymentState">payment state</see> as Posted.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class PostPaymentCommand : CommandRequest
    {

        private int paymentIdField;

        private System.Nullable<System.DateTime> timestampField;

        /// <summary>
        /// Gets or sets an payment id.
        /// </summary>
        public int PaymentId
        {
            get
            {
                return this.paymentIdField;
            }
            set
            {
                this.paymentIdField = value;
            }
        }

        /// <summary>
        /// Gets or sets a timestamp (optional).
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> Timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
            }
        }
    }

    /// <summary>
    /// This command allows integration client creating Space and its Unit asset at the same time; while specifying new Unit�s 
    /// location inside work zone and asset templates for Unit itself, its floor and building.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class SpaceCreateCommand : CommandRequest
    {

        private int customerIdField;

        private System.DateTime startDateField;

        private System.DateTime endDateField;

        private System.DateTime moveOutDateField;

        private string instructionsField;

        private int unitIdField;

        private NewUnitSpecifier newUnitSpecifierField;

        /// <summary>
        /// Parent Customer ID, required.
        /// </summary>
        public int CustomerId
        {
            get
            {
                return this.customerIdField;
            }
            set
            {
                this.customerIdField = value;
            }
        }

        /// <summary>
        /// Start date, optional.
        /// </summary>
        public System.DateTime StartDate
        {
            get
            {
                return this.startDateField;
            }
            set
            {
                this.startDateField = value;
            }
        }

        /// <summary>
        /// End date, optional.
        /// </summary>
        public System.DateTime EndDate
        {
            get
            {
                return this.endDateField;
            }
            set
            {
                this.endDateField = value;
            }
        }

        /// <summary>
        /// Move out date, optional.
        /// </summary>
        public System.DateTime MoveOutDate
        {
            get
            {
                return this.moveOutDateField;
            }
            set
            {
                this.moveOutDateField = value;
            }
        }

        /// <summary>
        /// Free-text value containing additional notes/instructions, optional.
        /// </summary>
        public string Instructions
        {
            get
            {
                return this.instructionsField;
            }
            set
            {
                this.instructionsField = value;
            }
        }

        /// <summary>
        /// ID of the Unit associated with the Space. Zero means new Unit will be created based on NewUnitSpecifier parameter.
        /// </summary>
        public int UnitId
        {
            get
            {
                return this.unitIdField;
            }
            set
            {
                this.unitIdField = value;
            }
        }

        /// <summary>
        /// Reference to object containing information about the new Unit. Ignored when UnitId != 0.
        /// </summary>
        public NewUnitSpecifier NewUnitSpecifier
        {
            get
            {
                return this.newUnitSpecifierField;
            }
            set
            {
                this.newUnitSpecifierField = value;
            }
        }
    }

    /// <summary>
    /// This command allows integration client to search for assets under specified parent; with two additional criteria: (a) only assets belonging to specified categories included into the search; (b) asset model must have task with the specified code.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class AssetMatchByTaskCodeCommand : CommandRequest
    {

        private int parentAssetIdField;

        private AssetType[] assetCategoriesField;

        private string taskCodeField;

        private int recordCountField;

        /// <summary>
        /// Parent asset ID, required. 
        /// </summary>
        public int ParentAssetId
        {
            get
            {
                return this.parentAssetIdField;
            }
            set
            {
                this.parentAssetIdField = value;
            }
        }

        /// <summary>
        /// Array of AssetType enumeration values. Empty array (i.e. containing zero items) is acceptable.
        /// </summary>
        public AssetType[] AssetCategories
        {
            get
            {
                return this.assetCategoriesField;
            }
            set
            {
                this.assetCategoriesField = value;
            }
        }

        /// <summary>
        /// Required (zero-length and null values are not allowed)
        /// </summary>
        public string TaskCode
        {
            get
            {
                return this.taskCodeField;
            }
            set
            {
                this.taskCodeField = value;
            }
        }

        /// <summary>
        /// Number of records to return (no more than X). 0 value is acceptable.
        /// </summary>
        public int RecordCount
        {
            get
            {
                return this.recordCountField;
            }
            set
            {
                this.recordCountField = value;
            }
        }
    }


    /// <summary>
    ///  Represents a command for modification invoice state.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class UpdateInvoiceStateCommand : CommandRequest
    {

        private int invoiceIdField;

        private CiInvoiceState stateField;

        private System.Nullable<System.DateTime> timestampField;

        private string commentField;

        /// <summary>
        /// Gets or sets an invoice id.
        /// </summary>
        public int InvoiceId
        {
            get
            {
                return this.invoiceIdField;
            }
            set
            {
                this.invoiceIdField = value;
            }
        }

        /// <summary>
        /// Gets or sets a required state.
        /// </summary>
        public CiInvoiceState State
        {
            get
            {
                return this.stateField;
            }
            set
            {
                this.stateField = value;
            }
        }

        /// <summary>
        /// Gets or sets a required timestamp (optional).
        /// </summary>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> Timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
            }
        }

        /// <summary>
        /// Gets or sets a comment (optional).
        /// </summary>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }
    }

    /// <summary>
    ///  Represents a command for retrieving WO last modification date.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoLastModificationCommand : CommandRequest
    {

        private int workOrderIdField;

        /// <summary>
        /// Gets or sets an Work Order ID.
        /// </summary>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }
    }

    /// <summary>
    /// Represents a command for creating an instance of a Corrigo entity.
    /// Returns an OperationCommandResponse that contains an identifier and a type of the newly created entity or error information in case of an error.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CreateCommand : CommandRequest
    {

        private CorrigoEntity entityField;

        /// <summary>
        /// Specifies an instance of a class derived from CorrigoEntity of the type entity to create.
        /// </summary>
        public CorrigoEntity Entity
        {
            get
            {
                return this.entityField;
            }
            set
            {
                this.entityField = value;
            }
        }
    }

    /// <summary>
    ///  Represents a command for updating an existing entity instance.
    /// Returns an OperationCommandResponse that contains an identifier and a type of the updated entity or error information in case of an error.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class UpdateCommand : CommandRequest
    {

        private CorrigoEntity entityField;

        private PropertySetBase propertySetField;

        /// <summary>
        /// Specifies an instance of a class derived from CorrigoEntity of a type that supports update. The instance has one or more property values set that are to be updated.
        /// </summary>
        public CorrigoEntity Entity
        {
            get
            {
                return this.entityField;
            }
            set
            {
                this.entityField = value;
            }
        }

        /// <summary>
        /// Specifies the set of properties to update. Passing a null value will lead to error. To update all properties, pass a new instance of the AllProperties class.
        /// </summary>
        public PropertySetBase PropertySet
        {
            get
            {
                return this.propertySetField;
            }
            set
            {
                this.propertySetField = value;
            }
        }
    }

    /// <summary>
    /// Represents a command for deleting an existing entity instance.
    /// Returns an OperationCommandResponse that contains an identifier and a type of the deleted entity or error information in case of an error.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class DeleteCommand : CommandRequest
    {

        private EntitySpecifier entitySpecifierField;

        /// <summary>
        /// Specifies an entity by identifier and entity type to be deleted.
        /// </summary>
        public EntitySpecifier EntitySpecifier
        {
            get
            {
                return this.entitySpecifierField;
            }
            set
            {
                this.entitySpecifierField = value;
            }
        }
    }

    /// <summary>
    ///  Represents a command for restoring previously deleted entity instance.
    /// Works only for some entities which support this feature.
    /// Returns an OperationCommandResponse that contains an identifier and a type of the restored entity or error information in case of an error.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class RestoreCommand : CommandRequest
    {

        private EntitySpecifier entitySpecifierField;

        /// <summary>
        /// Specifies an entity by identifier and entity type to be restored.
        /// </summary>
        public EntitySpecifier EntitySpecifier
        {
            get
            {
                return this.entitySpecifierField;
            }
            set
            {
                this.entitySpecifierField = value;
            }
        }
    }

    /// <summary>
    /// Executes commands in sequential manner until first error.
    /// Returns an CompositeCommandResponse that contains a list of a CommandRequest for successfully completed commands or error information in case of an error.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CompositeCommand : CommandRequest
    {

        private bool isTransactionalField;

        private CommandRequest[] commandsField;

        /// <summary>
        /// Gets or sets a value indicating that all commands should be executed in one transaction.
        /// </summary>
        public bool IsTransactional
        {
            get
            {
                return this.isTransactionalField;
            }
            set
            {
                this.isTransactionalField = value;
            }
        }

        /// <summary>
        /// Specifies a list of specific CommandRequest instances.
        /// </summary>
        public CommandRequest[] Commands
        {
            get
            {
                return this.commandsField;
            }
            set
            {
                this.commandsField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoFlagCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoCreateCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoCancelCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoPickUpCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoStartCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoPauseCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoOnHoldCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoReopenCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoCompleteCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(WoAssignCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ApStatusChangeCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ApSubmitPaymentCommand))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(CostStatusChangeCommand))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public abstract partial class BaseWoActionCommand : CommandRequest
    {

        private System.DateTime actionDateField;

        private int workOrderIdField;

        private string commentField;

        private WOStatus statusIdField;

        private int concurrencyIdField;

        private int actionReasonIdField;

        /// <remarks/>
        public System.DateTime ActionDate
        {
            get
            {
                return this.actionDateField;
            }
            set
            {
                this.actionDateField = value;
            }
        }

        /// <remarks/>
        public int WorkOrderId
        {
            get
            {
                return this.workOrderIdField;
            }
            set
            {
                this.workOrderIdField = value;
            }
        }

        /// <remarks/>
        public string Comment
        {
            get
            {
                return this.commentField;
            }
            set
            {
                this.commentField = value;
            }
        }

        /// <remarks/>
        public WOStatus StatusId
        {
            get
            {
                return this.statusIdField;
            }
            set
            {
                this.statusIdField = value;
            }
        }

        /// <remarks/>
        public int ConcurrencyId
        {
            get
            {
                return this.concurrencyIdField;
            }
            set
            {
                this.concurrencyIdField = value;
            }
        }

        /// <remarks/>
        public int ActionReasonId
        {
            get
            {
                return this.actionReasonIdField;
            }
            set
            {
                this.actionReasonIdField = value;
            }
        }
    }



    /// <summary>
    /// Is used to set flag to a Work Order.
    /// Contains reason and comment.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoFlagCommand : BaseWoActionCommand
    {
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoCreateCommand : BaseWoActionCommand
    {

        private WorkOrder workOrderField;

        private WpTree wpTreeField;

        private int employeeIdField;

        private bool keepUnassignedField;

        private bool computeScheduleField;

        private bool computeAssignmentField;

        private bool emergencyDisabledField;

        private bool skipBillToLogicField;

        private bool skipPunchListsField;

        private string externalNumberField;

        /// <summary>
        /// Reference to Work Order entity, required. Integration client must provide property values as specified below.
        /// </summary>
        public WorkOrder WorkOrder
        {
            get
            {
                return this.workOrderField;
            }
            set
            {
                this.workOrderField = value;
            }
        }

        /// <summary>
        /// Reference to Work Plan Link entity, optional. Integration client needs to provide this property only when new WO is created as part of work plan.
        /// </summary>
        public WpTree WpTree
        {
            get
            {
                return this.wpTreeField;
            }
            set
            {
                this.wpTreeField = value;
            }
        }

        /// <summary>
        /// Primary assignee ID; 0 means Work Order remains unassigned. This value is ignored if ComputeAssignment == True.
        /// </summary>
        public int EmployeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }

        /// <summary>
        /// True means integration services will not perform auto-assignment routine.
        /// </summary>
        public bool KeepUnassigned
        {
            get
            {
                return this.keepUnassignedField;
            }
            set
            {
                this.keepUnassignedField = value;
            }
        }

        /// <summary>
        /// True means �Schedule� routine will be executed. Default value is False.
        /// </summary>
        public bool ComputeSchedule
        {
            get
            {
                return this.computeScheduleField;
            }
            set
            {
                this.computeScheduleField = value;
            }
        }


        /// <summary>
        /// True means �Auto Assignment� routine will be executed. Default value is False.
        /// </summary>
        public bool ComputeAssignment
        {
            get
            {
                return this.computeAssignmentField;
            }
            set
            {
                this.computeAssignmentField = value;
            }
        }

        /// <summary>
        /// Boolean flag. True means WO priority value will be de-escalated from emergency to highest non-emergency priority
        /// </summary>
        public bool EmergencyDisabled
        {
            get
            {
                return this.emergencyDisabledField;
            }
            set
            {
                this.emergencyDisabledField = value;
            }
        }

        /// <summary>
        /// True means integration services will use billing configuration as specified rather than automatically compute billing settings for new WO. Matches CreateWoAction.SkipContract.
        /// </summary>
        public bool SkipBillToLogic
        {
            get
            {
                return this.skipBillToLogicField;
            }
            set
            {
                this.skipBillToLogicField = value;
            }
        }

        /// <summary>
        /// Boolean flag. True means routine will not attach punch lists to new WO automatically. 
        /// </summary>
        public bool SkipPunchLists
        {
            get
            {
                return this.skipPunchListsField;
            }
            set
            {
                this.skipPunchListsField = value;
            }
        }

        /// <summary>
        /// Optional string containing �external� WO number (provided by third-party application)
        /// </summary>
        public string ExternalNumber
        {
            get
            {
                return this.externalNumberField;
            }
            set
            {
                this.externalNumberField = value;
            }
        }
    }


    /// <summary>
    /// Cancels Work Order.
    /// ActionReasonId - The Id of a reason from cancel reasons.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoCancelCommand : BaseWoActionCommand
    {
    }

    /// <summary>
    /// Changes work order state from 'New' to 'Open'.
    /// Assignment is required.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoPickUpCommand : BaseWoActionCommand
    {
    }

    /// <summary>
    /// Changes work order state from 'Open' to 'In Progress'.
    /// Assignment is required.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoStartCommand : BaseWoActionCommand
    {
    }

    /// <summary>
    /// Changes work order state from 'In Progress' to 'Paused'. 
    /// Assignment required.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoPauseCommand : BaseWoActionCommand
    {
    }

    /// <summary>
    /// Put Work Order 'On Hold'.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoOnHoldCommand : BaseWoActionCommand
    {
    }

    /// <summary>
    /// Reopens work order after 'Close', 'On Hold', 'Cancell' statuses.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoReopenCommand : BaseWoActionCommand
    {
    }

    /// <summary>
    /// Completes Work Order.
    /// Assignment required.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoCompleteCommand : BaseWoActionCommand
    {

        private int repairCodeIdField;

        private CompletionNoteOptions completionNoteOptionField;

        /// <summary>
        /// Repair Code Id can be specified to set RepairCode.
        /// </summary>
        public int RepairCodeId
        {
            get
            {
                return this.repairCodeIdField;
            }
            set
            {
                this.repairCodeIdField = value;
            }
        }

        /// <summary>
        /// Completion Note Option: Ignore, Replace, FillEmpty
        /// </summary>
        public CompletionNoteOptions CompletionNoteOption
        {
            get
            {
                return this.completionNoteOptionField;
            }
            set
            {
                this.completionNoteOptionField = value;
            }
        }
    }



    /// <summary>
    /// Allows to assign Work Order to some user.
    /// Requires WoChangeAssigmentMode (if a Workorder is not assigned to anyone - use Primary mode),
    /// Employee.Id of user for an assignment
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoAssignCommand : BaseWoActionCommand
    {

        private int[] assigneesField;

        private WoChangeAssigmentMode modeField;

        /// <summary>
        /// Employee.Ids of users for an assignment
        /// </summary>
        public int[] Assignees
        {
            get
            {
                return this.assigneesField;
            }
            set
            {
                this.assigneesField = value;
            }
        }

        /// <summary>
        /// How Assignees parameter is treated. Four modes supported: Primary, AddSecondary, RemoveSecondary and Snapshot.
        /// In Snapshot mode, Assignees collection is treated as new list of assignees for WO;
        /// and first item in that list is treated as primary assignee.
        /// In all modes Assignees can be empty.
        /// </summary>
        public WoChangeAssigmentMode Mode
        {
            get
            {
                return this.modeField;
            }
            set
            {
                this.modeField = value;
            }
        }
    }



    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ApSubmitPaymentCommand))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class ApStatusChangeCommand : BaseWoActionCommand
    {

        private APInvoiceStatus vendorInvoiceStatusIdField;

        private bool keepCommentIntactField;

        private APInvoiceStatus currentStatusIdField;

        private int financialConcurrencyIdField;

        /// <summary>
        /// New value for Vendor Invoice Status
        /// </summary>
        public APInvoiceStatus VendorInvoiceStatusId
        {
            get
            {
                return this.vendorInvoiceStatusIdField;
            }
            set
            {
                this.vendorInvoiceStatusIdField = value;
            }
        }

        /// <summary>
        /// Boolean flag; True means routine will not alter Comment value provided by caller.
        /// </summary>
        public bool KeepCommentIntact
        {
            get
            {
                return this.keepCommentIntactField;
            }
            set
            {
                this.keepCommentIntactField = value;
            }
        }

        /// <summary>
        /// Current value of WorkOrderCost.ApStatusId, optional. Together with FinancialConcurrencyID, define concurrency check logic for this action. Since this action is inherited from WoAction it also supports WO concurrency ID check based on StatusID and ConcurrencyId properties. The expected usage scenario for �Vendor Invoice Status Change� action is StatusID = APInvoiceStatus.Unknown and ConcurrencyId = 0; e.g. WO concurrency check is turned off.
        /// </summary>
        public APInvoiceStatus CurrentStatusId
        {
            get
            {
                return this.currentStatusIdField;
            }
            set
            {
                this.currentStatusIdField = value;
            }
        }
        /// <summary>
        /// FinancialConcurrencyID: Current value of WorkOrderCost.ConcurrencyId, optional.
        /// </summary>
        public int FinancialConcurrencyId
        {
            get
            {
                return this.financialConcurrencyIdField;
            }
            set
            {
                this.financialConcurrencyIdField = value;
            }
        }
    }



    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class ApSubmitPaymentCommand : ApStatusChangeCommand
    {

        private decimal paymentAmountField;

        private string checkNumberField;

        private System.Nullable<System.DateTime> checkCutDateField;

        /// <remarks/>
        public decimal PaymentAmount
        {
            get
            {
                return this.paymentAmountField;
            }
            set
            {
                this.paymentAmountField = value;
            }
        }

        /// <remarks/>
        public string CheckNumber
        {
            get
            {
                return this.checkNumberField;
            }
            set
            {
                this.checkNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(IsNullable = true)]
        public System.Nullable<System.DateTime> CheckCutDate
        {
            get
            {
                return this.checkCutDateField;
            }
            set
            {
                this.checkCutDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class CostStatusChangeCommand : BaseWoActionCommand
    {

        private CostStatus costStatusIdField;

        private bool keepCommentIntactField;

        private CostStatus currentStatusIdField;

        private int financialConcurrencyIdField;

        /// <summary>
        /// New value for Vendor Invoice Status
        /// </summary>
        public CostStatus CostStatusId
        {
            get
            {
                return this.costStatusIdField;
            }
            set
            {
                this.costStatusIdField = value;
            }
        }


        /// <summary>
        /// Boolean flag; True means routine will not alter Comment value provided by caller.
        /// </summary>
        public bool KeepCommentIntact
        {
            get
            {
                return this.keepCommentIntactField;
            }
            set
            {
                this.keepCommentIntactField = value;
            }
        }


        /// <summary>
        /// Current value of WorkOrderCost.ApStatusId, optional. Together with FinancialConcurrencyID, define concurrency check logic for this action. Since this action is inherited from WoAction it also supports WO concurrency ID check based on StatusID and ConcurrencyId properties. The expected usage scenario for �Vendor Invoice Status Change� action is StatusID = APInvoiceStatus.Unknown and ConcurrencyId = 0; e.g. WO concurrency check is turned off.
        /// </summary>
        public CostStatus CurrentStatusId
        {
            get
            {
                return this.currentStatusIdField;
            }
            set
            {
                this.currentStatusIdField = value;
            }
        }

        /// <summary>
        /// FinancialConcurrencyID: Current value of WorkOrderCost.ConcurrencyId, optional.
        /// </summary>
        public int FinancialConcurrencyId
        {
            get
            {
                return this.financialConcurrencyIdField;
            }
            set
            {
                this.financialConcurrencyIdField = value;
            }
        }
    }




    /// <summary>
    /// This command is used primarily to prepare scheduling data for the new Work Order: flag �Possibly covered by warranty�, PTE, Priority, Specialty, Duration, GL Account, Vendor NTE, due date etc. It can be also executed for existing Work Order.
    /// Allows assign date-time fields such as: creation date, due date, on site by date, duration of the Work Order.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoScheduleRoutine : CommandRequest
    {

        private WorkOrder workOrderField;

        private WoScheduleOptions optionsField;

        private PropertySet outputPropertySetField;

        private PropertySet inputPropertySetField;

        /// <summary>
        /// Work Order
        /// </summary>
        public WorkOrder WorkOrder
        {
            get
            {
                return this.workOrderField;
            }
            set
            {
                this.workOrderField = value;
            }
        }

        /// <summary>
        /// Flags (could be combined with bitwise OR) to turn off some WorkOrder�s property changes while the command is executed.
        /// </summary>
        public WoScheduleOptions Options
        {
            get
            {
                return this.optionsField;
            }
            set
            {
                this.optionsField = value;
            }
        }

        /// <summary>
        /// Output Property Set
        /// </summary>
        public PropertySet OutputPropertySet
        {
            get
            {
                return this.outputPropertySetField;
            }
            set
            {
                this.outputPropertySetField = value;
            }
        }

        /// <summary>
        /// Input Property Set
        /// </summary>
        public PropertySet InputPropertySet
        {
            get
            {
                return this.inputPropertySetField;
            }
            set
            {
                this.inputPropertySetField = value;
            }
        }
    }



    /// <summary>
    ///  Converts a Company Name argument into a fully-qualified URL for WSDK calls.
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class GetCompanyWsdkUrlCommand : CommandRequest
    {

        private string companyNameField;

        private Protocols protocolField;

        /// <summary>
        /// Gets or sets Company Name.
        /// </summary>
        public string CompanyName
        {
            get
            {
                return this.companyNameField;
            }
            set
            {
                this.companyNameField = value;
            }
        }

        /// <summary>
        /// Gets or sets Protocol.
        /// </summary>
        public Protocols Protocol
        {
            get
            {
                return this.protocolField;
            }
            set
            {
                this.protocolField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.1590.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://corrigo.com/integration/")]
    public partial class WoAutoAssignRoutine : CommandRequest
    {

        private WorkOrder workOrderField;

        private string zipField;

        /// <remarks/>
        public WorkOrder WorkOrder
        {
            get
            {
                return this.workOrderField;
            }
            set
            {
                this.workOrderField = value;
            }
        }

        /// <remarks/>
        public string Zip
        {
            get
            {
                return this.zipField;
            }
            set
            {
                this.zipField = value;
            }
        }
    }




}